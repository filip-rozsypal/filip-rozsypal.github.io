function [VF,PF,reaction_y,reaction_inf]=Paper_VI_full_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init)

global alpha y_star y_target s_eps beta_l beta_h delta;
disp('----------------------------------------------------------------------------------')    


%% initialisation
[meshgrid_inf,meshgrid_y] = meshgrid(Prob_inf,Prob_y);

y_ND = beta_h/(alpha^2+beta_h)*epsilon;
inf_ND = alpha/beta_h*y_star - alpha/(alpha^2+beta_h)*epsilon;

inf_e_D = alpha/beta_h*y_target;

allocation_inf = @(beta)(alpha  * y_target +    alpha^2 * inf_e_D - alpha * epsilon)/(alpha^2+beta);
allocation_y   = @(beta)(alpha^2* y_target - alpha*beta * inf_e_D +  beta * epsilon)/(alpha^2+beta);


beta_grid = [beta_l beta_h];

inflation = zeros(size(beta_grid,2),size(epsilon,2));
output    = zeros(size(beta_grid,2),size(epsilon,2));
P         = zeros(size(beta_grid,2),size(epsilon,2));
L_NP      = zeros(size(beta_grid,2),size(epsilon,2));

for i=1:size(beta_grid,2)
    inflation(i,:) = allocation_inf(beta_grid(i));
    output(i,:)    = allocation_y(beta_grid(i));
    
    P(i,:)         = interp2(meshgrid_inf,meshgrid_y,Prob,inflation(i,:),output(i,:),'*spline');
    L_NP(i,:)        = 0.5*(output(i,:)-y_star).^2 + 0.5* beta_l * inflation(i,:).^2;
end



%%
%Gauss-Hermite quadrature (just to remember for the iteration)
V_NP_new = 900*ones(size(epsilon));

[nodes, weights] = GaussHermite(15);
EV_NP =  1/sqrt(pi)*weights'* interp1(epsilon,V_NP_new,(sqrt(2)*s_eps.*nodes),'linear','extrap');


%expected value while being punished E[V^p(eps)]
EL_punished = 1/2*beta_l/(alpha^2+beta_l)*s_eps^2+1/2*(alpha^2+beta_l)/beta_l*y_star^2;
EV_P = EL_punished + delta*EV_NP;
%EV_P = EL_punished/(1-delta)







%% Iteration
disp('Value function iteration')
cont = 1;
count=0;
diff = 100;
while cont

    if diff<tolerance
        cont=0;
    else
        count=count+1;
        V_NP = V_NP_new;
        EV_NP =  1/sqrt(pi)*weights'* interp1(epsilon,V_NP,(sqrt(2)*s_eps.*nodes),'linear','extrap');
        EV_P = EL_punished + delta*EV_NP; %update expected value of being punished
        
        [V_NP_new PF] = min( L_NP +  delta*(P *EV_P+(1-P) * EV_NP));
        
        EV_NP_new =  1/sqrt(pi)*weights'* interp1(epsilon,V_NP_new,(sqrt(2)*s_eps.*nodes),'linear','extrap'); %expected value of not being punished     
        
                
        diff = max(abs(V_NP_new-V_NP)./V_NP);
        
        
        
        if mod(count,10)==0
            fprintf('*');
        end
        
        if mod(count,500)==0
            fprintf('\n');
        end
 
    end
end
fprintf('\n')
disp(strcat(num2str(count),' iterations needed to converge, done.'));


PF2=NaN*zeros(size(PF));
for i=1:size(epsilon,2)
    PF2(i) =  output(PF(i),i)- output(2,i)  ;
end



%% figures
% figure(100)
% plot(epsilon,PF2,'r');
% ylabel('deviation');xlabel('\epsilon');hline(0);vline(0);

reaction_y   = NaN*zeros(size(epsilon));
reaction_inf = NaN*zeros(size(epsilon));

for i=1:size(epsilon,2)
    vector=zeros(size(epsilon)); vector(i)=1; vector=vector';    
    reaction_y(i)=allocation_y(beta_h)*vector+PF2(i);
    reaction_inf(i)=allocation_inf(beta_h)*vector+PF2(i)/alpha;
end

% figure(100)
% plot(epsilon,PF2);
% ylabel('\beta');xlabel('\epsilon'); hline(beta_l);hline(beta_h);vline(0);

% figure(101)
% for i=1:size(epsilon,2)
%     vector=zeros(size(epsilon)); vector(i)=1; vector=vector';
%     plot(allocation_y(PF(i))*vector,allocation_inf(PF(i))*vector,'.'); hold on;
% end
% ylabel('\pi');xlabel('Prob_y')
% hold off;
%     plot(reaction_y,reaction_inf)
  

PF=PF2;

VF = V_NP_new;




