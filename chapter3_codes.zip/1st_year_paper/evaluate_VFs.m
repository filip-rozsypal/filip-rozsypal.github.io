

clear all;clc;
set(0,'DefaultFigureWindowStyle','docked');
global alpha y_star y_target s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target_dir;

target_dir='F:\matlab\1st_year_paper\';
%target_dir='C:\Users\Filip Rozsypal\Documents\MATLAB\1st_year_paper\';

print_graphs = 1;
print_exp_dir = 'C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper\fig\';

int_method = 'Simpson';
%int_method = 'gauss_quadrature';

%model_experiment = 'Blinder_y';
model_experiment = 'Blinder_beta';
%model_experiment = 'Blinder_kappa';

%model_experiment = 'Rogoff_kappa';
%model_experiment = 'Rogoff_y';
%model_experiment = 'Rogoff_beta'; 

switch model_experiment
    case 'Blinder_y'
        models = [306 307 308 309 310 311 312 313 401 404 405 406 407 408];
        set_axis = [-1.05 1.05 970 1020];
        
    case 'Blinder_beta'
        models = -[301 302 303 304 305 314 315 316 317 318 319 320 ...
                    321 322 323 324 325 326 327 328  330 331 332 333 334 335 336 337];
                %329
        set_axis = [0 1.4 974 978];
        
    case 'Blinder_kappa';
        models = -[201 202 203 204 205 206 207 208 209 210 211 212 ...
                    213 214 215 216 217 218 219 220 221 222 ]; %223 special one
        set_axis = [0.5 1.1 970 985];

    case 'Rogoff_y'
         models = [-105 550 551 552 553 554];
         set_axis = [0.9 4.1 1012 1017];
        
    case 'Rogoff_beta'
        %models = [ -105 501 502 503 504 505 506 507 508 509];
        models = [-105 501 502 503 507 508 509];
        set_axis = [5 11 1010 1020];
        
    case 'Rogoff_kappa'
        models = -[1 101 102 103 104 105     107     110 111 112 113 114];
        set_axis = [0.7 1.1 1010 1035];
end


%%

for i=1:size(models,2)
    
   
    
    disp('**************************************************')
    model = models(i);fprintf('model=%i \n',model)
    
switch_back=0;
if model<0
    model=-model;
    switch_back=1;
end
     
    fprintf('loaded: ')
    
    target=strcat(target_dir,'parameters\Parameters_',num2str(model),'.mat');
    load(target,'parameters');fprintf('parameters, ');

    target = strcat(target_dir,'Pmat\Pun_matrix_',num2str(model),'.mat');
    load(target); fprintf('Pmat, ')
    

    target = strcat(target_dir,'R_reg\R_reg_matrix_',num2str(model),'.mat');
    load(target); fprintf('R_reg, ')
    
if switch_back
    model=-model;
end

    target=strcat(target_dir,'results\results_',num2str(model),'.mat');
    load(target,'PF','VF');fprintf('results. LOADING done\n');
    
    parameters_unload;
    
    
    
    VF_01(i,:)     = VF(1,:);
    VF_no_con(i,:) = VF(2,:);
    VF_conCH(i,:)  = VF(3,:);    
    VF_conLI(i,:)  = VF(4,:);   
    VF_conCH2(i,:) = VF(5,:);    
    VF_conLI2(i,:) = VF(6,:);     


    EVF_no_con(i) = evaluateEVF(epsilon, VF(2,:),int_method);
    EVF_conCH(i)  = evaluateEVF(epsilon, VF(3,:),int_method);
    EVF_conLI(i)  = evaluateEVF(epsilon, VF(4,:),int_method);
    EVF_conCH2(i) = evaluateEVF(epsilon, VF(5,:),int_method);
    EVF_conLI2(i) = evaluateEVF(epsilon, VF(6,:),int_method);
    
    
    PF_01(i,:)     = PF(1,:);
    PF_no_con(i,:) = PF(2,:);
    PF_conCH(i,:)  = PF(3,:);    
    PF_conLI(i,:)  = PF(4,:);   
    PF_conCH2(i,:) = PF(5,:);    
    PF_conLI2(i,:) = PF(6,:);  

    
    axis_kappa(i) = kappa_pos;
    axis_y_target(i) = y_target;
    axis_beta_h(i) = beta_h;
    
    
    y_ND = beta_h/(alpha^2+beta_h)*epsilon;
    inf_ND = alpha/beta_h*y_target - alpha/(alpha^2+beta_h)*epsilon;

    inf_e_D = alpha/beta_h*y_target;


    allocation_inf = @(beta)(alpha  * y_target + alpha^2     *inf_e_D - alpha *epsilon)/(alpha^2+beta);
    allocation_y   = @(beta)(alpha^2* y_target - alpha*beta  *inf_e_D + beta  *epsilon)/(alpha^2+beta);

    for j = 1:size(epsilon,2)
        vector = zeros(size(epsilon)); vector(i)=1; vector=vector';    
        reaction_y(:,j,i)   = allocation_y(beta_h)*vector  +PF(:,i);
        reaction_inf(:,j,i) = allocation_inf(beta_h)*vector+PF(:,i)/alpha;
    end
    
end



%% Value functions
switch model_experiment
    case 'Blinder_y'
        [axis_sorted,IX] = sort(axis_y_target);
        axis_string = 'y^*_{l}';
        legend_string = 'E[V](y^*_l)';
    case 'Blinder_beta'
        [axis_sorted,IX] = sort(axis_beta_h);
        axis_string = '\beta_h';
        legend_string = 'E[V](\beta_h)';
    case 'Blinder_kappa';
        axis_kappa=2-axis_kappa;
        axis_kappa=1./axis_kappa;
        [axis_sorted,IX] = sort(axis_kappa);
        axis_string = '\kappa';
        legend_string = 'E[V](\kappa)';
    case 'Rogoff_kappa'
        axis_kappa=2-axis_kappa;
        axis_kappa=1./axis_kappa;
        [axis_sorted,IX] = sort(axis_kappa);
        axis_string = '\kappa';
        legend_string = 'E[V](\kappa)';
    case 'Rogoff_y'
        [axis_sorted,IX] = sort(axis_y_target);
        axis_string = 'y^*_l';
        legend_string = 'E[V](y^*_l)';
    case 'Rogoff_beta'
        [axis_sorted,IX] = sort(axis_beta_h);
        axis_string = '\beta_{h}';
        legend_string = 'E[V](\beta_{h})';
end




for j = 1:size(IX,2)
    EVF_no_con_sorted(j)= EVF_no_con(IX(j));
    EVF_conCH_sorted(j) = EVF_conCH(IX(j));
    EVF_conLI_sorted(j) = EVF_conLI(IX(j));
    EVF_conCH2_sorted(j) = EVF_conCH2(IX(j));
    EVF_conLI2_sorted(j) = EVF_conLI2(IX(j));       
end




figure_name = 'EVF_';
figure(1)
plot(axis_sorted,[EVF_conCH_sorted;EVF_conCH2_sorted ]','Marker','.','MarkerSize',20)
xlabel(axis_string );ylabel('E[V(\epsilon)]');
legend('EVF\_conCH\_sorted','EVF\_conCH2\_sorted',2);legend('boxoff');
axis(set_axis)

figure(2)
plot(axis_sorted,[EVF_conLI_sorted;EVF_conLI2_sorted ]','Marker','.','MarkerSize',20)
xlabel(axis_string );ylabel('E[V(\epsilon)]');
legend('EVF\_conLI\_sorted','EVF\_conLI2\_sorted',2);legend('boxoff');
axis(set_axis)


figure(3)
plot(axis_sorted,[EVF_conCH2_sorted;EVF_conLI2_sorted]','Marker','.','MarkerSize',20)
xlabel(axis_string );ylabel('E[V(\epsilon)]');
legend('EVF\_conCH2\_sorted','EVF\_conLI2\_sorted',2);legend('boxoff');
axis(set_axis)

figure(4)
plot(axis_sorted,EVF_no_con_sorted,'Marker','.','MarkerSize',20)
xlabel(axis_string);ylabel('E[V(\epsilon)]');legend('EVF\_nocon',2);legend('boxoff')

figure(5)
plot(axis_sorted,[EVF_conLI2_sorted],'Marker','.','MarkerSize',20)
xlabel(axis_string );ylabel('E[V(\epsilon)]');
legend(legend_string,2);legend('boxoff');
axis(set_axis)

if print_graphs
    figuresize(14,10,'centimeters')
    target = strcat(print_exp_dir,figure_name,model_experiment,'.pdf');
    print(gcf, '-dpdf', '-r100', target);
end


