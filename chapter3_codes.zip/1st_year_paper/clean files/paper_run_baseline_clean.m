clear all;clc;

set(0,'DefaultFigureWindowStyle','docked');
target='C:\Users\Filip Rozsypal\Documents\Cambridge\1st_year_paper_proposal\';

s=RandStream('mt19937ar'); %set the seed
RandStream.setDefaultStream(s);

%% Parameters
global alpha y_star s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target;

% Probability of punishment matrix
load_Pmat = 0;  %1 for loading Pmatrix, 0 for computing
N_sim = 200;    % number of noise shock to simulate in order to compute the probability of punishment
save_matrix = 1;% save Pmatrix or not

tolerance = 1e-12; %tolerance in value function iteration
d_grid = -10:0.01:10;   %grid for the deviations

%CB preference
beta_l = 1;    %-> high inflation expectations
beta_h = 8;     %->low inflation expectations

%PC parameter
alpha  = 0.9; %slope of PC curve
y_star = 4; %output target
%variances
s_eps = 2.5;  %std of supply shock
s_inf = 0.2;  %std of inflation noise
s_y   = 1;  %std of output noise

delta = 0.99;; %CB discount factor

kappa_pos = 0.8; %revison constant    
kappa_neg = 2-kappa_pos; %revison constant for negative loglikelihood

% bounds on region for Pmatrix
y_min   =  -16;  y_step   =   0.025;  y_max   =   15;
inf_min =  -10;  inf_step =   0.025;  inf_max =   15;

%grid for state variable in value function iteration
epsilon = -14:0.025:14;



%%
model=104;

    
%% Obtain probability of rejection
disp('Obtain probability of rejection...')
if load_Pmat
    %cd('C:\Users\Filip Rozsypal\Documents\MATLAB\macro\1st_year_paper\Pmat');
    cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\Pmat');
    target = strcat('Pun_matrix_',num2str(model),'.mat');
    load(target); disp('loaded.')
else
   [Prob,Prob_y,Prob_inf] = Pmatrix(N_sim,y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix,model);
end



%% No rejection region
disp('Obtain no rejection region...');
if load_Pmat
    %cd('C:\Users\Filip Rozsypal\Documents\MATLAB\macro\1st_year_paper\R_reg');
    cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\R_reg');
    target = strcat('R_reg_matrix_',num2str(model),'.mat');
    load(target); disp('loaded.')
else
    [Rregion_matrix,~,~] = Rregion(y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix,model);
end



%% Value function iteration
%setup
%int_method = 'gauss_quadrature';     
int_method = 'Simpson';%choose method to compute expected value
constraint = 'yes';  %constrint setup
cutoff = norminv(0.975,0,s_eps);
ind_first = find(epsilon>-cutoff,1, 'first');
ind_last  = find(epsilon>cutoff,1, 'first');

%% 0-1 setup
% 0-0 deviation only, normal value function iteration
method='01';
[VF,PF_01,reaction_y_01,reaction_inf_01] = ...
    Paper_VI_full_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,[],[]);

%continuous deviation, normal value function iteration
method='no_con';
[VF,PF_no_con,reaction_y_no_con,reaction_inf_no_con] = ...
    Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,[],[],constraint,int_method);




figure(1)
plot(epsilon,[PF_no_con;PF_01],'linewidth',2)
axis([-14 14 -3 3])
vline(0,'k');hline(0,'k');vline([-cutoff,cutoff]);
xlabel('\epsilon');ylabel('Policy function');
legend('continuous deviation','0-1 deviation only');legend('boxoff');

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\PF_01','.pdf');
print(gcf, '-dpdf', '-r100', target);



sc_y   = [reaction_y_01(ind_first);reaction_y_01(ind_last);reaction_y_no_con(ind_first);reaction_y_no_con(ind_last)];
sc_inf = [reaction_inf_01(ind_first);reaction_inf_01(ind_last);reaction_inf_no_con(ind_first);reaction_inf_no_con(ind_last)];

figure(2)
get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
plot(reaction_y_01,reaction_inf_01,reaction_y_no_con,reaction_inf_no_con,'linewidth',2);
scatter(sc_y,sc_inf,50,[1;1;2;2],'filled'); hold off;
axis([-12 11 -3 7])
vline(0,'k');hline(0,'k');
xlabel('y');ylabel('\pi');
legend('No rejection area','0-1 deviation only','continuous deviation');legend('boxoff');

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\allocation_01','.pdf');
print(gcf, '-dpdf', '-r100', target);








%% 

%continuous deviation, approximating the policy function by chebyshev
%polynomials and iterating on E[V]    
order = 12;
[theta_init,PF_no_con_fitted] = cheb_estimation(order,PF_no_con,epsilon); %find the starting values  from normal value function iteration


method='con_CHpol';
[VF,PF_conCH,reaction_y_CHpol,reaction_inf_CHpol] = ...
    Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,[],constraint,int_method);


%continuous deviation, approximating the policy function by linear
%approxiamtion and iterating on E[V]       
method='con_LinInt';
grid_eps = min(epsilon):0.5:max(epsilon);
theta_init = interp1(epsilon,PF_no_con,grid_eps); %find starting conditions from normal value function iteration
[VF,PF_conLI,reaction_y_LinInt,reaction_inf_LinInt] = ...
    Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,grid_eps,constraint,int_method);



figure(3)
plot(epsilon,[PF_no_con;PF_conCH;PF_conLI],'linewidth',2)
axis([-14 10 -0.5 3])
vline(0,'k');hline(0,'k');vline([-cutoff,cutoff]);
xlabel('\epsilon');ylabel('Policy function');
legend('standard VFI, no constraint', '12th order Chebyshev pol, with constraint','lin approx, with constraint');legend('boxoff');
title('(Gauss-Hermite quadrature))')

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\PF_constraint_gauss','.pdf');
print(gcf, '-dpdf', '-r100', target);



sc_y   = [reaction_y_no_con(ind_first);reaction_y_no_con(ind_last);
          reaction_y_CHpol(ind_first);reaction_y_CHpol(ind_last);
          reaction_y_LinInt(ind_first);reaction_y_LinInt(ind_last)];

sc_inf   = [reaction_inf_no_con(ind_first);reaction_inf_no_con(ind_last);
          reaction_inf_CHpol(ind_first);reaction_inf_CHpol(ind_last);
          reaction_inf_LinInt(ind_first);reaction_inf_LinInt(ind_last)];

      
yy = [reaction_y_no_con;
      reaction_y_CHpol;
      reaction_y_LinInt]';

  
infinf = [reaction_inf_no_con;
          reaction_inf_CHpol;
          reaction_inf_LinInt]';  
  
      
      
      
figure(4)
get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
plot(yy,infinf,'linewidth',2);
scatter(sc_y,sc_inf,50,[1;1;2;2;3;3],'filled'); hold off;
axis([-12 7 -1 5])
vline(0,'k');hline(0,'k');
xlabel('y');ylabel('\pi');
legend('No rejection area','standard VFI, no constraint', ...
    '12th order Chebyshev pol, with constraint','lin approx, with constraint');legend('boxoff');
title('(Gauss-Hermite quadrature))')

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\allocation_constraint_gauss','.pdf');
print(gcf, '-dpdf', '-r100', target);



%%
int_method = 'Simpson';


%continuous deviation, approximating the policy function by chebyshev
%polynomials and iterating on E[V]    
order = 12;
[theta_init,PF_no_con_fitted] = cheb_estimation(order,PF_no_con,epsilon); %find the starting values  from normal value function iteration


method='con_CHpol';
[VF,PF_conCH,reaction_y_CHpol,reaction_inf_CHpol] = ...
    Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,[],constraint,int_method);


%continuous deviation, approximating the policy function by linear
%approxiamtion and iterating on E[V]       
method='con_LinInt';
grid_eps = min(epsilon):0.5:max(epsilon);
theta_init = interp1(epsilon,PF_no_con,grid_eps); %find starting conditions from normal value function iteration
[VF,PF_conLI,reaction_y_LinInt,reaction_inf_LinInt] = ...
    Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,grid_eps,constraint,int_method);



figure(5)
plot(epsilon,[PF_no_con;PF_conCH;PF_conLI],'linewidth',2)
axis([-14 10 -0.5 3])
vline(0,'k');hline(0,'k');vline([-cutoff,cutoff]);
xlabel('\epsilon');ylabel('Policy function');
legend('standard VFI, no constraint', '12th order Chebyshev pol, with constraint','lin approx, with constraint');legend('boxoff');
title('(Simpson quadrature))')

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\PF_constraint_simpson','.pdf');
print(gcf, '-dpdf', '-r100', target);



sc_y   = [reaction_y_no_con(ind_first);reaction_y_no_con(ind_last);
          reaction_y_CHpol(ind_first);reaction_y_CHpol(ind_last);
          reaction_y_LinInt(ind_first);reaction_y_LinInt(ind_last)];

sc_inf   = [reaction_inf_no_con(ind_first);reaction_inf_no_con(ind_last);
          reaction_inf_CHpol(ind_first);reaction_inf_CHpol(ind_last);
          reaction_inf_LinInt(ind_first);reaction_inf_LinInt(ind_last)];

      
yy = [reaction_y_no_con;
      reaction_y_CHpol;
      reaction_y_LinInt]';

  
infinf = [reaction_inf_no_con;
          reaction_inf_CHpol;
          reaction_inf_LinInt]';  
  
      
      
      
figure(6)
get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
plot(yy,infinf,'linewidth',2);
scatter(sc_y,sc_inf,50,[1;1;2;2;3;3],'filled'); hold off;
axis([-12 7 -1 5])
vline(0,'k');hline(0,'k');
xlabel('y');ylabel('\pi');
legend('No rejection area','standard VFI, no constraint', ...
    '12th order Chebyshev pol, with constraint','lin approx, with constraint');legend('boxoff');
title('(Simpson quadrature))')



figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\allocation_constraint_simpson','.pdf');
print(gcf, '-dpdf', '-r100', target);





