function   [Prob,Prob_y,Prob_inf]=Pmatrix(N_sim,y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix,model)
%Prob...probability of punishment
global alpha y_star s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg target;


seedToSet = RandStream('mcg16807','Seed',1234);
RandStream.setDefaultStream(seedToSet) 

y   = y_min  :y_step  :y_max;
inf = inf_min:inf_step:inf_max;

%generatuing the noise shocks

Xi = [s_y^2 0;0 s_inf^2] * randn(2,N_sim);

%% Probability of deviation
 fprintf('computing "Probability of punishment" matrix:  0%%')

% norevision - 'no revision action is taken', i.e. Punishment NOT triggered
norevision = int8(zeros(size(y,2),size(inf,2),N_sim));

%loglikelihood
loglik = @(Shocks) -(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2))/2 ...
                    - Shocks(1)^2/(2*s_eps^2)-Shocks(2)^2/(2*s_y^2)-Shocks(3)^2/(2*s_inf^2);

%first row deviating, second row no deviation
xi_y_hat   = zeros(2,N_sim);               
xi_inf_hat = zeros(2,N_sim);
eps_hat    = zeros(2,N_sim);
y_hat      = zeros(2,N_sim);
inf_hat    = zeros(2,N_sim);

count = 1;
beeper = floor(size(y,2)*size(inf,2)/10);

for i=1:size(y,2)
    for j=1:size(inf,2)
        
        if mod(count,beeper)==0
            fprintf('\b\b\b\b %u0%%',count/beeper);
        end
        count = count+1;
        
        %skip areas which will not be reached
        if y(i)+inf(j)>52 || y(i)+inf(j)<-52
            norevision(i,j,:)=NaN; 
        else
            X_tilde =[y(i);inf(j)]*ones(1,N_sim)+Xi;
            for ii=1:N_sim
                %low beta - Deviation
                [y_hat(1,ii),inf_hat(1,ii),xi_y_hat(1,ii),xi_inf_hat(1,ii),eps_hat(1,ii)] = ...
                    CSG(X_tilde(1,ii),X_tilde(2,ii),beta_h,beta_l);

                %high beta - NoDeviation
                [y_hat(2,ii),inf_hat(2,ii),xi_y_hat(2,ii),xi_inf_hat(2,ii),eps_hat(2,ii)] = ...
                    CSG(X_tilde(1,ii),X_tilde(2,ii),beta_h,beta_h);
                
                %compare the loglikelihoods
                %note 'loglik(2)' is loglikelihood of NOT DEVIATING
                
                if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > 0 %check for the sign
                    disp('ll>0')
                    if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > ...
                            kappa_pos*loglik([eps_hat(1,ii) xi_y_hat(1,ii) xi_inf_hat(1,ii)])
                        norevision(i,j,ii) = 1;
                    end
                else
                    if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > ...
                            kappa_neg*loglik([eps_hat(1,ii) xi_y_hat(1,ii) xi_inf_hat(1,ii)])
                        norevision(i,j,ii) = 1;
                    end
                end
            end 
        end
    end
end

Prob = 1-sum(norevision,3)/size(norevision,3); %Probability of Punishment


Prob_y   = y;
Prob_inf = inf;
if save_matrix
    %cd('C:\Users\Filip Rozsypal\Documents\MATLAB\macro\1st_year_paper\Pmat');
    cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\Pmat');
    target = strcat('Pun_matrix_',num2str(model),'.mat');
    save(target,'Prob','Prob_y','Prob_inf'); disp('(P matrix saved)');
end
disp('done...')


    %CSG:Constrained Signal Extraction
    function [y_hat,inf_hat,xi_y_hat,xi_inf_hat,eps_hat] = CSG(y,inf,beta_old,beta_new)
        global alpha y_star s_inf s_y s_eps;
        
        if beta_old==beta_new  %correct beliefs (=not deviated) 
            beta=beta_old;
            const = -s_y^2*s_inf^2*s_eps^2*(alpha^2+beta)/ ...
                (s_inf^2*s_y^2*(alpha^2+beta)^2+s_y^2*s_eps^2*alpha^2+s_inf^2*s_eps^2*beta^2);
            eps_hat = const * ( -alpha^2/(beta*s_inf^2)*y_star + alpha/s_inf^2*inf - beta/s_y^2*y);

            xi_inf_hat = inf - alpha/beta*y_star + alpha/(alpha^2+beta)*eps_hat;
            xi_y_hat   = y - beta/(alpha^2+beta)*eps_hat;

            inf_hat = alpha/beta*y_star - alpha/(alpha^2+beta)*eps_hat;
            y_hat   = beta/(alpha^2+beta)*eps_hat;
        else %incorrect beliefs (=deviated)     
            inf_e = alpha/beta_old*y_star;
            const = (alpha^2+beta_new)/ ...
                ( (alpha^2+beta_new)^2*s_inf^2*s_y^2+alpha^2*s_y^2*s_eps^2+beta_new^2*s_inf^2*s_eps^2);

            eps_hat = const * ( ...
                -alpha*s_eps^2*s_y^2*(inf-alpha/(alpha^2+beta_new)*y_star-alpha^2/(alpha^2+beta_new)*inf_e) ...
                +beta_new*s_inf^2*s_eps^2*(y-alpha^2/(alpha^2+beta_new)*y_star-alpha*beta_new/(alpha^2+beta_new)*inf_e) ...
                );

            inf_hat = (alpha  * y_star + alpha^2       *inf_e - alpha   *eps_hat)/(alpha^2+beta_new);
            y_hat   = (alpha^2* y_star - alpha*beta_new*inf_e + beta_new*eps_hat)/(alpha^2+beta_new);

            xi_inf_hat = inf - inf_hat;
            xi_y_hat   = y - y_hat;
        end
    end
end
