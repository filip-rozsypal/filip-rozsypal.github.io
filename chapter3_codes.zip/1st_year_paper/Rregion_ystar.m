function [Rregion_matrix,Rregion_y,Rregion_inf] = Rregion_ystar(y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix,model)
    global alpha y_star y_target s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg target_folder;


    inf_e_D = alpha/beta_h*y_target;

    epsilon = -12:0.25:12;
    % allocation_inf = @([beta,y])(alpha  * y_star + alpha^2     *inf_e_D - alpha *epsilon)/(alpha^2+beta);
    % allocation_y   = @([beta,y])(alpha^2* y_star - alpha*beta  *inf_e_D + beta  *epsilon)/(alpha^2+beta);


    y   = y_min  :y_step  :y_max;
    Rregion_y = y;

    inf = inf_min:inf_step:inf_max;
    Rregion_inf = inf;

    norevision = zeros(size(y,2),size(inf,2));

    loglik=@(Shocks) -(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2))/2 ...
                        - Shocks(1)^2/(2*s_eps^2)-Shocks(2)^2/(2*s_y^2)-Shocks(3)^2/(2*s_inf^2);


    xi_y_hat   = zeros(2,1);               
    xi_inf_hat = zeros(2,1);
    eps_hat    = zeros(2,1);
    y_hat      = zeros(2,1);
    inf_hat    = zeros(2,1);                

    fprintf('computing "Probability of punishment" matrix:  0%%')

    beeper=floor(size(y,2)*size(inf,2)/10);
    count=1;

    %figure(203)
    for i=1:size(y,2)
        for j=1:size(inf,2)

            if mod(count,beeper)==0
                fprintf('\b\b\b\b %u0%%',count/beeper);
            end
            count=count+1;

            X_tilde =[y(i);inf(j)];

            %Deviation
            [y_hat(1),inf_hat(1),xi_y_hat(1),xi_inf_hat(1),eps_hat(1)] = Signal_extraction_D(X_tilde(1),X_tilde(2));
            %plot(y_hat(1),inf_hat(1),'.','color','black');hold on;

            %hNoDeviation
            [y_hat(2),inf_hat(2),xi_y_hat(2),xi_inf_hat(2),eps_hat(2)] = Signal_extraction_ND(X_tilde(1),X_tilde(2));
            %plot(y_hat(2),inf_hat(2),'.','color','black');hold on;

            if loglik([eps_hat(2) xi_y_hat(2) xi_inf_hat(2)]) > 0
                disp('ll>0')
                if loglik([eps_hat(2) xi_y_hat(2) xi_inf_hat(2)]) > ...
                        kappa_pos*loglik([eps_hat(1) xi_y_hat(1) xi_inf_hat(1)])
                    norevision(i,j) = 1;
                end
            else
                if loglik([eps_hat(2) xi_y_hat(2) xi_inf_hat(2)]) > ...
                        kappa_neg*loglik([eps_hat(1) xi_y_hat(1) xi_inf_hat(1)])
                    norevision(i,j) = 1;
                    %plot(X_tilde(1),X_tilde(2),'.','color','r','MarkerSize',10);hold on;
                else
                    %plot(X_tilde(1),X_tilde(2),'.','color','b');hold on;
                end

            end
        end
    end

%     axis([y_min y_max inf_min inf_max])
%     xlabel('y'); ylabel('\pi'); 
%     hline(0,'-k');vline(0,'-k');
%     plot(allocation_y(epsilon,beta_h,y_target,inf_e_D),allocation_inf(epsilon,beta_h,y_target,inf_e_D),'k'); hold on;
%     plot(allocation_y(epsilon,beta_l,y_star,inf_e_D),allocation_inf(epsilon,beta_l,y_star,inf_e_D),'k'); hold on;
%     hold off;

     fprintf('  done\n');

    Rregion_matrix =  norevision;

    if save_matrix
        target=strcat(target_folder,'R_reg\R_reg_matrix_',num2str(model),'.mat');
        save(target,'Rregion_matrix');disp('(NoRejection matrix saved saved)');
    end

    function inf = allocation_inf(epsilon,beta,yy,inf_e)
        inf = (alpha  * yy + alpha^2     *inf_e - alpha *epsilon)/(alpha^2+beta);
    end
    
    function y = allocation_y(epsilon,beta,yy,inf_e)
        y   = (alpha^2* yy - alpha*beta  *inf_e + beta  *epsilon)/(alpha^2+beta);
    end




end
 








