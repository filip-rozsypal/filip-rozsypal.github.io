
N_sim=10000;
hist2=zeros(101,101);

Xi = [3^2 0;0 3^2] * randn(2,N_sim);

    

for i=-50:50
    for j=-50:50
        for l=1:N_sim
            if Xi(1,l)>i-0.5 && Xi(1,l)<i+0.5 && Xi(2,l)>j-0.5 && Xi(2,l)<j+0.5
                hist2(i+51,j+51)=hist2(i+51,j+51)+1;
            end
        end
    end
end

hist2=hist2/N_sim;
mesh(hist2)        