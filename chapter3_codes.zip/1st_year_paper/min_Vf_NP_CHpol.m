



function  [V_NP_new,PF,theta_solution] = ...
    min_Vf_NP_CHpol(delta, EV_NP, EV_P,Prob_matrix,y_grid,inf_grid,theta_init,beta_h,beta_l,alpha,y_star,y_target,s_eps,epsilon,~,constraint,int_method,turn_off_the_switch)

    
    
    [nodes, weights] = GaussHermite(12);
    nodes=nodes';

    
    %functions
    allocation_y   = @(epsilon,theta)                         beta_h/(alpha^2+beta_h)*epsilon + PF_approx(theta,epsilon)      ;
    allocation_inf = @(epsilon,theta) alpha/beta_h*y_target -  alpha/(alpha^2+beta_h)*epsilon + PF_approx(theta,epsilon)/alpha; 

    loss = @(epsilon,theta) 0.5*(allocation_y(epsilon,theta)-y_star).^2+beta_l/2*allocation_inf(epsilon,theta).^2;


    [y_mgrid inf_mgrid] = meshgrid(y_grid,inf_grid);
    Probability = @(epsilon,theta) ...
        interp2( ...
                    y_mgrid,inf_mgrid,Prob_matrix',allocation_y(epsilon,theta),...
                    allocation_inf(epsilon,theta), ...
                '*linear',1);

    value =  @(epsilon,theta) loss(epsilon,theta)+ ...
        delta*( Probability(epsilon,theta)*EV_P + ( 1 - Probability(epsilon,theta) )*EV_NP );


  
    

    % epsilon for which the two expansion paths intersect
    %reverse_cutpoint = (alpha^2+beta_h)/beta_h*(y_target);   works only for y_star=y_target
    
    if beta_h/beta_l>1
        cutoff_case = 'higher';
    end
    if beta_h/beta_l==1
        cutoff_case = 'equal';
    end
    if beta_h/beta_l<1
        cutoff_case = 'lower';
    end
    
    if turn_off_the_switch
        cutoff_case = 'equal';
    end

  reverse_cutpoint = (y_star*beta_h-y_target*beta_l)/(beta_h-beta_l)*(alpha^2+beta_h)/beta_h;

    switch  int_method
        case 'gauss_quadrature'
            switch cutoff_case
                case 'higher'                   
                    reverse_dev = ones(size(nodes))-2*(sqrt(2)*s_eps*nodes>reverse_cutpoint);
                case 'equal'
                    reverse_dev = ones(size(nodes));
                case 'lower'
                    reverse_dev = ones(size(nodes))-2*(sqrt(2)*s_eps*nodes<reverse_cutpoint);
            end           
            ed_weights = weights.*reverse_dev';
            
            EV    = @(theta) 1/sqrt(pi)* value(sqrt(2)*s_eps.*nodes,theta)*weights;
            E_dev = @(theta) 1/sqrt(pi)* PF_approx(theta,sqrt(2)*s_eps*nodes)*ed_weights;
        
        case 'Simpson'            
            switch cutoff_case
                case 'higher'                  
                    reverse_dev = ones(size(epsilon))-2*(epsilon>reverse_cutpoint);
                case 'equal'
                    reverse_dev = ones(size(epsilon));
                case 'lower'
                    reverse_dev = ones(size(epsilon))-2*(epsilon<reverse_cutpoint);  
            end  
            
            EV    = @(theta) simpson_int_norm(epsilon,value(epsilon,theta),0,s_eps);    
            E_dev = @(theta) simpson_int_norm(epsilon,PF_approx(theta,epsilon).*reverse_dev,0,s_eps);
    end
    
    %expected_deviation = @(theta) 1/sqrt(pi)* PF_approx(theta,sqrt(2)*s_eps*nodes)*ed_weights;

  % [x,fval] = fminunc(expected_value,[0,0])


    A   = [];
    b   = [];
    Aeq = [];
    beq = [];
    lb  = [];
    ub  = [];

    
   options = optimset('TolFun',1e-9,'TolX',1e-9,'MaxFunEvals',15000,'Display','notify-detailed','algorithm','interior-point');
  
   
   switch constraint
       case 'yes'
           theta_solution = fmincon(EV,theta_init,A,b,Aeq,beq,lb,ub,@mycon,options);
       case 'no'
           theta_solution = fminsearch(EV,theta_init,options);
   end

   PF       = PF_approx(theta_solution,epsilon);
   V_NP_new = value(epsilon,theta_solution);
   
   
   
    %define the nonlinear constraint
    function [c,ceq] = mycon(theta)
        c = [];                             % Compute nonlinear inequalities at x.
        ceq = E_dev(theta);    % Compute nonlinear equalities at x.
    end

    function fval = PF_approx(theta,xx)
        %xx row vector
        
        X_min = min(xx);
        X_max = -X_min; %because the hermite nodes are symetric
         
        x = xx/(X_max-X_min);
        if size(xx,1)==1
            x=x';
        end
        
        theta_sw = fliplr(theta);
        
        Her_matrix = ones(size(theta_sw,2),size(x,1));
        Her_matrix(2,:) = x';
        
        for i=2:size(theta_sw,2)-1
            Her_matrix(i+1,:) = 2*x'.*Her_matrix(i,:)-Her_matrix(i-1,:);
        end
        
        fval = theta*Her_matrix;
        
    end
        
        
    function fval=gausian_quadrature(x,fx,s_eps,nodes)
        fval = 1/sqrt(pi)*weights'* interp1(x,fx,(sqrt(2)*s_eps.*nodes),'linear','extrap');
    end

end


















