

close all;clear all;clc;

global alpha y_star y_target s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target_dir;

target_dir='F:\matlab\1st_year_paper\';
pic_save_dir = 'C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper\fig\';
print_fig = 1;


s_eps = 2.5;
epsilon = -14:0.05:14;
cutoff = norminv(0.975,0,s_eps);
ind_first = find(epsilon>-cutoff,1, 'first');
ind_last  = find(epsilon>cutoff,1, 'first');


model_name = 'model1';
pic_save_dir = 'C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper\fig\';

int_method = 'Simpson';


% model_name = 'Blinder_beta';
%  model_name = 'Blinder_kappa';
% model_name = 'Blinder_y';

% model_name = 'Rogoff_beta';
 model_name = 'Rogoff_kappa';
% model_name = 'Rogoff_y';


switch model_name
    case 'Blinder_kappa'
        model_set =[-215 -201 -205 -208 -212];
        PF_axis = [-10 10 -0.8 0.6];
        Allocation_axis = [-5 5 -3 3];
        VF_axis = [-12 12 950 1050  ];
        figure_name = 'Blinder_kappa';
     case 'Rogoff_kappa'
        model_set =[ -101  -105 -115 -108 -112];
        PF_axis = [-10 10 -0.8 0.6];
        Allocation_axis = [-5 5 -3 3];
        VF_axis = [-12 12 950 1050  ];
        figure_name = 'Blinder_kappa';
end




variable = 'kappa';
hold off;
counter = 0;
model_legend = {};
for model = model_set
    counter = 1+counter;
    fprintf('****************************************************************\n')
    fprintf('model %i :loaded: ',model)
    

switch_back=0;
if model<0
    model=-model;
    switch_back=1;
end    

    
    target=strcat(target_dir,'parameters\Parameters_',num2str(model),'.mat');
    load(target,'parameters');fprintf('parameters, ');
    parameters.kappa=parameters.kappa_pos;

    var_string = strcat('parameters.',variable);
    model_legend = [model_legend;strcat('\',variable,'=',num2str(eval(var_string)))];
    
    target = strcat(target_dir,'Pmat\Pun_matrix_',num2str(model),'.mat');
    load(target); fprintf('Pmat, ')


    target = strcat(target_dir,'R_reg\R_reg_matrix_',num2str(model),'.mat');
    load(target); fprintf('R_reg, ')


if switch_back
    model=-model;
end    
    
    target=strcat(target_dir,'results\results_',num2str(model),'.mat');
    load(target,'PF','VF');fprintf('results. LOADING done\n');

    parameters_unload;



    VF_01(counter,:)     = VF(1,:);
    VF_no_con(counter,:)  = VF(2,:);

    VF_conCH(counter,:)   = VF(3,:);    
    VF_conLI(counter,:)   = VF(4,:);   

    VF_conCH2(counter,:)   = VF(5,:);    
    VF_conLI2(counter,:)   = VF(6,:);


    PF_01(counter,:)     = PF(1,:);
    PF_no_con(counter,:)  = PF(2,:);

    PF_conCH(counter,:)  = PF(3,:);    
    PF_conLI(counter,:)   = PF(4,:);   

    PF_conCH2(counter,:)   = PF(5,:);    
    PF_conLI2(counter,:)   = PF(6,:);
    
    figure(5)
    area_handle(counter) = get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
end
hold off;
%%





y_ND = beta_h/(alpha^2+beta_h)*epsilon;
inf_ND = alpha/beta_h*y_target - alpha/(alpha^2+beta_h)*epsilon;

y_D = beta_l/(alpha^2+beta_l)*epsilon;
inf_D = alpha/beta_l*y_star - alpha/(alpha^2+beta_l)*epsilon;

PF_D = alpha^2/(alpha^2+beta_l)*(y_star-beta_l/beta_h*y_target)...
        +( beta_l/(alpha^2+beta_l) -   beta_h/(alpha^2+beta_h) )*epsilon;

inf_e_D = alpha/beta_h*y_target;


allocation_inf = @(beta)(alpha  * y_target + alpha^2     *inf_e_D - alpha *epsilon)/(alpha^2+beta);
allocation_y   = @(beta)(alpha^2* y_target - alpha*beta  *inf_e_D + beta  *epsilon)/(alpha^2+beta);

for i = 1:size(epsilon,2)
    vector = zeros(size(epsilon)); vector(i)=1; vector=vector'; 

    reaction_y_no_con(:,i)   = ones(counter,1)*allocation_y(beta_h)*vector  +PF_no_con(:,i);
    reaction_inf_no_con(:,i) = ones(counter,1)*allocation_inf(beta_h)*vector+PF_no_con(:,i)/alpha;

    reaction_y_conCH(:,i)   = ones(counter,1)*allocation_y(beta_h)*vector  +PF_conCH(:,i);
    reaction_inf_conCH(:,i) = ones(counter,1)*allocation_inf(beta_h)*vector+PF_conCH(:,i)/alpha;

    reaction_y_conCH2(:,i)   = ones(counter,1)*allocation_y(beta_h)*vector  +PF_conCH2(:,i);
    reaction_inf_conCH2(:,i) = ones(counter,1)*allocation_inf(beta_h)*vector+PF_conCH2(:,i)/alpha;

    reaction_y_conLI(:,i)   = ones(counter,1)*allocation_y(beta_h)*vector  +PF_conLI(:,i);
    reaction_inf_conLI(:,i) = ones(counter,1)*allocation_inf(beta_h)*vector+PF_conLI(:,i)/alpha;

    reaction_y_conLI2(:,i)   = ones(counter,1)*allocation_y(beta_h)*vector  +PF_conLI2(:,i);
    reaction_inf_conLI2(:,i) = ones(counter,1)*allocation_inf(beta_h)*vector+PF_conLI2(:,i)/alpha;

    reaction_y_01(:,i)   = ones(counter,1)*allocation_y(beta_h)*vector  +PF_01(:,i);
    reaction_inf_01(:,i) = ones(counter,1)*allocation_inf(beta_h)*vector+PF_01(:,i)/alpha;
end   

%%

% compare Value functions
figure(1)
compare_x = [epsilon];
compare_y = [VF_conLI2]';

plot(compare_x,compare_y,'linewidth',3);
legend(model_legend);legend('boxoff')
axis(VF_axis);


%%

% compare policy functions functions, Linear
figure(2)
compare_x = [epsilon];
compare_y = [PF_conLI2]';
hl=plot(compare_x,compare_y,'linewidth',3);
legend(model_legend,2);legend('boxoff');
xlabel('\epsilon');ylabel('d(\epsilon)');
axis(PF_axis);
ll=hline(0,'-k');lll=vline([-cutoff cutoff]); llll=vline(0,'-k');
set(hl(1),'linestyle',':');
set(hl(2),'linestyle','--');
set(hl(4),'linestyle','-.');set(hl(1),'Color','r');
set(hl(3),'linestyle','-');set(hl(3),'Color','b');
set(hl(5),'linestyle',':');
l=[ll lll llll];
set(l,'linewidth',2,'color','k');
set(gca,'XTick',-10:2:10);

% compare policy functions functions, Chebyshev
figure(3)
compare_x = [epsilon];
compare_y = [PF_conCH2]';
hl=plot(compare_x,compare_y,'linewidth',3);
legend(model_legend,2);legend('boxoff');
xlabel('\epsilon');ylabel('d(\epsilon)');
ll=hline(0,'-k');lll=vline([-cutoff cutoff]); llll=vline(0,'-k');
axis(PF_axis);
set(hl(1),'linestyle',':');
set(hl(2),'linestyle','--');
set(hl(4),'linestyle','-.');set(hl(1),'Color','r');
set(hl(3),'linestyle','-');set(hl(3),'Color','b');
set(hl(5),'linestyle',':');
l=[ll lll llll];
set(l,'linewidth',2,'color','k');
set(gca,'XTick',-10:2:10);


% compare allocations using LI
figure(4)
compare_x = [reaction_y_conLI2]';
compare_y = [reaction_inf_conLI2]';
plot(compare_x,compare_y,'linewidth',3);
legend(model_legend);legend('boxoff');
axis(Allocation_axis)
hline(0);vline(0)


% compare allocations using LI
figure(5)
col     = 1-(0.1:0.8/(counter-1):0.9).^2;
col_mat = [zeros(size(col))' col' col'];
for i=1:counter
    set(area_handle(i),'facecolor',col_mat(i,:));
end
legend(model_legend);legend('boxoff');
axis(Allocation_axis);
xlabel('y');ylabel('\pi');
set(gca,'XTick',-5:1:5);
vline(0,'-k');hline(0,'-k');
%%
if print_fig
    
    figure(2)
    figuresize(15,10,'centimeters')
    target=strcat(pic_save_dir,model_name,'_rob_LI','.pdf');
    print(gcf, '-dpdf', '-r300', target);
    
    figure(3)
    figuresize(15,10,'centimeters')
    target=strcat(pic_save_dir,model_name,'_rob_CH','.pdf');
    print(gcf, '-dpdf', '-r300', target);
    
    figure(5)
    figuresize(13,13,'centimeters')
    target=strcat(pic_save_dir,model_name,'_rob_kappa','.pdf');
    print(gcf, '-dpdf', '-r300', target);


end








