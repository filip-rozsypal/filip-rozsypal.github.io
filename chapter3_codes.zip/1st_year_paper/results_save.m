

      PF = [PF_01;
            PF_no_con;
            PF_conCH;
            PF_conLI;
           PF_conCH2;
           PF_conLI2];


      VF =  [VF_01;
             VF_no_con;
             VF_conCH;
             VF_conLI;
             VF_conCH2;
           VF_conLI2];
         

if save_matrix
    target=strcat(target_dir,'results\results_',num2str(model),'.mat');
    save(target,'PF','VF');disp('(PF and VF saved)');
end         