

clear all;clc;

global alpha y_star y_target s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target;

int_method = 'Simpson';
int_method = 'gauss_quadrature';

models = 4;

pause on;

fprintf('beta_h \t beta_l \t kappa \t y_targer\n')

for i=1:size(models,2)
    model = models(i);    
    
    cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\parameters')
    target=strcat('Parameters_',num2str(model),'.mat');
    load(target,'parameters');%disp('Parameters loaded');

    cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\Pmat');
    target = strcat('Pun_matrix_',num2str(model),'.mat');
    load(target); %disp('loaded.')
    
    cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\R_reg');
    target = strcat('R_reg_matrix_',num2str(model),'.mat');
    load(target); %disp('loaded.')
    
    cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\results')
    target=strcat('results_',num2str(model),'.mat');
    load(target,'PF','VF'); %disp('PF and VF loaded');
    
    parameters_unload;
    

    
    fprintf(' %1.1f \t %1.1f \t\t %1.1f \t %1.1f \n', [beta_h kappa_pos  beta_l y_target]    )
    

 

 
    
    pause
    
%           VF =  [VF_01(counter,:);
%              VF_no_con(counter,:);
%              VF_conCH(counter,:);
%              VF_conLI(counter,:);
%              VF_conCH2(counter,:);
%              VF_conLI2(counter,:)];   


    EVF_no_con(i) = evaluateEVF(epsilon, VF(2,:),int_method);
    EVF_conLI(i) = evaluateEVF(epsilon, VF(4,:),int_method);
    EVF_conCH(i) = evaluateEVF(epsilon, VF(3,:),int_method);
    axis_kappa(i) = kappa_pos;
end


[axis_kappa_sorted,IX] = sort(axis_kappa);
for j = 1:size(IX,2)
    EVF_no_con_sorted(j)= EVF_no_con(IX(j));
    EVF_conCH_sorted(j) = EVF_conCH(IX(j));
    EVF_conLI_sorted(j) = EVF_conLI(IX(j));    
end


plot(axis_kappa,EVF_conLI,'*')
plot(axis_kappa,EVF_conLI,'-r',axis_kappa,EVF_conCH,'*')
plot(axis_kappa,EVF_no_con,'*')    
    

% 
% PF_01     = PF(1,:);
% PF_no_con = PF(2,:);
% PF_conLI2  = PF(4,:);
% PF_conCH  = PF(3,:);
% 
% VF_01     = VF(1,:);
% VF_no_con = VF(2,:);
% VF_conLI2  = VF(4,:);
% VF_conCH  = VF(3,:);  

% plot(axis_kappa_sorted,[EVF_conLI_sorted; EVF_conCH_sorted],'Marker','.','MarkerSize',20)
% legend('Linear approximation','12th order Chebyshev polynomial approximation');legend('boxoff')
% ylabel('E[V]');
% xlabel('\beta_{high}');


% figuresize(14,10,'centimeters')
% %target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
% target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper\fig\EVF','.pdf');
% print(gcf, '-dpdf', '-r100', target);


plot(axis_kappa_sorted,[EVF_conLI_sorted; EVF_conCH_sorted],'Marker','.','MarkerSize',20)
legend('Linear approximation','12th order Chebyshev pol. approx');legend('boxoff')
ylabel('E[V]');
xlabel('\kappa');

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper\fig\EVF_kappa','.pdf');
print(gcf, '-dpdf', '-r100', target);




%%


figure(1)
plot(epsilon,[PF_no_con;PF_01],'linewidth',2)
axis([-14 14 -3 3])
vline(0,'k');hline(0,'k');vline([-cutoff,cutoff]);
xlabel('\epsilon');ylabel('Policy function');
legend('continuous deviation','0-1 deviation only');legend('boxoff');

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper\fig\PF_01','.pdf');
print(gcf, '-dpdf', '-r100', target);



sc_y   = [reaction_y_01(ind_first);reaction_y_01(ind_last);reaction_y_no_con(ind_first);reaction_y_no_con(ind_last)];
sc_inf = [reaction_inf_01(ind_first);reaction_inf_01(ind_last);reaction_inf_no_con(ind_first);reaction_inf_no_con(ind_last)];

figure(2)
get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
plot(reaction_y_01,reaction_inf_01,reaction_y_no_con,reaction_inf_no_con,'linewidth',2);
scatter(sc_y,sc_inf,50,[1;1;2;2],'filled'); hold off;
axis([-12 11 -3 7])
vline(0,'k');hline(0,'k');
xlabel('y');ylabel('\pi');
legend('No rejection area','0-1 deviation only','continuous deviation');legend('boxoff');

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper\fig\allocation_01','.pdf');
print(gcf, '-dpdf', '-r100', target);


%%
figure(3)
plot(epsilon,[PF_no_con;PF_conCH;PF_conLI2],'linewidth',2)
axis([-14 10 -0.75 2.5])
vline(0,'k');hline(0,'k');vline([-cutoff,cutoff]);
xlabel('\epsilon');ylabel('Policy function');
legend('standard VFI, no constraint', '12th order Chebyshev pol, with constraint','lin approx, with constraint');legend('boxoff');


figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper\fig\PF_constraint_gauss','.pdf');
print(gcf, '-dpdf', '-r100', target);


%%



sc_y   = [reaction_y_no_con(ind_first);reaction_y_no_con(ind_last);
          reaction_y_CHpol(ind_first);reaction_y_CHpol(ind_last);
          reaction_y_LinInt2(ind_first);reaction_y_LinInt2(ind_last)];

sc_inf   = [reaction_inf_no_con(ind_first);reaction_inf_no_con(ind_last);
          reaction_inf_CHpol(ind_first);reaction_inf_CHpol(ind_last);
          reaction_inf_LinInt2(ind_first);reaction_inf_LinInt2(ind_last)];

      
yy = [reaction_y_no_con;
      reaction_y_CHpol;
      reaction_y_LinInt2]';

  
infinf = [reaction_inf_no_con;
          reaction_inf_CHpol;
          reaction_inf_LinInt2]';  
  
      
      
      
figure(4)
get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
plot(yy,infinf,'linewidth',2);
scatter(sc_y,sc_inf,50,[1;1;2;2;3;3],'filled'); hold off;
axis([-12 7 -1 5])
vline(0,'k');hline(0,'k');
xlabel('y');ylabel('\pi');
legend('No rejection area','standard VFI, no constraint', ...
    '12th order Chebyshev pol, with constraint','lin approx, with constraint');legend('boxoff');


figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper\fig\allocation_constraint_gauss','.pdf');
print(gcf, '-dpdf', '-r100', target);

