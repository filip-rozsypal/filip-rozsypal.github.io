
function EVF=evaluateEVF(epsilon,VF,int_method)
    global  s_eps;
    order = 12;





    switch  int_method
        case 'gauss_quadrature'
            EVF = gaussian_quadrature(epsilon,VF,s_eps,order);
        case 'Simpson'       
            EVF = simpson_int_norm(epsilon,VF,0,s_eps);
    end




    function fval=gaussian_quadrature(x,fx,s_eps,order)
        [nodes, weights] = GaussHermite(order);
        fval = 1/sqrt(pi)*weights'* interp1(x,fx,(sqrt(2)*s_eps.*nodes),'linear','extrap');
    end


end