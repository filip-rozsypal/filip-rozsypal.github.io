
% unload the parameters of the current model from parameters. structure


load_Pmat   = parameters.load_Pmat;
N_sim       = parameters.N_sim;
save_matrix = parameters.save_matrix;

tolerance = parameters.tolerance;
d_grid   = parameters.d_grid;

alpha   = parameters.alpha;

beta_l = parameters.beta_l;
y_star = parameters.y_star;
delta  = parameters.delta;


s_eps = parameters.s_eps;
s_inf = parameters.s_inf;
s_y   = parameters.s_y ;



kappa_pos = parameters.kappa_pos;
kappa_neg = parameters.kappa_neg;


y_min  = parameters.y_min ;
y_step = parameters.y_step ;
y_max  = parameters.y_max;

inf_min  = parameters.inf_min;
inf_step = parameters.inf_step ;
inf_max  = parameters.inf_max;

epsilon = parameters.epsilon;

beta_h   = parameters.beta_h;
y_target = parameters.y_target;  

model = parameters.model;


