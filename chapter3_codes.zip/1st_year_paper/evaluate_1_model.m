

clear all;clc; close all;
set(0,'DefaultFigureWindowStyle','docked');

global alpha y_star y_target s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target_dir;

target_dir = 'F:\matlab\1st_year_paper\';

print_fig = 1;

model_name   = 'model1';
pic_save_dir = 'C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper\fig\';

int_method = 'Simpson';

s_eps = 2.5;
epsilon = -14:0.05:14;
cutoff = norminv(0.975,0,s_eps);
ind_first = find(epsilon>-cutoff,1, 'first');
ind_last  = find(epsilon>cutoff,1, 'first');


%%
% %model 1
% model = 1;
% model_name = 'model1';
% axis_model_PF         = [-10 10 -0.75 2];
% axis_model_allocation = [-7 7 -1 3];


%model 2
% model = 2;
% model_name = 'model2';
% axis_model_PF         =[-10 10 -0.5 1];
% axis_model_allocation = [-7 7 -5 5];


% % Blinder
% model = 205;
% model_name = 'model205';
% axis_model_PF         =[-10 10 -1 2];
% axis_model_allocation = [-5 5 -3 3];
% axis_robust = [-10 10 -1 1];


% % Blinder
% model = -205;
% model_name = 'model-205';
% axis_model_PF         =[-10 10 -1 2];
% axis_model_allocation = [-5 5 -3 3];
% axis_robust = [-10 10 -1 1];

% %Rogoff
% model = 105;
% model_name = 'model105';
% axis_model_PF         =[-10 10 -1 2];
% axis_model_allocation = [-5 5 -3 3];
% axis_robust = [-10 10 -1 1];
% 
% 
% %Rogoff  without switching
% model = -105;
% model_name = 'model-105';
% axis_model_PF         =[-10 10 -1 2];
% axis_model_allocation = [-5 5 -3 3];
% axis_robust = [-10 10 -1 1];

%Optimal????
model = -333;
model_name = 'model-333';
axis_model_PF         =[-10 10 -1 2];
axis_model_allocation = [-5 5 -3 3];
axis_robust = [-10 10 -1 1];

fprintf('****************************************************************\n')
fprintf('model %i :loaded: ',model)


switch_back=0;
if model<0
    model=-model;
    switch_back=1;
end
    
target=strcat(target_dir,'parameters\Parameters_',num2str(model),'.mat');
load(target,'parameters');fprintf('parameters, ');

target = strcat(target_dir,'Pmat\Pun_matrix_',num2str(model),'.mat');
load(target); fprintf('Pmat, ')


target = strcat(target_dir,'R_reg\R_reg_matrix_',num2str(model),'.mat');
load(target); fprintf('R_reg, ')

%%
if switch_back
    model=-model;
end

target=strcat(target_dir,'results\results_',num2str(model),'.mat');
load(target,'PF','VF');fprintf('results. LOADING done\n');
%%
parameters_unload;



VF_01     = VF(1,:);
VF_no_con = VF(2,:);

VF_conCH  = VF(3,:);    
VF_conLI  = VF(4,:);   

VF_conCH2  = VF(5,:);    
VF_conLI2  = VF(6,:);


PF_01    = PF(1,:);
PF_no_con = PF(2,:);

PF_conCH = PF(3,:);    
PF_conLI  = PF(4,:);   

PF_conCH2  = PF(5,:);    
PF_conLI2  = PF(6,:);  

y_ND = beta_h/(alpha^2+beta_h)*epsilon;
inf_ND = alpha/beta_h*y_target - alpha/(alpha^2+beta_h)*epsilon;

y_D = beta_l/(alpha^2+beta_l)*epsilon;
inf_D = alpha/beta_l*y_star - alpha/(alpha^2+beta_l)*epsilon;

PF_D = alpha^2/(alpha^2+beta_l)*(y_star-beta_l/beta_h*y_target)...
        +( beta_l/(alpha^2+beta_l) -   beta_h/(alpha^2+beta_h) )*epsilon;

inf_e_D = alpha/beta_h*y_target;


allocation_inf = @(beta)(alpha  * y_target + alpha^2     *inf_e_D - alpha *epsilon)/(alpha^2+beta);
allocation_y   = @(beta)(alpha^2* y_target - alpha*beta  *inf_e_D + beta  *epsilon)/(alpha^2+beta);

for i = 1:size(epsilon,2)
    vector = zeros(size(epsilon)); vector(i)=1; vector=vector'; 
    
    reaction_y_no_con(i)   = allocation_y(beta_h)*vector  +PF_no_con(i);
    reaction_inf_no_con(i) = allocation_inf(beta_h)*vector+PF_no_con(i)/alpha;

    reaction_y_conCH(i)   = allocation_y(beta_h)*vector  +PF_conCH(i);
    reaction_inf_conCH(i) = allocation_inf(beta_h)*vector+PF_conCH(i)/alpha;

    reaction_y_conCH2(i)   = allocation_y(beta_h)*vector  +PF_conCH2(i);
    reaction_inf_conCH2(i) = allocation_inf(beta_h)*vector+PF_conCH2(i)/alpha;
    
    reaction_y_conLI(i)   = allocation_y(beta_h)*vector  +PF_conLI(i);
    reaction_inf_conLI(i) = allocation_inf(beta_h)*vector+PF_conLI(i)/alpha;
    
    reaction_y_conLI2(i)   = allocation_y(beta_h)*vector  +PF_conLI2(i);
    reaction_inf_conLI2(i) = allocation_inf(beta_h)*vector+PF_conLI2(i)/alpha;
    
    reaction_y_01(i)   = allocation_y(beta_h)*vector  +PF_01(i);
    reaction_inf_01(i) = allocation_inf(beta_h)*vector+PF_01(i)/alpha;
    
    
end







%% allocations
% compare cheb results
compare_x = [epsilon];
compare_y = [PF_no_con;PF_conCH;PF_conCH2]';
compare_legend = {'announced policy';'full deviation';'PF\_no\_con';'PF\_conCH';'PF\_conCH2'};
figure(100)
plot(epsilon,zeros(size(epsilon)),'--k',epsilon,PF_D,'--m',compare_x,compare_y,'linewidth',2);
hline(0,'-k'); vline(0,'-k'); xlabel('\epsilon'); ylabel('d');
vline([-cutoff cutoff]);
legend(compare_legend,2); legend('boxoff')
axis(axis_model_PF)



% compare li results
compare_x = [epsilon];
compare_y =[PF_no_con;PF_conLI;PF_conLI2]';
compare_legend = {'announced policy';'full deviation';'PF\_no\_con';'PF\_conLI';'PF\_conLI2'};
figure(200)
plot(epsilon,zeros(size(epsilon)),'--k',epsilon,PF_D,'--m',compare_x,compare_y,'linewidth',2);
hline(0); vline(0);vline([-cutoff cutoff]); xlabel('\epsilon'); ylabel('d');
legend(compare_legend,2); legend('boxoff')
axis(axis_model_PF)




% cheb2 vs li2 results
compare_x = [epsilon];
compare_y = [PF_no_con;PF_conCH2;PF_conLI2]';
compare_legend = {'announced policy';'full deviation';'PF\_no\_con';'PF\_conCH2';'PF\_conLI2'};
figure(300)
plot(epsilon,zeros(size(epsilon)),'--k',epsilon,PF_D,'--m',compare_x,compare_y,'linewidth',2);
hline(0); vline(0);vline([-cutoff cutoff]); xlabel('\epsilon'); ylabel('d');
legend(compare_legend,1); legend('boxoff')
axis(axis_model_PF)

% Results, policy functions
compare_x = [epsilon];
compare_y = [PF_no_con;PF_conLI2]';
compare_legend = {'announced policy';'full deviation'; ... 
    'Optimal deviation, no constraint';'Optimal deviation, with constraint'};
figure(600)
plot(epsilon,zeros(size(epsilon)),'--k',epsilon,PF_D,'--m',compare_x,compare_y,'linewidth',3);
ll=hline(0,'-k');lll=vline([-cutoff cutoff]); llll=vline(0,'-k');
xlabel('\epsilon'); ylabel('d');
legend(compare_legend,1); legend('boxoff')
axis(axis_model_PF)
l=[ll lll llll];
set(l,'linewidth',1.5,'color','k');
set(gca,'XTick',-10:2:10);



% robustness check
compare_x = [epsilon];
compare_y = [PF_conCH;PF_conLI;PF_conCH2;PF_conLI2]';
compare_legend = {'Cheb, gauss';'Linear, gauss';'Cheb, simpson';'Linear, simpson'};
figure(500)
hl=plot(compare_x,compare_y,'linewidth',3);
ll=hline(0,'-k');lll=vline([-cutoff cutoff]); llll=vline(0,'-k');
xlabel('\epsilon'); ylabel('d');
switch model
    case 205
        legend(compare_legend,1);
    case 105
        legend(compare_legend,3);
end
legend('boxoff')

axis(axis_robust);
set(hl(1),'linestyle',':');
set(hl(2),'linestyle','--');
set(hl(3),'linestyle','-.');
set(hl(4),'Color','b');set(hl(1),'Color','k');

l=[ll lll llll];
set(l,'linewidth',1.5,'color','k');
set(gca,'XTick',-10:2:10);






% allocations without R area
compare_x = [reaction_y_no_con; reaction_y_conCH2; reaction_y_conLI2]';
compare_y = [reaction_inf_no_con; reaction_inf_conCH2; reaction_inf_conLI2]';
compare_legend = {'announced policy';'true preferences';'no\_con';'conCH2';'conLI2'};

sc_y   =   [reaction_y_no_con(ind_first);
            reaction_y_no_con(ind_last);
            reaction_y_conCH2(ind_first);
            reaction_y_conCH2(ind_last);
            reaction_y_conLI2(ind_first);
            reaction_y_conLI2(ind_last)];

sc_inf   = [reaction_inf_no_con(ind_first);
            reaction_inf_no_con(ind_last);
            reaction_inf_conCH2(ind_first);
            reaction_inf_conCH2(ind_last);
            reaction_inf_conLI2(ind_first);
            reaction_inf_conLI2(ind_last)];

figure(401)
plot(y_ND,inf_ND,'--k',y_D,inf_D,'--m',compare_x,compare_y,'linewidth',2); hold on;
scatter(sc_y,sc_inf,50,[1;1;2;2;3;3],'filled'); hold off;
ylabel('\pi');xlabel('y');hline(0);vline(0)
axis(axis_model_allocation)
legend(compare_legend);legend('boxoff')







% allocations with R area
compare_x = [reaction_y_no_con;  reaction_y_conLI2]';
compare_y = [reaction_inf_no_con; reaction_inf_conLI2]';
compare_legend = {'No rejection region';'announced policy';'full deviation'; ... 
    'Optimal deviation, no constraint';'Optimal deviation, with constraint'};
figure(400)
get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
plot(y_ND,inf_ND,'--k',y_D,inf_D,'--m',compare_x,compare_y,'linewidth',3); 
scatter(sc_y,sc_inf,100,[1;1;2;2;3;3],'filled'); hold off;
ylabel('\pi');xlabel('y');
ll=hline(0,'-k'); llll=vline(0,'-k');
axis(axis_model_allocation)
legend(compare_legend);legend('boxoff')
l=[ll llll];
set(l,'linewidth',1.5,'color','k');
set(gca,'XTick',-5:1:5);

axis([-10 10 -10 10]);

%% print

if print_fig
    
    figure(100)
    figuresize(12,10,'centimeters')
    target=strcat(pic_save_dir,model_name,'_comparison_CH','.pdf');
    print(gcf, '-dpdf', '-r200', target);


    figure(200)
    figuresize(12,10,'centimeters')
    target=strcat(pic_save_dir,model_name,'_comparison_LI','.pdf');
    print(gcf, '-dpdf', '-r200', target);    
    

    figure(600)
    figuresize(14,14,'centimeters')
    target=strcat(pic_save_dir,model_name,'_PF','.pdf');
    print(gcf, '-dpdf', '-r200', target);
    
    figure(500)
    figuresize(15,10,'centimeters')
    target=strcat(pic_save_dir,model_name,'_robust','.pdf');
    print(gcf, '-dpdf', '-r300', target);
    
    figure(400)
    figuresize(14,14,'centimeters')
    target=strcat(pic_save_dir,model_name,'_allocation','.pdf');
    print(gcf, '-dpdf', '-r200', target);
end

