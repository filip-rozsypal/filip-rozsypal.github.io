function [init_EV, initEV_NP] = get_init_EV(PF_no_con,epsilon)

grid_eps = min(epsilon):0.5:max(epsilon);
theta_init = interp1(epsilon,PF_no_con,grid_eps);



reversed_cutpoint = (alpha^2+beta_h)/beta_h*y_star;
reversed_dev = ones(size(epsilon))-2*(epsilon>reversed_cutpoint);      


EV    = @(theta) simpson_int_norm(epsilon,value(epsilon,theta),0,s_eps);    
E_dev = @(theta) simpson_int_norm(epsilon,PF_approx(theta,epsilon).*reversed_dev,0,s_eps);






    
    
    
    
    
    function fval = PF_approx(theta,xx)
        %xx row vector
        
        X_min = min(xx);
        X_max = -X_min; %because the hermite nodes are symetric
         
        x = xx/(X_max-X_min);
        if size(xx,1)==1
            x=x';
        end
        
        theta_sw = fliplr(theta);
        
        Her_matrix = ones(size(theta_sw,2),size(x,1));
        Her_matrix(2,:) = x';
        
        for i=2:size(theta_sw,2)-1
            Her_matrix(i+1,:) = 2*x'.*Her_matrix(i,:)-Her_matrix(i-1,:);
        end
        
        fval = theta*Her_matrix;
        
    end

    function fval = gaussian_quadrature(x,fx,s_eps,nodes)
        fval = 1/sqrt(pi)*weights'* interp1(x,fx,(sqrt(2)*s_eps.*nodes),'linear','extrap');
    end


end;


