function get_noR_area(Rregion_matrix,Prob_y,Prob_inf)

[~,index_lower_b]    = max(Rregion_matrix,[],2);
[~,index_upper_b_sw] = max(fliplr(Rregion_matrix),[],2);

Prob_inf_flipped = fliplr(Prob_inf);

upper_b = Prob_inf_flipped(index_upper_b_sw);
lower_b  = Prob_inf(index_lower_b);



figure(1)
fill( [Prob_y';flipud(Prob_y')],[upper_b';flipud(lower_b')],'r','LineStyle','none');
 