clear all;clc;

set(0,'DefaultFigureWindowStyle','docked');
target='C:\Users\Filip Rozsypal\Documents\Cambridge\1st_year_paper_proposal\';

s=RandStream('mt19937ar'); %set the seed
RandStream.setDefaultStream(s);

%% Parameters
global alpha y_star s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target;

% Probability of punishment matrix
load_Pmat = 1;  %1 for loading Pmatrix, 0 for computing
N_sim = 250;    % number of noise shock to simulate in order to compute the probability of punishment
save_matrix = 1;% save Pmatrix or not

tolerance = 0.0001; %tolerance in value function iteration
d_grid = -15:0.05:15;   %grid for the deviations

%CB preference
beta_l = 7.5/1.5/10;    %-> high inflation expectations
beta_h = beta_l*15;     %->low inflation expectations

%PC parameter
alpha  = 1; %slope of PC curve
y_star = 5; %output target
%variances
s_eps = 3;  %std of supply shock
s_inf = 1;  %std of inflation noise
s_y   = 1;  %std of output noise

delta=0.9; %CB discount factor

kappa_pos = 0.9; %revison constant    
kappa_neg = 2-kappa_pos; %revison constant for negative loglikelihood

% bounds on region for Pmatrix
y_min   =  -15;  y_step   =   0.05;  y_max   =   15;
inf_min =  -15;  inf_step =   0.05;  inf_max =   15;

%grid for state variable in value function iteration
epsilon = -20:0.1:20;

                    %s_eps  delta   kappa   beta_l          beta_h            alpha         
parameter_values = [0.5     0.9     0.9     7.5/1.5/10      7.5/1.5/10*10       1;      %1 - lower s_eps 
                    2       0.9     0.9     7.5/1.5/10      7.5/1.5/10*10       1;      %2 - baseline
                    3       0.9     0.9     7.5/1.5/10      7.5/1.5/10*10       1;      %3 - higher s_eps
                    2       0.7     0.9     7.5/1.5/10      7.5/1.5/10*10       1;      %4 - lower delta
                    2       0.99    0.9     7.5/1.5/10      7.5/1.5/10*10       1;      %5 - higher delta
                    2       0.9     0.7     7.5/1.5/10      7.5/1.5/10*10       1;      %6 - lower kappa
                    2       0.9     0.99    7.5/1.5/10      7.5/1.5/10*10       1;      %7 - higher kappa
                    2       0.9     0.95    7.5/1.5/10      7.5/1.5/10*10       1;      %8 - a bit higher kappa
                    2       0.9     0.9     7.5/1.5/10*2    7.5/1.5/10*10*2     1;      %9 - higher betas
                    2       0.9     0.9     7.5/1.5/10/2    7.5/1.5/10*10/2     1;      %10 - lower betas
                    2       0.9     0.9     7.5/1.5/10      7.5/1.5/10*10*4     1;      %11 - higher beta_h
                    2       0.9     0.9     7.5/1.5/10      7.5/1.5/10*10/4     1;      %12 - lower beta_h
                    2       0.9     0.9     7.5/1.5/10      7.5/1.5/10*10       0.5;    %13 - lower alpha
                    2       0.9     0.9     7.5/1.5/10      7.5/1.5/10*10       2];     %14 - higher alpha 
                
model_description = {   '\sigma_\epsilon=0.5';
                        'benchmark';
                        '\sigma_\epsilon=3';
                        '\delta=0.7';
                        '\delta=0.99';
                        '\kappa=0.7';
                        '\kappa=0.99';
                        '\kappa=0.95';
                        '\beta_l=1, \beta_h=10';
                        '\beta_l=0.25, \beta_h=2.5';
                        '\beta_h=20';
                        '\beta_h=1.25';
                        '\alpha=0.5';
                        '\alpha=2'};               
    



for model = 2:size(parameter_values,1)

    disp('**************************************************');
    disp(strcat('computing model ',' ',num2str(model)));
    s_eps = parameter_values(model,1);
    delta = parameter_values(model,2);
    kappa_pos = parameter_values(model,3);    
    kappa_neg = 2-kappa_pos;
    beta_l = parameter_values(model,4);
    beta_h = parameter_values(model,5);
    alpha  = parameter_values(model,6);
    
    %% define expansion paths
    inf_e_D = alpha/beta_h*y_star;
    allocation_inf = @(beta)(alpha  * y_star + alpha^2     *inf_e_D - alpha *epsilon)/(alpha^2+beta);
    allocation_y   = @(beta)(alpha^2* y_star - alpha*beta  *inf_e_D + beta  *epsilon)/(alpha^2+beta);    
    
    
    %% Obtain probability of rejection
    disp('Obtain probability of rejection...')
    if load_Pmat
        %cd('C:\Users\Filip Rozsypal\Documents\MATLAB\macro\1st_year_paper\Pmat');
        cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\Pmat');
        target = strcat('Pun_matrix_',num2str(model),'.mat');
        load(target); disp('loaded.')
    else
       [Prob,Prob_y,Prob_inf] = Pmatrix(N_sim,y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix,model);
    end
    

    
    %% No rejection region
    disp('Obtain no rejection region...');
    if load_Pmat
        %cd('C:\Users\Filip Rozsypal\Documents\MATLAB\macro\1st_year_paper\R_reg');
        cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\R_reg');
        target = strcat('R_reg_matrix_',num2str(model),'.mat');
        load(target); disp('loaded.')
    else
        [Rregion_matrix,~,~] = Rregion(y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix,model);
    end
    
    
    %% Value function iteration
    disp('Value function iteration...');
    [VF,PF,reaction_y,reaction_inf]=Paper_VI_full_d(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid);
    
    
    
    %% figure
    disp('Constructing the optimal reaction graph...')
    figure(1000)
    get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;

    plot(reaction_y,reaction_inf,'blue','LineWidth',2); hold on;
    plot(allocation_y(beta_h),allocation_inf(beta_h),'--k'); hold on;
    plot(allocation_y(beta_l),allocation_inf(beta_l),'--k'); hold on;
    xlabel('y');ylabel('\pi');
    vline(0,':k');hline(0,':k');
    hold off;
    axis([-10 10 -10 10])
    
    figuresize(10,10,'centimeters')
    %target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
    target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
    print(gcf, '-dpdf', '-r100', target);
    disp('done.')
    

    

end

%% create comparison figures
disp('producing comparison figures...')
models_superset = [ 1  2 3;
                    4  2 5;
                    6  2 7;
                    9  2 10;
                    11 2 12;
                    13 2 14];
for i=1:size(models_superset,1)
    disp(i);
    combine_dev_fig(models_superset(i,:),parameter_values,model_description,epsilon,tolerance,d_grid);
    
    figure(400)
    %target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\comp_',num2str(i),'.pdf');
    target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\comp_',num2str(i),'.pdf');
    figuresize(15,11,'centimeters')
    print(gcf, '-dpdf', '-r100', target);
    
    figure(401)
    %target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\vf_',num2str(i),'.pdf');
    target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\vf_',num2str(i),'.pdf');
    figuresize(15,11,'centimeters')
    print(gcf, '-dpdf', '-r100', target);       
    
end
disp('done.')
%     



