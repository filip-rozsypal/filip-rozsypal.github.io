 % Deviating        
    function [y_hat,inf_hat,xi_y_hat,xi_inf_hat,eps_hat] = 	Signal_extraction_D(y,inf)
        global alpha beta_l beta_h y_star y_target s_eps s_y s_inf;

        inf_e = alpha/beta_h*y_target;

        denominator = 1/s_eps^2 + (alpha/(alpha^2+beta_l))^2/(s_inf^2) + (beta_l/(alpha^2+beta_l))^2/(s_y^2);
        nominator1 = (  -  alpha  /(alpha^2+beta_l)   *inf ...
                        + (alpha  /(alpha^2+beta_l))^2*y_star ...
                        -  alpha^3/(alpha^2+beta_l)^2 *inf_e )/(s_inf^2);
        nominator2 = (            beta_l  /(alpha^2+beta_l)  *y   ...
                        - alpha^2*beta_l  /(alpha^2+beta_l)^2*y_star ...
                        + alpha  *beta_l^2/(alpha^2+beta_l)^2*inf_e )/(s_y^2);

        eps_hat = (nominator1 + nominator2)/denominator;

        
        
        
        
        
        
        
%         denom= 1/s_eps^2 + (alpha/(alpha^2+beta))^2/(s_inf^2) + (beta/(alpha^2+beta))^2/(s_y^2);
%         nom1 = (1/(alpha^2+beta))*(beta/s_y^2*y-alpha/s_inf^2*inf);
%         nom2 = y_star*(alpha/(alpha^2+beta))^2*(1/s_inf^2-beta*1/s_y^2);
%         nom3 = inf_e*(alpha/(alpha^2+beta)^2)*(alpha^2*1/s_inf^2-beta^2/s_y^2);
%         
%         
%         eps_hat2 = (nom1+nom2+nom3)/denom;
%         
%         eps_hat - eps_hat2
        
        
        
        
        
        
        
        inf_hat = (alpha  *y_star + alpha^2       *inf_e - alpha *eps_hat)/(alpha^2+beta_l);
        y_hat   = (alpha^2*y_star - alpha  *beta_l*inf_e + beta_l*eps_hat)/(alpha^2+beta_l);

        xi_inf_hat = inf_hat - inf;
        xi_y_hat   = y_hat   - y;
        
        
        
        
        
        
        
        
        
        
        
        
        
        inf_e = alpha/beta_h*y_target;
        const = (alpha^2+beta_l)/ ...
            ( (alpha^2+beta_l)^2*s_inf^2*s_y^2+alpha^2*s_y^2*s_eps^2+beta_l^2*s_inf^2*s_eps^2);

        eps_hat = const * ( ...
            -alpha*s_eps^2*s_y^2*(inf-alpha/(alpha^2+beta_l)*y_star-alpha^2/(alpha^2+beta_l)*inf_e) ...
            +beta_l*s_inf^2*s_eps^2*(y-alpha^2/(alpha^2+beta_l)*y_star-alpha*beta_l/(alpha^2+beta_l)*inf_e) ...
            );
        
        
        
        
    end

        





                
                