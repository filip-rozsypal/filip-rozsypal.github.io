function   [Prob,Prob_y,Prob_inf]=Pmatrix_ystar(N_sim,y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix,model)
%Prob...probability of punishment
global alpha y_star y_target s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg target_folder;


seedToSet = RandStream('mcg16807','Seed',1234);
RandStream.setDefaultStream(seedToSet) 

y   = y_min  :y_step  :y_max;
inf = inf_min:inf_step:inf_max;

%generatuing the noise shocks

Xi = [s_y^2 0;0 s_inf^2] * randn(2,N_sim);

%% Probability of deviation
 fprintf('computing "Probability of punishment" matrix:  0%%')

% norevision - 'no revision action is taken', i.e. Punishment NOT triggered
norevision = int8(zeros(size(y,2),size(inf,2),N_sim));

%loglikelihood
loglik = @(Shocks) -(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2))/2 ...
                    - Shocks(1)^2/(2*s_eps^2)-Shocks(2)^2/(2*s_y^2)-Shocks(3)^2/(2*s_inf^2);

%first row deviating, second row no deviation
xi_y_hat   = zeros(2,N_sim);               
xi_inf_hat = zeros(2,N_sim);
eps_hat    = zeros(2,N_sim);
y_hat      = zeros(2,N_sim);
inf_hat    = zeros(2,N_sim);

count = 1;
beeper = floor(size(y,2)*size(inf,2)/10);

for i=1:size(y,2)
    for j=1:size(inf,2)
        
        if mod(count,beeper)==0
            fprintf('\b\b\b\b %u0%%',count/beeper);
        end
        count = count+1;
        
        %skip areas which will not be reached
        if y(i)+inf(j)>20 || -0.5*y(i)+inf(j)<-20
            norevision(i,j,:) = 0; 
        else
            X_tilde = [y(i);inf(j)]*ones(1,N_sim)+Xi;
            for ii = 1:N_sim
                %Deviation
                [y_hat(1,ii),inf_hat(1,ii),xi_y_hat(1,ii),xi_inf_hat(1,ii),eps_hat(1,ii)] = ...
                    Signal_extraction_D(X_tilde(1,ii),X_tilde(2,ii));

                %NoDeviation
                [y_hat(2,ii),inf_hat(2,ii),xi_y_hat(2,ii),xi_inf_hat(2,ii),eps_hat(2,ii)] = ...
                    Signal_extraction_ND(X_tilde(1,ii),X_tilde(2,ii));
                
                %compare the loglikelihoods
                %note 'loglik(2)' is loglikelihood of NOT DEVIATING
                
                if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > 0 %check for the sign
                    disp('ll>0')
                    if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > ...
                            kappa_pos*loglik([eps_hat(1,ii) xi_y_hat(1,ii) xi_inf_hat(1,ii)])
                        norevision(i,j,ii) = 1;
                    end
                else
                    if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > ...
                            kappa_neg*loglik([eps_hat(1,ii) xi_y_hat(1,ii) xi_inf_hat(1,ii)])
                        norevision(i,j,ii) = 1;
                    end
                end
            end 
        end
    end
end

Prob = 1-sum(norevision,3)/size(norevision,3); %Probability of Punishment


Prob_y   = y;
Prob_inf = inf;
if save_matrix
    target = strcat(target_folder,'Pmat\Pun_matrix_',num2str(model),'.mat');
    save(target,'Prob','Prob_y','Prob_inf'); disp('(P matrix saved)');
end
disp('done...')









   



