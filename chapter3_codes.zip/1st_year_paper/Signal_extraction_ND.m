    function [y_hat,inf_hat,xi_y_hat,xi_inf_hat,eps_hat] = 	Signal_extraction_ND(y,inf)
        global alpha beta_h y_target s_eps s_y s_inf;

        inf_e = alpha/beta_h*y_target;

        denominator = 1/s_eps^2 + (alpha/(alpha^2+beta_h))^2/s_inf^2 + (beta_h/(alpha^2+beta_h))^2/s_y^2;
        nominator1 =  alpha/(alpha^2+beta_h)*(-inf+inf_e)/s_inf^2;
        nominator2 = beta_h/(alpha^2+beta_h)*y/s_y^2;

        eps_hat = (nominator1 + nominator2)/denominator;

        inf_hat = (alpha  *y_target + alpha^2       *inf_e - alpha *eps_hat)/(alpha^2+beta_h);
        y_hat   = (alpha^2*y_target - alpha  *beta_h*inf_e + beta_h*eps_hat)/(alpha^2+beta_h);

        xi_inf_hat = inf - inf_hat ;
        xi_y_hat   = y  - y_hat;
        

    end

        





                
                