function area_handle=get_noR_area(Rregion_matrix,Prob_y,Prob_inf)

% cut_y = double((Prob_y>-4) & (Prob_y<8));
% cut_inf= double((Prob_inf>-10 & Prob_inf<5.7));
% 
% cut_matrix =cut_y' * cut_inf; 
% Rregion_matrix=Rregion_matrix.*cut_matrix ;

[~,index_lower_b]    = max(Rregion_matrix,[],2);
[~,index_upper_b_sw] = max(fliplr(Rregion_matrix),[],2);

Prob_inf_flipped = fliplr(Prob_inf);

upper_b = Prob_inf_flipped(index_upper_b_sw);
lower_b  = Prob_inf(index_lower_b);


area_handle=fill( [Prob_y';flipud(Prob_y')],[upper_b';flipud(lower_b')],'g','LineStyle','none');
 




% hold on
% 
% for i=1:3:size(Prob_y,2)
%     for j=1:3:size(Prob_inf,2)
%         if Rregion_matrix(i,j)==1
%             scatter(Prob_y(i),Prob_inf(j),5,'.')
%         end
%     end
% end



