
clear all;clc;

set(0,'DefaultFigureWindowStyle','docked');


%%
global alpha y_star y_target s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target_dir turn_off_the_switch;
target_dir = 'F:\MATLAB\1st_year_paper\';
%target_dir='C:\Users\Filip Rozsypal\Documents\MATLAB\1st_year_paper\';
cd(target_dir);


load_Pmat = 1;  %1 for loading Pmatrix, 0 for computing
%load_Pmat = 1;
save_matrix = 1;% save Pmatrix or not

%grid for the deviations
d_grid = -10:0.01:10;   


%grid for state variable in value function iteration
epsilon = -14:0.05:14;




%% recounting with VF iteration corrected
% run_models = -[213 214 215 216 217 218 219 220  221 222 313 401 404  405 406 407 408 330  331 332 333 334 335 336 337 ];
% run_models = -[201 202 203 204 205 206 207 208 209 210 211 212 306 307 308 309 310 311 312 321 322 323 324 325  326  327 328 ];
%run_models = [ -212  -201];
%run_models = [501 550 551 552 553 554 ]:
%  run_models = -[1 -101 102 103 104 105     107   110 111  112 113 114 301 302   303  304 305 314 315 316 317 318 319 320];
% run_models =[502 503 508 507 509];
%% running:


% %basement1
% run_models =[];
% %basement2
% run_models =[];
% %basement3 
% run_models =[];



%home
%run_models = [  504 505 506 507];


% %desktop
run_models = [-115 ];



%% queue:



%re-runs: 

%%
load models_parameters;



parameter_names = {'model';'N_sim';'tolerance';'alpha';'beta_l';'y_star';'delta';'s_eps';...
                    's_inf';'s_y';'kappa_pos';'kappa_neg';'y_min';'y_step';'y_max';'inf_min';'inf_step';...
                    'inf_max';'beta_h';'y_target';'PF switch'};


    
N_models = size(run_models,2);
    
for i = 1:N_models
    
    model_row = find(model_parameters(:,1)==run_models(i));
    
    if isempty(model_row)
        fprintf('model %i not found\n',run_models(i));               
    else
        disp('************************************************************************');
        fprintf('computing model %i\n',run_models(i));
        
        % unload the parameters
        model     = model_parameters(model_row,1);
        N_sim     = model_parameters(model_row,2);
        tolerance = model_parameters(model_row,3);
        alpha     = model_parameters(model_row,4);
        beta_l    = model_parameters(model_row,5);
        y_star    = model_parameters(model_row,6);
        delta     = model_parameters(model_row,7);
        s_eps     = model_parameters(model_row,8);
        s_inf     = model_parameters(model_row,9);
        s_y       = model_parameters(model_row,10);
        kappa_pos = model_parameters(model_row,11);
        kappa_neg = model_parameters(model_row,12);
        y_min     = model_parameters(model_row,13);
        y_step    = model_parameters(model_row,14);
        y_max     = model_parameters(model_row,15);
        inf_min   = model_parameters(model_row,16);
        inf_step  = model_parameters(model_row,17);
        inf_max   = model_parameters(model_row,18);
        beta_h    = model_parameters(model_row,19);
        y_target  = model_parameters(model_row,20);
        turn_off_the_switch = model_parameters(model_row,21);
        
        model_run;        
    end
end

    