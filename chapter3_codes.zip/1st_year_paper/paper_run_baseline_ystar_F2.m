clear all;clc;

set(0,'DefaultFigureWindowStyle','docked');
%target_folder = 'C:\Users\Filip Rozsypal\Documents\Cambridge\1st_year_paper_proposal\';
target_folder = 'F:\MATLAB\1st_year_paper\';

s=RandStream('mt19937ar'); %set the seed
RandStream.setDefaultStream(s);

%% Parameters
global alpha y_star y_target s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target_folder;

% Probability of punishment matrix
load_Pmat = 0;  %1 for loading Pmatrix, 0 for computing
N_sim = 500;    % number of noise shock to simulate in order to compute the probability of punishment
save_matrix = 1;% save Pmatrix or not

tolerance = 1e-15; %tolerance in value function iteration
d_grid = -10:0.05:10;   %grid for the deviations


%PC parameter
alpha    = 0.9; %slope of PC curve

%CB preference
beta_l = 1;    %-> high inflation expectations
y_star = 4; %output target
delta = 0.99; %CB discount factor

%variances
s_eps = 2.5;  %std of supply shock
s_inf = 0.2;  %std of inflation noise
s_y   = 1;  %std of output noise



kappa_pos = 0.8; %revison constant    
kappa_neg = 2-kappa_pos; %revison constant for negative loglikelihood

% bounds on region for Pmatrix
y_min   =  -16;  y_step   =   0.05;  y_max   =   15;
inf_min =  -10;  inf_step =   0.05;  inf_max =   15;

%grid for state variable in value function iteration
epsilon = -14:0.025:14;


% CB announcements
beta_h   = 1;     %->low inflation expectations
y_target = 0;     %->targeting zero output gap

%%
model=51;


    
%% define expansion paths
% inf_e_D = alpha/beta_h*y_star;
% allocation_inf = @(beta)(alpha  * y_star + alpha^2     *inf_e_D - alpha *epsilon)/(alpha^2+beta);
% allocation_y   = @(beta)(alpha^2* y_star - alpha*beta  *inf_e_D + beta  *epsilon)/(alpha^2+beta);    


%% Obtain probability of rejection
disp('Obtain probability of rejection...')
if load_Pmat
    cd(target_folder); cd Pmat
    target = strcat('Pun_matrix_',num2str(model),'.mat');
    load(target); disp('loaded.')
else
   [Prob,Prob_y,Prob_inf] = Pmatrix_ystar(N_sim,y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix,model);
end



%% No rejection region
disp('Obtain no rejection region...');
if load_Pmat
    cd(target_folder); cd R_reg
    target = strcat('R_reg_matrix_',num2str(model),'.mat');
    load(target); disp('loaded.')
else
    [Rregion_matrix,~,~] = Rregion_ystar(y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix,model);
end


%%
figures_code
    



