












y1      = zeros(18,1);
y2      = zeros(18,1);
pi_err = zeros(18,1);

pi_err(3) = 1;


for t=3:18
    y1(t) = 1.15036109491*y1(t-1) - 0.378441972807*y1(t-2) + 0.406866027785*pi_err(t)                             ;
    y2(t) = 1.15234956302*y2(t-1) - 0.355578151966*y2(t-2) + 0.904447684342*pi_err(t) - 0.658454807037*pi_err(t-1);
end

y1=y1(3:end);
y2=y2(3:end);

plot(1:16,[y1 y2],'LineWidth',3)
hline(0);legend('2 lags','1 lag only'); xlabel('time');ylabel('percentage deviation')
axis([1,16,-0.1,1])

y1_sum=sum(y1)
y2_sum=sum(y2)

