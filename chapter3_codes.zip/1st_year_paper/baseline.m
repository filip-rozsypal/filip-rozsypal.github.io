

clear all;clc;

global alpha y_star y_target s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target;

model = 1;

cd('G:\filip_google_drive\doc_cambridge\MATLAB\1st_year_paper\parameters')
target=strcat('Parameters_',num2str(model),'.mat');
load(target,'parameters');%disp('Parameters loaded');

cd('G:\filip_google_drive\doc_cambridge\MATLAB\1st_year_paper\Pmat');
target = strcat('Pun_matrix_',num2str(model),'.mat');
load(target); %disp('loaded.')

cd('G:\filip_google_drive\doc_cambridge\MATLAB\1st_year_paper\R_reg');
target = strcat('R_reg_matrix_',num2str(model),'.mat');
load(target); %disp('loaded.')

cd('G:\filip_google_drive\doc_cambridge\MATLAB\1st_year_paper\results');
target=strcat('results_',num2str(model),'.mat');
load(target,'PF','VF'); %disp('PF and VF loaded');


cd('G:\filip_google_drive\doc_cambridge\MATLAB\1st_year_paper');


parameters_unload;
    

    
%           VF =  [VF_01(counter,:);
%              VF_no_con(counter,:);
%              VF_conCH(counter,:);
%              VF_conLI(counter,:);
%              VF_conCH2(counter,:);
%              VF_conLI2(counter,:)];   

    PF_01     = PF(1,:);
    PF_no_con = PF(2,:);
    PF_conLI2  = PF(4,:);
    PF_conCH  = PF(3,:);

    VF_01     = VF(1,:);
    VF_no_con = VF(2,:);
    VF_conLI2  = VF(4,:);
    VF_conCH  = VF(3,:);


    
    
    
    

%%


inf_e_D = alpha/beta_h*y_target;


allocation_inf = @(beta)(alpha  * y_target + alpha^2     *inf_e_D - alpha *epsilon)/(alpha^2+beta);
allocation_y   = @(beta)(alpha^2* y_target - alpha*beta  *inf_e_D + beta  *epsilon)/(alpha^2+beta);

No_deviation_y = allocation_y(beta_h);
No_deviation_inf = allocation_inf(beta_h);

Deviation_y = allocation_y(beta_l);
Deviation_inf = allocation_inf(beta_l);

for i=1:size(epsilon,2)
    vector=zeros(size(epsilon)); vector(i)=1; vector=vector';    
    
    reaction_y_01(i)   = allocation_y(beta_h)*vector+PF_01(i);
    reaction_inf_01(i) = allocation_inf(beta_h)*vector+PF_01(i)/alpha;
    
    reaction_y_no_con(i)   = allocation_y(beta_h)*vector+PF_no_con(i);
    reaction_inf_no_con(i) = allocation_inf(beta_h)*vector+PF_no_con(i)/alpha;
    
    reaction_y_CHpol(i)   = allocation_y(beta_h)*vector+PF_conCH(i);
    reaction_inf_CHpol(i) = allocation_inf(beta_h)*vector+PF_conCH(i)/alpha;
    
    reaction_y_LinInt2(i)   = allocation_y(beta_h)*vector+PF_conLI2(i);
    reaction_inf_LinInt2(i) = allocation_inf(beta_h)*vector+PF_conLI2(i)/alpha;
end





%%
cutoff = norminv(0.975,0,s_eps);
ind_first = find(epsilon>-cutoff,1, 'first');
ind_last  = find(epsilon>cutoff,1, 'first');


figure(1)
plot(epsilon,[PF_no_con;PF_01],'linewidth',2)
axis([-14 10 -1 9])
vline(0,'k');hline(0,'k');vline([-cutoff,cutoff]);
xlabel('\epsilon');ylabel('Policy function');
legend('continuous deviation','0-1 deviation only');legend('boxoff');

% % figuresize(14,10,'centimeters')
% % %target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
% % target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_presentation\fig\baseline_PF_01','.pdf');
% % print(gcf, '-dpdf', '-r100', target);



sc_y   = [reaction_y_01(ind_first);reaction_y_01(ind_last);reaction_y_no_con(ind_first);reaction_y_no_con(ind_last)];
sc_inf = [reaction_inf_01(ind_first);reaction_inf_01(ind_last);reaction_inf_no_con(ind_first);reaction_inf_no_con(ind_last)];

figure(2)
get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
plot(reaction_y_no_con,reaction_inf_no_con,reaction_y_01,reaction_inf_01,'linewidth',2);
scatter(sc_y,sc_inf,50,[2;2;1;1],'filled'); 
plot(No_deviation_y,No_deviation_inf,'--','markersize',0.5);
plot(Deviation_y,Deviation_inf,'--','markersize',0.5);hold off;
axis([-12 12 -1.5 4.5])
vline(0,'k');hline(0,'k');
xlabel('y');ylabel('\pi');
legend('No rejection area','continuous deviation','0-1 deviation only');legend('boxoff');

% % figuresize(14,10,'centimeters')
% % %target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
% % target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_presentation\fig\baseline_allocation_01','.pdf');
% % print(gcf, '-dpdf', '-r100', target);


%%


figure(5)
plot(epsilon,[PF_no_con],'linewidth',2)
axis([-14 10 -1 9])
vline(0,'k');hline(0,'k');vline([-cutoff,cutoff]);
xlabel('\epsilon');ylabel('Policy function');
legend('continuous deviation','0-1 deviation only');legend('boxoff');

% % figuresize(14,10,'centimeters')
% % %target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
% % target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_presentation\fig\baseline_PF_no_con','.pdf');
% % print(gcf, '-dpdf', '-r100', target);



sc_y   = [reaction_y_no_con(ind_first);reaction_y_no_con(ind_last)];
sc_inf = [reaction_inf_no_con(ind_first);reaction_inf_no_con(ind_last)];

figure(6)
get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
plot(reaction_y_no_con,reaction_inf_no_con,'linewidth',2);
scatter(sc_y,sc_inf,50,[1;1],'filled'); 
plot(No_deviation_y,No_deviation_inf,'--','markersize',0.5);
plot(Deviation_y,Deviation_inf,'--','markersize',0.5);hold off;
axis([-12 12 -1.5 4.5])
vline(0,'k');hline(0,'k');
xlabel('y');ylabel('\pi');
legend('No rejection area','continuous deviation');legend('boxoff');

% % figuresize(14,10,'centimeters')
% % %target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
% % target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_presentation\fig\baseline_allocation_no_con','.pdf');
% % print(gcf, '-dpdf', '-r100', target);


%%
figure(3)
plot(epsilon,[PF_no_con;PF_conCH;PF_conLI2],'linewidth')
axis([-14 10 -1 9])
vline(0,'k');hline(0,'k');vline([-cutoff,cutoff]);
xlabel('\epsilon');ylabel('Policy function');
legend('standard VFI, no constraint', '12th order Chebyshev pol, with constraint','lin approx, with constraint');legend('boxoff');


% % figuresize(14,10,'centimeters')
% % %target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
% % target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_presentation\fig\baseline_PF_constraint_gauss','.pdf');
% % print(gcf, '-dpdf', '-r100', target);


%%



sc_y   = [reaction_y_no_con(ind_first);reaction_y_no_con(ind_last);
          reaction_y_CHpol(ind_first);reaction_y_CHpol(ind_last);
          reaction_y_LinInt2(ind_first);reaction_y_LinInt2(ind_last)];

sc_inf   = [reaction_inf_no_con(ind_first);reaction_inf_no_con(ind_last);
          reaction_inf_CHpol(ind_first);reaction_inf_CHpol(ind_last);
          reaction_inf_LinInt2(ind_first);reaction_inf_LinInt2(ind_last)];

      
yy = [reaction_y_no_con;
      reaction_y_CHpol;
      reaction_y_LinInt2]';

  
infinf = [reaction_inf_no_con;
          reaction_inf_CHpol;
          reaction_inf_LinInt2]';  
  
      
      
      
figure(4)
get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
plot(yy,infinf,'linewidth',2);
scatter(sc_y,sc_inf,50,[1;1;2;2;3;3],'filled'); 
plot(No_deviation_y,No_deviation_inf,'--','markersize',0.5);
plot(Deviation_y,Deviation_inf,'--','markersize',0.5);hold off;
vline(0,'k');hline(0,'k');
xlabel('y');ylabel('\pi');
axis([-12 12 -1.5 4.5])
legend('No rejection area','standard VFI, no constraint', ...
    '12th order Chebyshev pol, with constraint','lin approx, with constraint');legend('boxoff');


% % figuresize(14,10,'centimeters')
% % %target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
% % target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_presentation\fig\baseline_allocation_constraint_gauss','.pdf');
% % print(gcf, '-dpdf', '-r100', target);

