function   [Prob,Prob_y,Prob_inf]=Pmatrix(N_sim,y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix,model)
%Prob...probability of punishment
global alpha y_star s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg target;


% seedToSet = RandStream('mcg16807','Seed',1234);
% RandStream.setDefaultStream(seedToSet) 

seed=1234567890;
rng(seed)

y   = y_min  :y_step  :y_max;
inf = inf_min:inf_step:inf_max;

%generatuing the noise shocks

Xi = [s_y^2 0;0 s_inf^2] * randn(2,N_sim);

%% Probability of deviation
 fprintf('computing "Probability of punishment" matrix:  0%%')

norevision = int8(zeros(size(y,2),size(inf,2),N_sim));

loglik=@(Shocks) -(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2))/2 ...
                    - Shocks(1)^2/(2*s_eps^2)-Shocks(2)^2/(2*s_y^2)-Shocks(3)^2/(2*s_inf^2);

xi_y_hat   = zeros(2,N_sim);               
xi_inf_hat = zeros(2,N_sim);
eps_hat    = zeros(2,N_sim);
y_hat      = zeros(2,N_sim);
inf_hat    = zeros(2,N_sim);

count=1;
%figure(1)
beeper=floor(size(y,2)*size(inf,2)/10);
for i=1:size(y,2)
    for j=1:size(inf,2)
        
        if mod(count,beeper)==0
            fprintf('\b\b\b\b %u0%%',count/beeper);
        end
        count=count+1;
        
        if y(i)+inf(j)>52 || y(i)+inf(j)<-52
            norevision(i,j,:)=NaN; %skip areas which will not be reached
        else          

            X_tilde =[y(i);inf(j)]*ones(1,N_sim)+Xi;

            for ii=1:N_sim
                %low beta - Deviation
                [y_hat(1,ii),inf_hat(1,ii),xi_y_hat(1,ii),xi_inf_hat(1,ii),eps_hat(1,ii)] = ...
                    CSG(X_tilde(1,ii),X_tilde(2,ii),beta_h,beta_l);
                %plot(y_hat(1,ii),inf_hat(1,ii),'.','color','black');hold on;

                %high beta - NoDeviation
                [y_hat(2,ii),inf_hat(2,ii),xi_y_hat(2,ii),xi_inf_hat(2,ii),eps_hat(2,ii)] = ...
                    CSG(X_tilde(1,ii),X_tilde(2,ii),beta_h,beta_h);
                %plot(y_hat(2,ii),inf_hat(2,ii),'.','color','black');hold on;

                if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > 0
                    disp('ll>0')
                    if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > ...
                            kappa_pos*loglik([eps_hat(1,ii) xi_y_hat(1,ii) xi_inf_hat(1,ii)])
                        norevision(i,j,ii) = 1;
                    end
                else
                    if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > ...
                            kappa_neg*loglik([eps_hat(1,ii) xi_y_hat(1,ii) xi_inf_hat(1,ii)])
                        norevision(i,j,ii) = 1;
                        %plot(X_tilde(1,ii),X_tilde(2,ii),'.','color','r');hold on;
                    else
                        %plot(X_tilde(1,ii),X_tilde(2,ii),'.','color','b');hold on;
                    end

                end
            end
            %plot(y(i),inf(j),'.','color','yellow','MarkerSize',30);hold on;
            
            
        end
   


    end
end

Prob = 1-sum(norevision,3)/size(norevision,3);
% [inflation,outputgap] = meshgrid(inf,y);
% figure(2)
% surf(outputgap,inflation,Prob);
% xlabel('y'); ylabel('\pi'); zlabel('Prabability of revision');
%figuresize(15,10,'centimeters')
% print(gcf, '-dpdf', '-r300', 'C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\P_punishment.pdf')

Prob_y   = y;
Prob_inf = inf;
if save_matrix
    %cd('C:\Users\Filip Rozsypal\Documents\MATLAB\macro\1st_year_paper\Pmat');
    cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\Pmat');
    target = strcat('Pun_matrix_',num2str(model),'.mat');
    save(target,'Prob','Prob_y','Prob_inf'); disp('(P matrix saved)');
end
disp('done...')