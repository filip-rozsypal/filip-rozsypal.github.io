

      PF = [PF_01(counter,:);
            PF_no_con(counter,:);
            PF_conCH(counter,:);
            PF_conLI2(counter,:);
            PF_conCH2(counter,:);
            PF_conLI2(counter,:);
            PF_noconCH(counter,:);
            PF_noconLI2(counter,:);
            PF_noconCH2(counter,:);
            PF_noconLI2(counter,:);
            ];


      VF =  [VF_01(counter,:);
             VF_no_con(counter,:);
             VF_conCH(counter,:);
             VF_conLI2(counter,:);
             VF_conCH2(counter,:);
             VF_conLI2(counter,:);
             VF_noconCH(counter,:);
             VF_noconLI2(counter,:);
             VF_noconCH2(counter,:);
             VF_noconLI2(counter,:)];
         

if save_matrix
    %cd('C:\Users\Filip Rozsypal\Documents\MATLAB\macro\1st_year_paper\R_reg');
    cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\results')
    target=strcat('results_ext_',num2str(model),'.mat');
    save(target,'PF','VF');disp('(PF and VF saved)');
end         