
clear all;clc;

set(0,'DefaultFigureWindowStyle','docked');



%%
global alpha y_star y_target s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target;


target = 'C:\Users\Filip Rozsypal\Documents\Cambridge\1st_year_paper_proposal\';




load_Pmat = 0;  %1 for loading Pmatrix, 0 for computing

save_matrix = 1;% save Pmatrix or not


d_grid = -10:0.01:10;   %grid for the deviations


%PC parameter


%CB preference
beta_l = 1;    %-> high inflation expectations
y_star = 4; %output target
delta = 0.99; %CB discount factor

%variances
s_eps = 2.5;  %std of supply shock
s_inf = 0.2;  %std of inflation noise
s_y   = 1;  %std of output noise



kappa_pos = 0.85; %revison constant    
kappa_neg = 2-kappa_pos; %revison constant for negative loglikelihood

% bounds on region for Pmatrix
y_min   =  -16;  y_step   =   0.025;  y_max   =   15;
inf_min =  -10;  inf_step =   0.025;  inf_max =   15;

%grid for state variable in value function iteration
epsilon = -14:0.05:14;


% CB announcements
beta_h   = 8;     %->low inflation expectations
y_target = 4;     %->targeting zero output gap





parameter_names = {'model';'N_sim';'tolerance';'alpha';'beta_l';'y_star';'delta';'s_eps';...
                    's_inf';'s_y';'kappa_pos';'kappa_neg';'y_min';'y_step';'y_max';'inf_min';'inf_step';...
                    'inf_max';'beta_h';'y_target'};

%                 
%                 
%                 
%              t                                          k     k                                       b   
%              o                                          a     a                        i  i       i   e   y
%              l                                          p     p                        n  n       n   t   _ 
%              e            b   y                         p     p        y   y      y    f  f       f   a   t  
%  m    N      r         a  e   _    d        s  s  s     a     a        _   _      _    _  _       _   _   a
%  o    _      a         l  t   s    e        _  _  _     _     _        m   s      m    m  s       m   h   r
%  d    s      n         p  a   t    l        s  f  y     p     n        i   t      a    i  t       a   i   g
%  e    i      c         h  _   a    t        p  n        o     e        n   e      x    n  e       x   g   e
%  l    m      e         a  l   r    a        s  f        s     g            p              p           h   t
parameters = [
	1	250	1.00E-14	0.9	1	4	0.99	2.5	0.2	1	0.85	1.15	-16	0.025	15	-10	0.025	15	8	4];
    
N_models = size(parameters,1);
    
for i = 1:N_models
    % unload the parameters
    model = parameters(i,1);
    N_sim = parameters(i,2);
    tolerance = parameters(i,3);
    alpha = parameters(i,4);
    beta_l = parameters(i,5);
    y_star = parameters(i,6);
    delta = parameters(i,7);
    s_eps = parameters(i,8);
    s_inf  = parameters(i,9);
    s_y  = parameters(i,10);
    kappa_pos  = parameters(i,11);
    kappa_neg  = parameters(i,12);
    y_min  = parameters(i,13);
    y_step = parameters(i,14);
    y_max = parameters(i,15);
    inf_min = parameters(i,16);
    inf_step = parameters(i,17);
    inf_max = parameters(i,18);
    beta_h = parameters(i,19);
    y_target = parameters(i,20);
    
    model_run;


end



    
