clear all;clc;

set(0,'DefaultFigureWindowStyle','docked');
target = 'C:\Users\Filip Rozsypal\Documents\Cambridge\1st_year_paper_proposal\';

s=RandStream('mt19937ar'); %set the seed
RandStream.setDefaultStream(s);

%% Parameters
global alpha y_star y_target s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target;

% Probability of punishment matrix
load_Pmat = 0;  %1 for loading Pmatrix, 0 for computing
N_sim = 300;    % number of noise shock to simulate in order to compute the probability of punishment
save_matrix = 1;% save Pmatrix or not

tolerance = 1e-12; %tolerance in value function iteration
d_grid = -10:0.01:10;   %grid for the deviations


%PC parameter
alpha    = 0.9; %slope of PC curve

%CB preference
beta_l = 1;    %-> high inflation expectations
y_star = 4; %output target
delta = 0.99; %CB discount factor

%variances
s_eps = 2.5;  %std of supply shock
s_inf = 0.2;  %std of inflation noise
s_y   = 1;  %std of output noise



kappa_pos = 0.85; %revison constant    
kappa_neg = 2-kappa_pos; %revison constant for negative loglikelihood

% bounds on region for Pmatrix
y_min   =  -16;  y_step   =   0.05;  y_max   =   15;
inf_min =  -10;  inf_step =   0.05;  inf_max =   15;

%grid for state variable in value function iteration
epsilon = -14:0.05:14;


% CB announcements
beta_h   = 8;     %->low inflation expectations
y_target = 4;     %->targeting zero output gap

%%
model=4;
counter=1;

% for kappa_pos=[0.75 0.82 0.83 0.84 0.86 0.87 0.88 0.89 0.97]
%     kappa_neg = 2-kappa_pos;
 for beta_h=[8 1]
     for y_target = [4 0]

        
        fprintf('model=%i,\t beta_h=%1.1f,\t y_target=%1.1f \n',[model beta_h y_target]);
        %% Obtain probability of rejection
        disp('Obtain probability of rejection...')
        if load_Pmat
            %cd('C:\Users\Filip Rozsypal\Documents\MATLAB\macro\1st_year_paper\Pmat');
            cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\Pmat');
            target = strcat('Pun_matrix_',num2str(model),'.mat');
            load(target); disp('loaded.')
        else
           [Prob,Prob_y,Prob_inf] = Pmatrix_ystar(N_sim,y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix,model);
        end



        %% No rejection region
        disp('Obtain no rejection region...');
        if load_Pmat
            %cd('C:\Users\Filip Rozsypal\Documents\MATLAB\macro\1st_year_paper\R_reg');
            cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\R_reg');
            target = strcat('R_reg_matrix_',num2str(model),'.mat');
            load(target); disp('loaded.')
        else
            [Rregion_matrix,~,~] = Rregion_ystar(y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix,model);
        end
        
        %%
        parameters_save;


        %%
        % setup
        int_method = 'gauss_quadrature';     
        %int_method = 'Simpson';%choose method to compute expected value
        constraint = 'yes';  %constrint setup
        cutoff = norminv(0.975,0,s_eps);
        ind_first = find(epsilon>-cutoff,1, 'first');
        ind_last  = find(epsilon>cutoff,1, 'first');

        %% 0-1 setup
        % 0-0 deviation only, normal value function iteration
        method='01';
        [VF_01(counter,:),PF_01(counter,:),reaction_y_01,reaction_inf_01] = ...
            Paper_VI_full_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,[],[]);

        %continuous deviation, normal value function iteration
        method='no_con';
        [VF_no_con(counter,:),PF_no_con(counter,:),reaction_y_no_con,reaction_inf_no_con] = ...
            Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,[],[],constraint,int_method);


        %continuous deviation, approximating the policy function by chebyshev
        %polynomials and iterating on E[V]    
        order = 14;
        [theta_init,PF_no_con_fitted(counter,:)] = cheb_estimation(order,PF_no_con(counter,:),epsilon); %find the starting values  from normal value function iteration


        method='con_CHpol';
        [VF_conCH(counter,:),PF_conCH(counter,:),reaction_y_CHpol,reaction_inf_CHpol] = ...
            Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,[],constraint,int_method);


        %continuous deviation, approximating the policy function by linear
        %approxiamtion and iterating on E[V]       
        method='con_LinInt';
        grid_eps = min(epsilon):0.5:max(epsilon);
        theta_init = interp1(epsilon,PF_no_con(counter,:),grid_eps); %find starting conditions from normal value function iteration
        [VF_conLI(counter,:),PF_conLI(counter,:),reaction_y_LinInt,reaction_inf_LinInt] = ...
            Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,grid_eps,constraint,int_method);
        
        %%
         int_method = 'Simpson';
% 
% 
%         %continuous deviation, approximating the policy function by chebyshev
%         %polynomials and iterating on E[V]    
%         order = 12;
%         [theta_init,PF_no_con_fitted(counter,:)] = cheb_estimation(order,PF_no_con(counter,:),epsilon); %find the starting values  from normal value function iteration
% 
% 
%         method='con_CHpol';
%         [VF_conCH2(counter,:),PF_conCH2(counter,:),reaction_y_CHpol2,reaction_inf_CHpol2] = ...
%             Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,[],constraint,int_method);
% 
% 
        %continuous deviation, approximating the policy function by linear
        %approxiamtion and iterating on E[V]       
        method='con_LinInt';
        grid_eps = min(epsilon):0.5:max(epsilon);
        theta_init = interp1(epsilon,PF_no_con(counter,:),grid_eps); %find starting conditions from normal value function iteration
        [VF_conLI2(counter,:),PF_conLI2(counter,:),reaction_y_LinInt2,reaction_inf_LinInt2] = ...
            Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,grid_eps,constraint,int_method);

        
        %% save value functions and policy functions
        results_save;
        
        %%
        model   = model+1;
        counter = counter+1;
     end

end


