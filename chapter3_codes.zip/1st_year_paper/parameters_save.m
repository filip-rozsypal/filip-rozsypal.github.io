
% saves the parameters of the current model into mat file


parameters.load_Pmat =load_Pmat;
parameters.N_sim=N_sim;
parameters.save_matrix=save_matrix;

parameters.tolerance =tolerance;
parameters.d_grid=d_grid;

parameters.alpha   =alpha;

parameters.beta_l =beta_l;
parameters.y_star =y_star;
parameters.delta =delta;


parameters.s_eps=s_eps;
parameters.s_inf =s_inf;
parameters.s_y  =s_y ;



parameters.kappa_pos =kappa_pos;
parameters.kappa_neg =kappa_neg;


parameters.y_min  =y_min ;
parameters.y_step  =y_step ;
parameters.y_max =y_max;

parameters.inf_min =inf_min;
parameters.inf_step =inf_step ;
parameters.inf_max =inf_max;

parameters.epsilon =epsilon;

parameters.beta_h =beta_h;
parameters.y_target =y_target;  

parameters.model = model;


if save_matrix

    target=strcat(target_dir,'parameters\Parameters_',num2str(model),'.mat');
    save(target,'parameters');disp('(Parameters saved)');
end