


clear all;clc; close all;
%% CPI
load data_cpi

dates=char(dates); dates=dates(:,4:end);dates(:,4:5)=[];   dates=cellstr(dates);

for i=1:size(data,1)
    for j=1:size(data,2)
        if data(i,j)==0
            data(i,j)=NaN;
        end
    end
end

error=NaN*zeros(size(data,2),1);

column = size(data,2);
row    = size(data,1) - 12;


while column-12>0
    error(row) = data(row,column) - data(row,column-12);
    error_percent(row) = error(row)/data(row,column)*100;
    
    row    = row-1;
    column = column-1;
end

row    = row+1;
column = column+1;

%plotyy

interval = row:size(data,1)-12;

figure(1)
plot(interval,error(interval),interval,data(interval,end),'--','LineWidth',2)
axis([row size(data,1)-12 -3 5]);hline(0,'-k');
labelnum=row:24:size(data,1);
set(gca,'XTick',labelnum);
set(gca,'XTickLabel',dates(labelnum));
ylabel('percentage point');xlabel('date (month)');
legend('revision','inflation (y-y)');legend('location','SouthWest');legend('boxoff');

target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper\fig\noise_in_cpi.pdf');
figuresize(11,9,'centimeters')
print(gcf, '-dpdf', '-r100', target); 



std_cpi       = std(data(interval,end));
std_cpi_error = std(error(interval));

disp('*** CPI ***')
fprintf('\t The std of CPI is \t\t %6.4f \n',std_cpi)
fprintf('\t The std of the noise is \t %6.4f \n',std_cpi_error)
fprintf('\t Signal to noise ration is \t\t %6.4f \n',std_cpi/std_cpi_error)





% figure(2)
% plot(error_percent)
% axis([row size(data,1)-12 -10 10])
% set(gca,'XTick',labelnum);
% set(gca,'XTickLabel',dates(labelnum));
% ylabel('1 year revision (%)');xlabel('date');
% legend('inflation');


%% GDP
clear all;
load data_gdp

data = data(:,1:end-1);

data2 = data(1+4 : end   , :);
data  = data(1   : end-4 , :);


data3 = (data2-data)./data*100;
data=data3;clear data3 data2;

dates2 ={};

dates=char(dates); dates=dates(:,4:end);
for i=1:size(dates,1)
    year = dates(i,6:end);
    switch dates(i,1:2)
        case '01'
            dates2(i,:)=cellstr(strcat(year,'Q1'));        
        case '04'
            dates2(i,:)=cellstr(strcat(year,'Q2')); 
        case '07'
            dates2(i,:)=cellstr(strcat(year,'Q3')); 
        case '10'
            dates2(i,:)=cellstr(strcat(year,'Q4'));            
    end
end
dates=dates2; clear dates2;

counter=2;
indicator_vector=zeros(size(names));
for i=1:size(names,2)
    name = char(names(i));
    names(i)=cellstr(strcat(name(7:10),'_',name(11:12),'_',name(13:14)));
    
    if mod(counter,3)==0
        indicator_vector(i) = 1;
    end
    counter=counter+1;
end

data2=[];
for i=1:size(data,2)
    if indicator_vector(i)==1
        data2=[data2 data(:,i)];
    end
end

data=data2; clear data2;



error_1y         = NaN*zeros(size(data,2),1);
error_1y_percent = error_1y;
column = size(data,2);
row    = size(data,1) - 4;

while column-4>0 && row>0
    error_1y(row)         = data(row,column) - data(row,column-4);
    error_1y_percent(row) = error_1y(row)/data(row,column)*100;    
    row    = row-1;
    column = column-1;
end       

row    = row+1;
column = column+1;

interval = row:size(data,1)-4;

figure(3)
plot(interval,error_1y(interval),interval,data(interval,end),'--','LineWidth',2)
axis([row size(data,1)-4 -3 5]);hline(0,'-k');
labelnum=row:10:size(data,1);
set(gca,'XTick',labelnum);
set(gca,'XTickLabel',dates(labelnum));
ylabel('percentage point');xlabel('date (quarters)');
legend('revision','GDP y-y growth'); legend('location','SouthWest');legend('boxoff');

target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper\fig\noise_in_gdp.pdf');
figuresize(11,9,'centimeters')
print(gcf, '-dpdf', '-r100', target); 


std_gdp       = std(data(interval,end));
std_gdp_error = std(error_1y(interval));

disp('*** GDP ***')
fprintf('\t The std of GDP is \t\t %6.4f \n',std_gdp)
fprintf('\t The std of the noise is \t %6.4f \n',std_gdp_error)
fprintf('\t Signal to noise ration is \t\t %6.4f \n',std_gdp/std_gdp_error)




% figure(4)
% plot(error_1y_percent)
% axis([row size(data,1)-4 -60 60])
% set(gca,'XTick',labelnum);
% set(gca,'XTickLabel',dates(labelnum));
% ylabel('1 year revision (%)');xlabel('date');
% legend('output');


























                