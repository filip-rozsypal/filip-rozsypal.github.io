function [y_hat,inf_hat,xi_y_hat,xi_inf_hat,eps_hat] = SE_D(y,inf,beta_old,beta_new)
global alpha beta_l y_star s_inf s_y s_eps;
%Constrained Signal Extraction
if beta_old==beta_new  %correct beliefs (=not deviated) 
    beta=beta_old;
    const = -s_y^2*s_inf^2*s_eps^2*(alpha^2+beta)/ ...
        (s_inf^2*s_y^2*(alpha^2+beta)^2+s_y^2*s_eps^2*alpha^2+s_inf^2*s_eps^2*beta^2);
    eps_hat = const * ( -alpha^2/(beta*s_inf^2)*y_star + alpha/s_inf^2*inf - beta/s_y^2*y);

    xi_inf_hat = inf - alpha/beta*y_star + alpha/(alpha^2+beta)*eps_hat;
    xi_y_hat   = y - beta/(alpha^2+beta)*eps_hat;

    inf_hat = alpha/beta*y_star - alpha/(alpha^2+beta)*eps_hat;
    y_hat   = beta/(alpha^2+beta)*eps_hat;
else %incorrect beliefs (=deviated)     
    inf_e = alpha/beta_old*y_star;
    const = (alpha^2+beta_new)/ ...
        ( (alpha^2+beta_new)^2*s_inf^2*s_y^2+alpha^2*s_y^2*s_eps^2+beta_new^2*s_inf^2*s_eps^2);
        
    eps_hat = const * ( ...
        -alpha*s_eps^2*s_y^2*(inf-alpha/(alpha^2+beta_new)*y_star-alpha^2/(alpha^2+beta_new)*inf_e) ...
        +beta_new*s_inf^2*s_eps^2*(y-alpha^2/(alpha^2+beta_new)*y_star-alpha*beta_new/(alpha^2+beta_new)*inf_e) ...
        );
    
    inf_hat = (alpha  * y_star + alpha^2       *inf_e - alpha   *eps_hat)/(alpha^2+beta_new);
    y_hat   = (alpha^2* y_star - alpha*beta_new*inf_e + beta_new*eps_hat)/(alpha^2+beta_new);
    

    xi_inf_hat = inf - inf_hat;
    xi_y_hat   = y - y_hat;
end





                
                
                
                
                
                
                
                
                
                
                
function [eps_hat,y_hat,inf_hat,xi_y_hat,xi_inf_hat] = 	Signal_extraction_D(y,inf,y_target,beta_h)

global alpha, beta_l, y_star, sigma_eps, sigma_y, sigma_inf

inf_e = alpha/beta_h*y_target;

denominator = 1/sigma_eps^2 + (alpha/(alpha^2+beta_l))^2/(sigma_inf^2) + (beta_l/(alpha^2+beta_l))^2/(sigma_y^2);
nominator1 = ( alpha/(alpha^2+beta_l)*inf - (alpha/(alpha^2+beta_l))^2*y_star + alpha^3/(alpha^2+beta_l)^2*inf_e)/(sigma_inf^2);
nominator2 = ( -beta_l/(alpha^2+beta_l)*y+ alpha^2*beta_l/(alpha^2+beta_l)^2*y_star - alpha*beta_l^2/(alpha^2+beta_l)^2*inf_e)/(sigma_y^2);

eps_hat = (nominator1 + nominator2)/denominator;

inf_hat = (alpha  *y_star + alpha^2       *inf_e - alpha *eps_hat)/(alpha^2+beta_l);
y_hat   = (alpha^2*y_star - alpha  *beta_l*inf_e - beta_l*eps_hat)/(alpha^2+beta_l);

xi_inf_hat = inf_hat - inf;
xi_y_hat   = y_hat   - y;

function [eps_hat,y_hat,inf_hat,xi_y_hat,xi_inf_hat] = 	Signal_extraction_ND(y,inf,y_target,beta_h)

global alpha, beta_l, y_star, sigma_eps, sigma_y, sigma_inf

inf_e = alpha/beta_h*y_target;

denominator = 1/sigma_eps^2 + (alpha/(alpha^2+beta_h))^2/(sigma_inf^2) + (beta_h/(alpha^2+beta_h))^2/(sigma_y^2);
nominator1 =  alpha/(alpha^2+beta_h)*(inf-inf_e)/(sigma_inf^2);
nominator2 = beta_h/(alpha^2+beta_h)*y/(sigma_y^2);

eps_hat = (nominator1 + nominator2)/denominator;

inf_hat = (alpha  *y_star + alpha^2       *inf_e - alpha *eps_hat)/(alpha^2+beta_h);
y_hat   = (alpha^2*y_star - alpha  *beta_h*inf_e - beta_h*eps_hat)/(alpha^2+beta_h);

xi_inf_hat = inf_hat - inf;
xi_y_hat   = y_hat   - y;

        





                
                