function [VF,PF,reaction_y,reaction_inf] ...
            = ...
Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob, ...
d_grid,method,theta_init,Vf_init,grid_eps,constraint,int_method)
%one period of punishment only
global alpha y_star y_target s_eps beta_l beta_h delta turn_off_the_switch;


disp('----------------------------------------------------------------------------------')
%% initialisation
[meshgrid_inf,meshgrid_y] = meshgrid(Prob_inf,Prob_y);

y_ND = beta_h/(alpha^2+beta_h)*epsilon;
inf_ND = alpha/beta_h*y_target - alpha/(alpha^2+beta_h)*epsilon;

inf_e_D = alpha/beta_h*y_target;


allocation_inf = @(beta)(alpha  * y_target + alpha^2     *inf_e_D - alpha *epsilon)/(alpha^2+beta);
allocation_y   = @(beta)(alpha^2* y_target - alpha*beta  *inf_e_D + beta  *epsilon)/(alpha^2+beta);


inflation = zeros(size(d_grid,2),size(epsilon,2));
output    = zeros(size(d_grid,2),size(epsilon,2));
P         = zeros(size(d_grid,2),size(epsilon,2));
L_NP      = zeros(size(d_grid,2),size(epsilon,2));

for i=1:size(d_grid,2)
    inflation(i,:) = allocation_inf(beta_h)   + 1/alpha*d_grid(i);
    output(i,:)    = allocation_y(beta_h) +         d_grid(i);
    
    P(i,:)         = interp2(meshgrid_inf,meshgrid_y,Prob,inflation(i,:),output(i,:),'*linear');
    L_NP(i,:)        = 0.5*(output(i,:)-y_star).^2 + 0.5* beta_l * inflation(i,:).^2;
end



%% initial values
if isempty(Vf_init)
    V_NP_new = 950*ones(size(epsilon));
else
    V_NP_new = Vf_init;
end


%Gauss-Hermite quadrature, just for the first iteration
[nodes, weights] = GaussHermite(12);
EV_NP =  1/sqrt(pi)*weights'* interp1(epsilon,V_NP_new,(sqrt(2)*s_eps.*nodes),'linear','extrap');
simpson_int_norm(epsilon,V_NP_new,0,s_eps);

%expected value while being punished E[V^p(eps)]
EL_punished = 1/2*beta_l/(alpha^2+beta_l)*s_eps^2+1/2*(alpha^2+beta_l)/beta_l*y_star^2;
EV_P = EL_punished + delta*EV_NP;
%EV_P = EL_punished/(1-delta);


disp('Value function iteration...');

fprintf('PF approximation method: ');
switch method
    case  'no_con'
        fprintf('none (standard value function iteration),');
    case 'con_polyval'
        fprintf('normal polynomials, ');
    case 'con_CHpol'
        fprintf('Chebyshev polynomials, ');
    case 'con_LinInt'
        fprintf('Linear interpolation, ');
end
fprintf('constraint: %s, integration method: %s \n',constraint, int_method);





%% Iteration
cont  = 1;
count = 0;
diff  = 100;
while cont

    if diff<tolerance
        cont=0;
    else
        count=count+1;
        V_NP = V_NP_new;
         
        switch  int_method
            case 'gauss_quadrature'
                EV_NP = gaussian_quadrature(epsilon,V_NP,s_eps,nodes);
            case 'Simpson'       
                EV_NP = simpson_int_norm(epsilon,V_NP,0,s_eps);
        end
        
        EV_P = EL_punished + delta*EV_NP; %update expected value of being punished
        
        switch method
            case  'no_con'
                [V_NP_new PF] = min(L_NP +  delta*(P*EV_P+(1-P)*EV_NP));
%             case 'con_polyval'
%                 [V_NP_new,PF,theta_solution] = ...
%                     min_Vf_NP_polyval(delta, EV_NP, EV_P,...
%                          Prob,Prob_y,Prob_inf,theta_init,beta_h,beta_l,alpha,y_star,y_target,s_eps,epsilon,[],constraint,int_method);
%                     theta_init = 0.99*theta_solution + 0.01*theta_init;
            case 'con_CHpol'
                [V_NP_new,PF,theta_solution] = ...
                    min_Vf_NP_CHpol(delta, EV_NP, EV_P,...
                        Prob,Prob_y,Prob_inf,theta_init,beta_h,beta_l,alpha,y_star,y_target,s_eps,epsilon,[],constraint,int_method,turn_off_the_switch);
                    theta_init = 0.99*theta_solution + 0.01*theta_init;
            case 'con_LinInt'
                [V_NP_new,PF,theta_solution] = ...
                    min_Vf_NP_LinInt(delta, EV_NP, EV_P,...
                        Prob,Prob_y,Prob_inf,theta_init,beta_h,beta_l,alpha,y_star,y_target,s_eps,epsilon,grid_eps,constraint,int_method,turn_off_the_switch);
                    theta_init = 0.99*theta_solution + 0.01*theta_init;
        end
        
        diff = max(abs((V_NP_new-V_NP)./V_NP));
        
        if mod(count,4)==0
            fprintf('*');
        end
        
        if mod(count,160)==0
            fprintf('diff: %4.7f \n',diff);
        end
        
        if count>2500
            disp('reached 2500 iterations, stopping !!!');
            cont=0;
        end
        
    end
end
fprintf('\n');
disp(strcat(num2str(count),' iterations needed to converge, done.'));
switch method
    case 'no_con'
            PF2 = NaN*zeros(1,size(epsilon,2));
            for i=1:size(epsilon,2)
                PF2(i) = d_grid(PF(i));
            end
            PF=PF2;
            
    case 'con_polyval'
            disp('estimated theta:');
            disp(theta_init);
            
    case 'con_CHpol'
            disp('estimated theta:');
            disp(theta_init);
end


%simpson_int_norm(epsilon,V_NP_new,0,s_eps);
%% figures
% figure(100)
% plot(epsilon,PF,'r');
% ylabel('deviation');xlabel('\epsilon');hline(0);vline(0);

for i=1:size(epsilon,2)
    vector=zeros(size(epsilon)); vector(i)=1; vector=vector';    
    reaction_y(i)=allocation_y(beta_h)*vector+PF(i);
    reaction_inf(i)=allocation_inf(beta_h)*vector+PF(i)/alpha;
end

%generate the figure with the optimal outcomes
% figure(101)
% plot(reaction_y,reaction_inf,'blue'); hold on;
% plot(allocation_y(beta_h),allocation_inf(beta_h),'red'); hold on;
% plot(allocation_y(beta_l),allocation_inf(beta_l),'red'); hold on;
% hline(0);vline(0);
% ylabel('\pi');xlabel('Prob_y');legend('Optimal','\beta_{high}','\beta_{low}')
% hold off;
    


VF = V_NP_new;
%simpson_int_norm(epsilon,VF,0,s_eps);
disp('----------------------------------------------------------------------------------')    


    function fval=gaussian_quadrature(x,fx,s_eps,nodes)
        fval = 1/sqrt(pi)*weights'* interp1(x,fx,(sqrt(2)*s_eps.*nodes),'linear','extrap');
    end

end



