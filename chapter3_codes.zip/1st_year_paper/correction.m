global alpha y_star y_target s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target_dir;

target_dir = 'C:\Documents and Settings\fr282\My Documents\MATLAB\1st_year_paper\';

for i=[2 201 202 203 204 205 206 207 208 209 210]
    cd(target_dir);
    
    cd parameters;
    string = strcat('Parameters_',int2str(i));
    load(string);
    parameters_unload;
    cd ..
    
    cd Pmat;
    string = strcat('Pun_matrix_',int2str(i));
    load(string);
    cd ..
    
 
    cd R_reg;
    string = strcat('R_reg_matrix_',int2str(i));
    load(string);
    cd ..
    
    
       %%
        % setup
        int_method = 'gauss_quadrature';     
        %int_method = 'Simpson';%choose method to compute expected value
        constraint = 'yes';  %constrint setup
        cutoff = norminv(0.975,0,s_eps);
        ind_first = find(epsilon>-cutoff,1, 'first');
        ind_last  = find(epsilon>cutoff,1, 'first');
        
        
        

        
        

        %% 0-1 setup
        % 0-0 deviation only, normal value function iteration
        method='01';
        [VF_01,PF_01,reaction_y_01,reaction_inf_01] = ...
            Paper_VI_full_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,[],[]);

        %continuous deviation, normal value function iteration
        method='no_con';
        [VF_no_con,PF_no_con,reaction_y_no_con,reaction_inf_no_con] = ...
            Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,[],[],constraint,int_method);


        %continuous deviation, approximating the policy function by chebyshev
        %polynomials and iterating on E[V]    
        order = 14;
        [theta_init,PF_no_con_fitted] = cheb_estimation(order,PF_no_con,epsilon); %find the starting values  from normal value function iteration


        method='con_CHpol';
        [VF_conCH,PF_conCH,reaction_y_CHpol,reaction_inf_CHpol] = ...
            Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,[],constraint,int_method);


        %continuous deviation, approximating the policy function by linear
        %approxiamtion and iterating on E[V]       
        method='con_LinInt';
        grid_eps = min(epsilon):0.5:max(epsilon);
        theta_init = interp1(epsilon,PF_no_con,grid_eps); %find starting conditions from normal value function iteration
        [VF_conLI,PF_conLI,reaction_y_LinInt,reaction_inf_LinInt] = ...
            Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,grid_eps,constraint,int_method);
        
        %
         int_method = 'Simpson';


        %continuous deviation, approximating the policy function by chebyshev
        %polynomials and iterating on E[V]    
        order = 12;
        [theta_init,PF_no_con_fitted] = cheb_estimation(order,PF_no_con,epsilon); %find the starting values  from normal value function iteration


        method='con_CHpol';
        [VF_conCH2,PF_conCH2,reaction_y_CHpol2,reaction_inf_CHpol2] = ...
            Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,[],constraint,int_method);


        %continuous deviation, approximating the policy function by linear
        %approxiamtion and iterating on E[V]       
        method='con_LinInt';
        grid_eps = min(epsilon):0.5:max(epsilon);
        theta_init = interp1(epsilon,PF_no_con,grid_eps); %find starting conditions from normal value function iteration
        [VF_conLI2,PF_conLI2,reaction_y_LinInt2,reaction_inf_LinInt2] = ...
            Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,grid_eps,constraint,int_method);

        
        %% save value functions and policy functions
        results_save;
end
    
