



function  [V_NP_new,PF,theta_solution] = ...
    min_Vf_NP(delta, EV_NP, EV_P,Prob_matrix,y_grid,inf_grid,theta_init,beta_h,beta_l,alpha,y_star,s_eps,epsilon)
    
    [nodes, weights] = GaussHermite(12);
    nodes=nodes';

    
    
    
    
    %epsilon = nodes;

    allocation_y   = @(epsilon,theta)                       beta_h/(alpha^2+beta_h)*epsilon + FP_approx(theta,epsilon)      ;
    allocation_inf = @(epsilon,theta) alpha/beta_h*y_star -  alpha/(alpha^2+beta_h)*epsilon + FP_approx(theta,epsilon)/alpha; 

    loss = @(epsilon,theta) 0.5*(allocation_y(epsilon,theta)-y_star).^2+beta_l/2*allocation_inf(epsilon,theta).^2;


    [y_mgrid inf_mgrid] = meshgrid(y_grid,inf_grid);
    Probability = @(epsilon,theta) ...
        interp2( ...
                    y_mgrid,inf_mgrid,Prob_matrix',allocation_y(epsilon,theta),...
                    allocation_inf(epsilon,theta), ...
                '*linear',1);

    value =  @(epsilon,theta) loss(epsilon,theta)+ ...
        delta*( Probability(epsilon,theta)*EV_NP + ( 1 - Probability(epsilon,theta) )*EV_P );


    expected_value = @(theta) 1/pi* value(sqrt(2)*s_eps.*nodes,theta)*weights;
    expected_deviation = @(theta) 1/pi* FP_approx(theta,sqrt(2)*s_eps*nodes)*weights;

  % [x,fval] = fminunc(expected_value,[0,0])


    A   = [];
    b   = [];
    Aeq = [];
    beq = [];
    lb  = [];
    ub  = [];

    
   options = optimset('TolFun',1e10,'TolX',1e-15,'Display','off','algorithm','interior-point');
   theta_solution = fmincon(expected_value,theta_init,A,b,Aeq,beq,lb,ub,@mycon,options);
   
   
   PF       = FP_approx(theta_solution,epsilon);
   V_NP_new = value(epsilon,theta_solution);   
  
   


    %define the nonlinear constraint
    function [c,ceq] = mycon(theta)
        c = [];                             % Compute nonlinear inequalities at x.
        ceq =  [];%expected_deviation(theta);    % Compute nonlinear equalities at x.
    end

    function fval = FP_approx(theta,xx)
        %xx row vector
        
        X_min = min(xx);
        X_max = -X_min; %because the hermine nodes are symetric
         
        x = xx/(X_max-X_min); %rescaling, is it needed?
        if size(xx,1)==1
            x=x';
        end
        
        theta_sw = fliplr(theta);
        
        Her_matrix = ones(size(theta_sw,2),size(x',2));
        Her_matrix(2,:) = x';
        
        for i=2:size(theta_sw,2)-1
            Her_matrix(i+1,:) = 2*x'.*Her_matrix(i,:)-Her_matrix(i-1,:);
        end
        
        fval = (theta*Her_matrix*(X_max-X_min));
        
    end
        
        
        
        
        


end