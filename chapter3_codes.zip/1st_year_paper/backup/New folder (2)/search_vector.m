function plausible_policy=search_vector(history,Data_matrix,tolerance,plausible_policy,n_steps)

global counter;

sigma   = 1;

    if size(history,2) == size(Data_matrix,2)
       
        sigma=1;

        policy_function = zeros(size(history,2),1);
        %transform history (indices) into deviations
        for i=1:size(history,2)
            policy_function(i) = Data_matrix(history(i),i);
        end
        
        
        %get expectations
        [nodes, weights] = GaussHermite(5);
        expected_deviation = 1/pi*weights'* interp1(-3:3,policy_function,(sqrt(2)*sigma.*nodes),'linear','extrap');

        
        if expected_deviation^2<tolerance
            plausible_policy=[plausible_policy;policy_function];
        end
        
        
        counter=counter+1;
        
        if mod(counter,5*floor(n_steps/100))==0
            percent = counter/floor(n_steps/100);
            fprintf('done %i%%,\t found: \t\t\t\t  %10.i\n',percent, size(plausible_policy,1));
        end     

        
    else
        for i=1:size(Data_matrix,1)
            new_history = [history i];
            %disp(new_history);
            plausible_policy = search_vector(new_history,Data_matrix,tolerance,plausible_policy,n_steps);
        end
        
    end
    
    
end
        
    

