function [VF,PF,reaction_y,reaction_inf]=Paper_VI_full_d(epsilon,tolerance,y,inf,Prob,d_grid)

global alpha y_star s_eps beta_l beta_h delta;




%% initialisation
[meshgrid_inf,meshgrid_y] = meshgrid(inf,y);

y_ND = beta_h/(alpha^2+beta_h)*epsilon;
inf_ND = alpha/beta_h*y_star - alpha/(alpha^2+beta_h)*epsilon;

inf_e_D = alpha/beta_h*y_star;


allocation_inf = @(beta)(alpha  * y_star + alpha^2     *inf_e_D - alpha *epsilon)/(alpha^2+beta);
allocation_y   = @(beta)(alpha^2* y_star - alpha*beta  *inf_e_D + beta  *epsilon)/(alpha^2+beta);


inflation = zeros(size(d_grid,2),size(epsilon,2));
output    = zeros(size(d_grid,2),size(epsilon,2));
P         = zeros(size(d_grid,2),size(epsilon,2));
L_NP      = zeros(size(d_grid,2),size(epsilon,2));

for i=1:size(d_grid,2)
    inflation(i,:) = allocation_inf(beta_h)   + 1/alpha*d_grid(i);
    output(i,:)    = allocation_y(beta_h) +         d_grid(i);
    
    P(i,:)         = interp2(meshgrid_inf,meshgrid_y,Prob,inflation(i,:),output(i,:),'linear');
    L_NP(i,:)        = 0.5*(output(i,:)-y_star).^2 + 0.5* beta_l * inflation(i,:).^2;
end



%%

%expected value while being punished E[V^p(epsilon)]
%EL_punished =
%(0.5*beta_l/(alpha^2+beta_l)*s_eps^2+0.5*(alpha^2+beta_l)/beta_l*y_star^2)
%;   WRONG!!!!!!   L(E[epsilon]) != E[(L(epsilon))]!!!!!!!!!
EL_punished = 1/2*beta_l/(alpha^2+beta_l)*s_eps^2+1/2*(alpha^2+beta_l)/beta_l*y_star^2;
EV_P = EL_punished/(1-delta);

V_NP_new = zeros(size(epsilon));




%Gauss-Hermite quadrature (just to remember for the iteration)
[nodes, weights] = GaussHermite(12);
EV_NP =  1/pi*weights'* interp1(epsilon,V_NP_new,(sqrt(2)*s_eps.*nodes),'linear','extrap');


%% Iteration
cont = 1;
count=0;
diff = 100;
while cont

    if diff<tolerance
        cont=0;
    else
        count=count+1;
        V_NP = V_NP_new;
        EV_NP =  1/pi*weights'* interp1(epsilon,V_NP,(sqrt(2)*s_eps.*nodes),'linear','extrap');
        
        [V_NP_new PF] = min(L_NP +  delta*(P*EV_P+(1-P)*EV_NP));
                
        diff = max(abs(V_NP_new-V_NP)./V_NP); 
    end
end
disp(strcat(num2str(count),' iterations needed to converge, done.'));


PF2 = NaN*zeros(1,size(epsilon,2));
for i=1:size(epsilon,2)
    PF2(i) = d_grid(PF(i));
end

PF=PF2;

%% figures
figure(100)
plot(epsilon,PF,'r');
ylabel('deviation');xlabel('\epsilon');hline(0);vline(0);



for i=1:size(epsilon,2)
    vector=zeros(size(epsilon)); vector(i)=1; vector=vector';    
    reaction_y(i)=allocation_y(beta_h)*vector+PF2(i);
    reaction_inf(i)=allocation_inf(beta_h)*vector+PF2(i)/alpha;
end

%generate the figure with the optimal outcomes
% figure(101)
% plot(reaction_y,reaction_inf,'blue'); hold on;
% plot(allocation_y(beta_h),allocation_inf(beta_h),'red'); hold on;
% plot(allocation_y(beta_l),allocation_inf(beta_l),'red'); hold on;
% hline(0);vline(0);
% ylabel('\pi');xlabel('y');legend('Optimal','\beta_{high}','\beta_{low}')
% hold off;
    
    

VF = V_NP_new;







