
clear all;clc;
options = optimset('algorithm','active-set','Display','off');

%% Parameters
%CB preference
beta=7.5/1.5;

%PC parameter
alpha  = 1;
y_star = 5;
%variances
s_eps = 2;
s_inf  = 1;
s_y   = 1;



%inf_e inflation expectations
inf_e = alpha/beta*y_star;



%% bounds on region
y_min   =  0;
y_max   =   4;

inf_min =   -6;
inf_max =  2;

N_inf = 200;
N_y   = 200;

%% Analytical solution
% Unconstrained allocation
arrows_unc = [];
for i=1:N_inf
    for j=1:N_y
        inf = inf_min + (inf_max-inf_min)/(N_inf-1)*(i-1);
        y = y_min + (y_max-y_min)/(N_y-1)*(j-1);

        inf_hat = 1/(alpha^2*s_inf^2 + s_y^2+s_eps^2)*(alpha^2* s_inf^2* inf_e + (s_y^2 + s_eps^2)*inf + alpha*s_inf^2* y);
        y_hat  = (alpha * s_y^2)/(s_y^2+s_eps^2)* (inf_hat-inf_e) + (s_eps^2)/(s_y^2+s_eps^2)*y;
        
        if (inf_hat < 0 && y_hat <= y_star)
            inf_hat = 0;
            y_hat   = (s_eps^2*y-alpha*s_y^2*inf_e)/(s_eps^2+s_y^2);
            disp('zero inflation bound hit');
        end
        
        eps_hat = y_hat-alpha*(inf_hat-inf_e);
        xi_inf_hat = inf-inf_hat;
        xi_y_hat  = y-y_hat;
        
        ll_unc(j,i) = -1/2*(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2)) ...
            - eps_hat^2/(2*s_eps^2)-xi_y_hat^2/(2*s_y^2)-xi_inf_hat^2/(2*s_inf^2);
        
        loc_unc(:,:,j,i) = [inf_hat
                            y_hat];
          
        arrows_unc = [arrows_unc;y inf y_hat inf_hat];
        

    end
end






 [inflation,outputgap] = meshgrid(inf_min:(inf_max-inf_min)/(N_inf-1):inf_max, y_min:(y_max-y_min)/(N_y-1):y_max); 

% 
% constrained allocation
        arrows_c=[];
        const1 = -s_y^2*s_inf^2*s_eps^2*(alpha^2+beta)/(s_inf^2*s_y^2*(alpha^2+beta)^2+s_y^2*s_eps^2*alpha^2+s_inf^2*s_eps^2*beta^2);
        for i=1:N_inf
            for j=1:N_y
                inf = inf_min + (inf_max-inf_min)/(N_inf-1)*(i-1);
                y = y_min + (y_max-y_min)/(N_y-1)*(j-1);

                eps_hat = const1 * ( -alpha^2/(beta*s_inf^2)*y_star + alpha/s_inf^2*inf - beta/s_y^2*y);

                xi_inf_hat = inf - alpha/beta*y_star + alpha/(alpha^2+beta)*eps_hat;
                xi_y_hat   = y - beta/(alpha^2+beta)*eps_hat;
                
                inf_hat = alpha/beta*y_star - alpha/(alpha^2+beta)*eps_hat;
                y_hat   = beta/(alpha^2+beta)*eps_hat;

                ll_c(j,i) = -1/2*(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2)) ...
                    - eps_hat^2/(2*s_eps^2)-xi_y_hat^2/(2*s_y^2)-xi_inf_hat^2/(2*s_inf^2);

                arrows_c = [arrows_c;y inf y_hat inf_hat];
            end
        end

    
    
% get bounds for no-revision region
kappa_pos = 0.95; %revison constant    
kappa_neg = 2-kappa_pos;
norevison = zeros(size(ll_unc));


for i=1:N_inf
    for j=1:N_y
        if ll_unc(j,i) >0 && ll_c(j,i)>kappa_pos*ll_unc(j,i) 
            norevison(j,i) = 1;
        end
        
        if ll_unc(j,i) <0 && ll_c(j,i)>kappa_neg*ll_unc(j,i) 
            norevison(j,i) = 1;
        end
    end
end





%get index of first and last row of no revision region

for j=1:N_y
    first(j) = 1;
    i=1;
    while norevison(j,i)==0 && i < N_inf
        first(j) = first(j)+1;
        i=i+1;
    end
    
    last(j) = first(j);
    
    if i < N_inf
        i=i+1;
    end
    
    while norevison(j,i)==1 && i < N_inf
        last(j) = last(j)+1;
        i=i+1;
    end
end


first_fval = inf_min + (inf_max-inf_min)/(N_inf-1)*(first-1);
last_fval  = inf_min + (inf_max-inf_min)/(N_inf-1)*(last-1);

grid = y_min:(y_max-y_min)/(N_y-1):y_max;

figure(7)
plot(grid,first_fval,grid,last_fval,...
   grid,alpha/beta*(y_star- grid))
%hline(0); vline(0);

data_first = [grid;first_fval]';
data_last  = [grid;last_fval]';


%export
%dir = 'C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_proposal\';
dir = 'C:\Users\Filip Rozsypal\Documents\Cambridge\1st_year_paper_proposal\';

filename = 'region.dat';

target = strcat(dir, filename);

fid = fopen(target,'w');
for i=1:N_y-1
    fprintf(fid,' %2.2f  %2.2f\n',  data_last(i,:));    
end
fprintf(fid,' %2.2f  %2.2f\n',  data_last(N_y,:)); 

for i=1:N_y
    fprintf(fid,'%2.2f %2.2f \n',  data_first(N_y+1-i,:));    
end
fprintf(fid,'%2.2f %2.2f',  data_first(1,:)); 
fclose(fid);


%%

filename = 'arrows_c.dat';

target = strcat(dir, filename);

fid = fopen(target,'w');
for i= 1:size(arrows_c,1)
    fprintf(fid,'\\draw[->,thin,red] (%2.2f,%2.2f) -- (%2.2f, %2.2f);',  arrows_c(i,:));    
end
fclose(fid);

filename = 'arrows_unc.dat';

target = strcat(dir, filename);

fid = fopen(target,'w');
for i= 1:size(arrows_unc,1)
    fprintf(fid,'\\draw[->,thin,blue] (%2.2f,%2.2f) -- (%2.2f, %2.2f);',  arrows_unc(i,:));    
end
fclose(fid);

% fid = fopen('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_proposal\aaa3.tex','w');
% for i= 1:size(arrows_unc_a,1)
%     fprintf(fid,'\\draw[->,very thin,orange] (%2.2f,%2.2f) -- (%2.2f, %2.2f);',  arrows_unc_a(i,:));    
% end
% fclose(fid);

%%


% fid = fopen('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_proposal\dots155.tex','w');
% for i=1:N_inf
%     for j=1:N_y
%         if norevison(j,i)==1
%             inf = inf_min + (inf_max-inf_min)/(N_inf-1)*(i-1);
%             y = y_min + (y_max-y_min)/(N_y-1)*(j-1);
%             exporting= [y inf];
%             fprintf(fid,'\\fill[yellow,opacity=0.5] (%2.2f,%2.2f) circle (2pt);',  exporting);
%         end
%     end
% end




