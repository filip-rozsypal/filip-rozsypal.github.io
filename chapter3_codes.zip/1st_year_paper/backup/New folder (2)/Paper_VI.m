function [VF,PF,V_NP_D,V_NP_ND]=Paper_VI(epsilon,tolerance,y,inf,Prob)

global alpha y_star s_eps beta_l beta_h delta;



%% initialisation



y_ND = beta_h/(alpha^2+beta_h)*epsilon;
inf_ND = alpha/beta_h*y_star - alpha/(alpha^2+beta_h)*epsilon;

inf_e_D = alpha/beta_h*y_star;
inf_D     = (alpha  * y_star + alpha^2     *inf_e_D - alpha   *epsilon)/(alpha^2+beta_l);
y_D       = (alpha^2* y_star - alpha*beta_l*inf_e_D + beta_l  *epsilon)/(alpha^2+beta_l);


[inflation,outputgap] = meshgrid(inf,y);
P_D = interp2(inflation,outputgap,Prob,inf_D,y_D,'linear');
P_ND = interp2(inflation,outputgap,Prob,inf_ND,y_ND,'linear');

figure(3)
plot(epsilon,P_D,epsilon,P_ND)
xlabel('\epsilon'); ylabel('Prabability of revision'); legend('D','ND')

figure(4)
plot(y_D,inf_D,y_ND,inf_ND);legend('D','ND');
%%

%expected value while being punished E[V^p(eps)]
EV_P = ones(size(eps))/(1-delta)*0.5*beta_l/(alpha^2+beta_l)*s_eps^2+0.5*(alpha^2+beta_l)/beta_l*y_star^2;

%current loss of NotDeviating while not being punished
L_NP_ND = 0.5*(y_ND-y_star).^2 + 0.5* beta_l * inf_ND.^2;

%current loss of Deviating while not being punished
L_NP_D  = 0.5*(y_D -y_star).^2 + 0.5* beta_l * inf_D .^2;








% figure(5)
% plot(epsilon,L_NP_D,epsilon,L_NP_ND);
% xlabel('\epsilon'); ylabel('Loss'); legend('D','ND')

V_NP_D  =zeros(size(epsilon));
V_NP_ND =zeros(size(epsilon));



%Gauss-Hermite quadrature
[nodes, weights] = GaussHermite(5);
EV_NP =  1/pi*weights'* interp1(epsilon,V_NP,(sqrt(2)*s_eps.*nodes),'linear','extrap');


%% Iteration
disp('Value function iteration')
cont = 1;
count=0;
diff = 100;
while cont

    if diff<tolerance
        cont=0;
    else
        count=count+1;
        V_NP = min(V_NP_D,V_NP_ND);
        EV_NP =  1/pi*weights'* interp1(epsilon,V_NP,(sqrt(2)*s_eps.*nodes),'linear','extrap');
        
        V_NP_D  = L_NP_D  +delta*(P_D *EV_P+(1-P_D) *EV_NP);
        V_NP_ND = L_NP_ND +delta*(P_ND*EV_P+(1-P_ND)*EV_NP);
        
        V_NP_new = min(V_NP_D,V_NP_ND);
        
        diff = max(abs(V_NP_new-V_NP));
        
        
    end
end
deviation=(V_NP_D>V_NP_ND);
disp(strcat(num2str(count),' iterations needed to converge, done.'));


PF = deviation;
VF = V_NP;
