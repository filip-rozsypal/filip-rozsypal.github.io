
clear all;clc;

%% Parameters
%CB preference
beta=7.5/1.5;

%PC parameter
alpha  = 1;
y_star = 5;
%variances
s_eps = 2;
s_inf  = 1;
s_y   = 1;



%inf_e inflation expectations
inf_e = alpha/beta*y_star;



%% bounds on region
y_min   =  2;
y_max   =   3;

inf_min =   -1;
inf_max =  2;

N_inf = 15;
N_y   = 15;

% %% Analytical solution
% % Unconstrained allocation
% arrows_unc = [];
% for i=1:N_inf
%     for j=1:N_y
%         inf = inf_min + (inf_max-inf_min)/(N_inf-1)*(i-1);
%         y = y_min + (y_max-y_min)/(N_y-1)*(j-1);
% 
%         inf_hat = 1/(alpha^2*s_inf^2 + s_y^2+s_eps^2)*(alpha^2* s_inf^2* inf_e + (s_y^2 + s_eps^2)*inf + alpha*s_inf^2* y);
%         y_hat  = (alpha * s_y^2)/(s_y^2+s_eps^2)* (inf_hat-inf_e) + (s_eps^2)/(s_y^2+s_eps^2)*y;   
% 
%         eps_hat = y_hat-alpha*(inf_hat-inf_e);
%         xi_inf_hat = inf-inf_hat;
%         xi_y_hat  = y-y_hat;
%         
%         ll_unc(j,i) = -1/2*(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2)) ...
%             - eps_hat^2/(2*s_eps^2)-xi_y_hat^2/(2*s_y^2)-xi_inf_hat^2/(2*s_inf^2);
%         
%         loc_unc(:,:,j,i) = [inf_hat
%                             y_hat];
%           
%         arrows_unc = [arrows_unc;y inf y_hat inf_hat];
%     end
% end
% 
 [inflation,outputgap] = meshgrid(inf_min:(inf_max-inf_min)/(N_inf-1):inf_max, y_min:(y_max-y_min)/(N_y-1):y_max); 
% figure(1)
% surf(outputgap,inflation,ll_unc);
% title('unconstrained')
% xlabel('y');ylabel('\pi');zlabel('log-likelihood');
% 
% % constrained allocation
%         arrows_c=[];
%         const1 = -s_y^2*s_inf^2*s_eps^2*(alpha^2+beta)/(s_inf^2*s_y^2*(alpha^2+beta)^2+s_y^2*s_eps^2*alpha^2+s_inf^2*s_eps^2*beta^2);
%         for i=1:N_inf
%             for j=1:N_y
%                 inf = inf_min + (inf_max-inf_min)/(N_inf-1)*(i-1);
%                 y = y_min + (y_max-y_min)/(N_y-1)*(j-1);
% 
%                 eps_hat = const1 * ( -alpha^2/(beta*s_inf^2)*y_star + alpha/s_inf^2*inf - beta/s_y^2*y);
% 
%                 xi_inf_hat = inf - alpha/beta*y_star + alpha/(alpha^2+beta)*eps_hat;
%                 xi_y_hat   = y - beta/(alpha^2+beta)*eps_hat;
%                 
%                 inf_hat = alpha/beta*y_star - alpha/(alpha^2+beta)*eps_hat;
%                 y_hat   = beta/(alpha^2+beta)*eps_hat;
% 
%                 ll_c(j,i) = -1/2*(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2)) ...
%                     - eps_hat^2/(2*s_eps^2)-xi_y_hat^2/(2*s_y^2)-xi_inf_hat^2/(2*s_inf^2);
% 
%                 arrows_c = [arrows_c;y inf y_hat inf_hat];
%             end
%         end
% 
% 
% 
% figure(2)
% surf(outputgap,inflation,ll_c);
% title('constrained')
% xlabel('y');ylabel('\pi');zlabel('log-likelihood');
% 
% % comparison
% figure(3)
% surf(outputgap,inflation,ll_c./ll_unc);
% xlabel('y');ylabel('pi');zlabel('relative log-likelihood');

%% numerical solution

%constrained
 arrows_c=[];
for i=1:N_inf
    for j=1:N_y
        inf = inf_min + (inf_max-inf_min)/(N_inf-1)*(i-1);
        y = y_min + (y_max-y_min)/(N_y-1)*(j-1);

       loglikelihood=@(X) -1*(-1/2*(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2)) ...
           - (X(1)-alpha*(X(2)-inf_e))^2/(2*s_eps^2)-(X(1)-y)^2/(2*s_y^2)-(X(2)-inf)^2/(2*s_inf^2));
       
       
        [target,ll_c_num(j,i)] = fmincon(loglikelihood,[0;inf_e],[],[],[1 beta/alpha ],y_star,[],[],[]);
       arrows_c=[arrows_c;y inf target'];
    end
end
ll_c_num = -ll_c_num; %changing back from maximum


%unconstrained
arrows_unc=[];
for i=1:N_inf
    for j=1:N_y
        inf = inf_min + (inf_max-inf_min)/(N_inf-1)*(i-1);
        y = y_min + (y_max-y_min)/(N_y-1)*(j-1);

       %loglikelihood=@(X) -1*( -1/2*(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2)) ...
       %    - (X(1)-alpha*(X(2)-inf_e))^2/(2*s_eps)-(X(1)-y)^2/(2*s_y)-(X(2)-inf)^2/(2*s_inf) );
       
          loglikelihood=@(X)-1*( -log(2*pi*s_eps^2)/2 -log(2*pi*s_inf^2)/2 -log(2*pi*s_y^2)/2 ...
                                 -(X(1)-alpha*(X(2)-inf_e))^2/(2*s_eps^2)...
                                 -(X(1)-y)^2/(2*s_y^2)...
                                 -(X(2)-inf)^2/(2*s_inf^2)...
                                );    
       
       
       %[loc_unc_num(:,:,j,i),ll_unc_num(j,i)] = fminsearch(loglikelihood,[inf;y]);
       

       
        c   = @(x)x(2)*(x(1)-y_star);
        ceq =[];
        pos_const = @(x)deal(c(x),ceq);
       
       [target,ll_unc_num(j,i)] = fmincon(loglikelihood,[0;inf_e],[],[],[],[],[],[],pos_const);
       arrows_unc=[arrows_unc;y inf target'];
       
    end
end
ll_unc_num = -ll_unc_num; %changing back from maximum



    
    
figure(4)
mesh(outputgap,inflation,ll_c_num./ll_unc_num);
xlabel('y');ylabel('\pi');zlabel('relative log-likelihood, numeric');
xlabel('y');ylabel('\pi');zlabel('relative log-likelihood');
    

%figuresize(15,15,'centimeters');
%print(gcf, '-dpdf', '-r300','C:\Documents and Settings\fr282\My Documents\Cambridge\macroworkshop_II\rel_log_lik.pdf');

    
    

 
    
    
% get bounds for no-revision region
kappa_pos = 0.85; %revison constant    
kappa_neg = 2-kappa_pos;
norevison = zeros(size(ll_unc_num));


for i=1:N_inf
    for j=1:N_y
        if ll_unc_num(j,i) >0 && ll_c_num(j,i)>kappa_pos*ll_unc_num(j,i) 
            norevison(j,i) = 1;
        end
        
        if ll_unc_num(j,i) <0 && ll_c_num(j,i)>kappa_neg*ll_unc_num(j,i) 
            norevison(j,i) = 1;
        end
    end
end





%get index of first and last row of no revision region

for j=1:N_y
    first(j) = 1;
    i=1;
    while norevison(j,i)==0 && i < N_inf
        first(j) = first(j)+1;
        i=i+1;
    end
    
    last(j) = first(j);
    
    if i < N_inf
        i=i+1;
    end
    
    while norevison(j,i)==1 && i < N_inf
        last(j) = last(j)+1;
        i=i+1;
    end
end


first_fval = inf_min + (inf_max-inf_min)/(N_inf-1)*(first-1);
last_fval  = inf_min + (inf_max-inf_min)/(N_inf-1)*(last-1);

grid = y_min:(y_max-y_min)/(N_y-1):y_max;

figure(7)
plot(grid,first_fval,grid,last_fval,...
   grid,alpha/beta*(y_star- grid))
%hline(0); vline(0);

data_first = [grid;first_fval]';
data_last  = [grid;last_fval]';


%export
%dir = 'C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_proposal\';
dir = 'C:\Users\Filip Rozsypal\Documents\Cambridge\1st_year_paper_proposal\';

filename = 'region.dat';

target = strcat(dir, filename);

fid = fopen(target','w');
for i=1:N_y-1
    fprintf(fid,' %2.2f  %2.2f\n',  data_last(i,:));    
end
fprintf(fid,' %2.2f  %2.2f\n',  data_last(N_y,:)); 

for i=1:N_y
    fprintf(fid,'%2.2f %2.2f \n',  data_first(N_y+1-i,:));    
end
fprintf(fid,'%2.2f %2.2f',  data_first(1,:)); 
fclose(fid);


%%

filename = 'arrows_c.dat';

target = strcat(dir, filename);

fid = fopen(target,'w');
for i= 1:size(arrows_c,1)
    fprintf(fid,'\\draw[->,thin,red] (%2.2f,%2.2f) -- (%2.2f, %2.2f);',  arrows_c(i,:));    
end
fclose(fid);

filename = 'arrows_unc.dat';

target = strcat(dir, filename);

fid = fopen(target,'w');
for i= 1:size(arrows_unc,1)
    fprintf(fid,'\\draw[->,thin,blue] (%2.2f,%2.2f) -- (%2.2f, %2.2f);',  arrows_unc(i,:));    
end
fclose(fid);

% fid = fopen('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_proposal\aaa3.tex','w');
% for i= 1:size(arrows_unc_a,1)
%     fprintf(fid,'\\draw[->,very thin,orange] (%2.2f,%2.2f) -- (%2.2f, %2.2f);',  arrows_unc_a(i,:));    
% end
% fclose(fid);

%%


% fid = fopen('C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_proposal\dots155.tex','w');
% for i=1:N_inf
%     for j=1:N_y
%         if norevison(j,i)==1
%             inf = inf_min + (inf_max-inf_min)/(N_inf-1)*(i-1);
%             y = y_min + (y_max-y_min)/(N_y-1)*(j-1);
%             exporting= [y inf];
%             fprintf(fid,'\\fill[yellow,opacity=0.5] (%2.2f,%2.2f) circle (2pt);',  exporting);
%         end
%     end
% end




