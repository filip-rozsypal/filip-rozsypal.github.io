
clear all;clc;


target='C:\Users\Filip Rozsypal\Documents\Cambridge\1st_year_paper_proposal\';
%% Parameters
global alpha y_star s_inf s_y s_eps beta_l beta_h inf_e;

%CB preference
beta_l = 7.5/1.5/5;
beta_h = beta_l*8;

%PC parameter
alpha  = 1;
y_star = 5;
%variances
s_eps = 2;
s_inf = 2;
s_y   = 2;


kappa_pos = 0.9; %revison constant    
kappa_neg = 2-kappa_pos;

%% bounds on region
y_min   =  -3;
y_max   =   5;

inf_min =   -3;
inf_max =  6;

%% grid for epsilon
eps = -2:0.25:5;

%% simulation of shocks
N_sim = 5000;
Xi = [s_y^2 0;0 s_inf^2] * randn(2,N_sim);

%%


norevision = zeros(size(eps,2),N_sim);

loglik=@(Shocks) -(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2))/2 ...
                    - Shocks(1)^2/(2*s_eps^2)-Shocks(2)^2/(2*s_y^2)-Shocks(3)^2/(2*s_inf^2);

xi_y_hat   = zeros(2,N_sim);               
xi_inf_hat = zeros(2,N_sim);
eps_hat    = zeros(2,N_sim);
y_hat      = zeros(2,N_sim);
inf_hat    = zeros(2,N_sim);

figure(1)
for i=1:size(eps,2)
    fprintf('epsilon=%2.2f \n',eps(i));
    inf = alpha/beta_h*y_star-alpha/(alpha^2+beta_h)*eps(i);
    y   = beta_h/(alpha^2+beta_h)*eps(i);
    

    X_tilde =[y;inf]*ones(1,N_sim)+Xi;


    for ii=1:N_sim
        [y_hat(1,ii),inf_hat(1,ii),xi_y_hat(1,ii),xi_inf_hat(1,ii),eps_hat(1,ii)] = ...
            CSG(X_tilde(1,ii),X_tilde(2,ii),beta_h,beta_l);
        plot(y_hat(1,ii),inf_hat(1,ii),'.','color','black');hold on;
        [y_hat(2,ii),inf_hat(2,ii),xi_y_hat(2,ii),xi_inf_hat(2,ii),eps_hat(2,ii)] = ...
            CSG(X_tilde(1,ii),X_tilde(2,ii),beta_h,beta_h);
        plot(y_hat(2,ii),inf_hat(2,ii),'.','color','black');hold on;

        if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > 0
            disp('ll>0')
            if loglik([eps_hat(1,ii) xi_y_hat(1,ii) xi_inf_hat(1,ii)]) > ...
                    kappa_pos*loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)])
                norevision(i,ii) = 1;
            end
        else
            if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > ...
                    kappa_neg*loglik([eps_hat(1,ii) xi_y_hat(1,ii) xi_inf_hat(1,ii)])
                norevision(i,ii) = 1;
                plot(X_tilde(1,ii),X_tilde(2,ii),'.','color','r');hold on;
            else
                plot(X_tilde(1,ii),X_tilde(2,ii),'.','color','b');hold on;
            end

        end
        plot(y,inf,'.','color','yellow','MarkerSize',30);hold on;
            
    end
end
axis([-6 8 -5 8]);
hold off;
           
Prob = sum(norevision,2)/size(norevision,2);
figure(2)
plot(eps,Prob)
xlabel('\epsilon'); ylabel('Probability of No revision')
%figuresize(15,10,'centimeters')
%print(gcf, '-dpdf', '-r300', 'C:\Documents and Settings\fr282\My Documents\Cambridge\1st_year_paper_proposal\P_punishment2.pdf')

% 
% [inflation,outputgap] = meshgrid(inf_min:(inf_max-inf_min)/(N_inf-1):inf_max, y_min:(y_max-y_min)/(N_y-1):y_max);         
% figure(2)
% surf(outputgap,inflation,ll_matrix);
% xlabel('y');ylabel('\pi');zlabel('relative log-likelihood');
% 
% figure(3)
% surf(outputgap,inflation,norevison);
% xlabel('y');ylabel('\pi');zlabel('no revision');
% 
% 
% % %% export of arrows
% % target0=strcat(target,'arrows0.dat');
% % fid = fopen(target0,'w');
% % for i= 1:size(arrows1,1)
% %     fprintf(fid,'\\draw[->,thin,green] (%2.2f,%2.2f) -- (%2.2f, %2.2f);',  arrows1(i,:));    
% % end
% % fclose(fid);
% % 
% % target1=strcat(target,'arrows1.dat');
% % fid = fopen(target1,'w');
% % for i= 1:size(arrows0,1)
% %     fprintf(fid,'\\draw[->,thin,pink] (%2.2f,%2.2f) -- (%2.2f, %2.2f);',  arrows0(i,:));    
% % end
% % fclose(fid);
% 
% %% export of circles
% target_circ=strcat(target,'circles.dat');
% fid = fopen(target_circ,'w');
% for i=1:N_inf
%     for j=1:N_y
%         inf = inf_min + (inf_max-inf_min)/(N_inf-1)*(i-1);
%         y = y_min + (y_max-y_min)/(N_y-1)*(j-1);
%         
%         if norevison(j,i) == 1
%             draw = [y,inf];
%             fprintf(fid,' \\fill [pink] (%2.2f,%2.2f) circle (0.05cm);',  draw);   
%         end
%     end
% end
% 
% fclose(fid);
















