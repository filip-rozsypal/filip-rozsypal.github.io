clear all;clc;

set(0,'DefaultFigureWindowStyle','docked');
target='C:\Users\Filip Rozsypal\Documents\Cambridge\1st_year_paper_proposal\';

%% Parameters
global alpha y_star s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg delta target;

% Probability of punishment matrix
load_Pmat = 1;  %1 for loading Pmatrix, 0 for computing
N_sim = 250;    % number of noise shock to simulate in order to compute the probability of punishment
save_matrix = 1;% save Pmatrix or not

tolerance = 0.01; %tolerance in value function iteration
   

%CB preference
beta_l = 7.5/1.5/10;    %-> high inflation expectations
beta_h = beta_l*15;     %->low inflation expectations

%PC parameter
alpha  = 1; %slope of PC curve
y_star = 5; %output target
%variances
s_eps = 2;  %std of supply shock
s_inf = 1;  %std of inflation noise
s_y   = 1;  %std of output noise

delta=0.8; %CB discount factor

kappa_pos = 0.95; %revison constant    
kappa_neg = 2-kappa_pos; %revison constant for negative loglikelihood

% bounds on region for Pmatrix
y_min   =  -15;  y_step   =   0.5;  y_max   =   15;
inf_min =  -15;  inf_step =   0.5;  inf_max =   15;

%grid for state variable in value function iteration
epsilon = -7:0.1:10;
%% Obtain probability of rejection
disp('Obtain probability of rejection...')
if load_Pmat
    load Pun_matrix.mat; disp('loaded...')
else
   [Prob,Prob_y,Prob_inf] = Pmatrix(N_sim,y_min,y_step,y_max,inf_min,inf_step,inf_max,save_matrix);
end


%% Value function iteration
disp('Value function iteration...');
[VF,PF]=Paper_VI_full_d(epsilon,tolerance,Prob_y,Prob_inf,Prob);

%% export figures
figure(100)
figuresize(15,10,'centimeters')
print(gcf, '-dpdf', '-r300', 'C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\deviation_d8_k95_eps2.pdf');

figure(101)
figuresize(15,10,'centimeters')
print(gcf, '-dpdf', '-r300', 'C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\exppath_d8_k95_eps2.pdf');
