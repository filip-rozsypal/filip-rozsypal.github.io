function [theta,fitted] = cheb_estimation(order,y,xx)
disp('estimating the starting values for the VFI using Chebyshev polynomials')

X_min = min(xx);
X_max = -X_min; %because the hermine nodes are symetric

x = xx/(X_max-X_min); %rescaling, is it needed?

if size(xx,1)==1
    x=x';
end

if size(y,1)==1
    y=y';
end



Her_matrix = ones(order,size(x,1));
Her_matrix(2,:) = x';

for i=2:order-1
    Her_matrix(i+1,:) = 2*x'.*Her_matrix(i,:)-Her_matrix(i-1,:);
end


X = Her_matrix';

theta = inv((X'*X))*X'*y;

fitted = X*theta;
% plot(xx,y,xx,fitted);

theta=theta';
disp('estimated theta:');
disp(theta);
fitted = fitted';
        


