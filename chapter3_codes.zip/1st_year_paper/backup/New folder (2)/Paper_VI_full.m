function [VF,PF]=Paper_VI_full(epsilon,tolerance,y,inf,Prob)

global alpha y_star s_eps beta_l beta_h delta;




%% initialisation
[meshgrid_inf,meshgrid_y] = meshgrid(inf,y);

y_ND = beta_h/(alpha^2+beta_h)*epsilon;
inf_ND = alpha/beta_h*y_star - alpha/(alpha^2+beta_h)*epsilon;

inf_e_D = alpha/beta_h*y_star;

%XX=[beta]
allocation_inf=@(beta)(alpha  * y_star + alpha^2     *inf_e_D - alpha   *epsilon)/(alpha^2+beta);
allocation_y=@(beta)(alpha^2* y_star - alpha*beta*inf_e_D + beta  *epsilon)/(alpha^2+beta);

beta_grid = sort([beta_l beta_h  beta_l/8:1/70:beta_h*3]);

inflation = zeros(size(beta_grid,2),size(epsilon,2));
output    = zeros(size(beta_grid,2),size(epsilon,2));
P         = zeros(size(beta_grid,2),size(epsilon,2));
L_NP      = zeros(size(beta_grid,2),size(epsilon,2));

for i=1:size(beta_grid,2)
    inflation(i,:) = allocation_y(beta_grid(i));
    output(i,:)    = allocation_inf(beta_grid(i));
    
    P(i,:)         = interp2(meshgrid_inf,meshgrid_y,Prob,inflation(i,:),output(i,:),'linear');
    L_NP(i,:)        = 0.5*(output(i,:)-y_star).^2 + 0.5* beta_l * inflation(i,:).^2;
end



%%

%expected value while being punished E[V^p(eps)]
EV_P = ones(size(eps))/(1-delta)*(0.5*beta_l/(alpha^2+beta_l)*s_eps^2+0.5*(alpha^2+beta_l)/beta_l*y_star^2);


V_NP_new = zeros(size(epsilon));




%Gauss-Hermite quadrature (just to remember for the iteration)
[nodes, weights] = GaussHermite(15);
EV_NP =  1/pi*weights'* interp1(epsilon,V_NP_new,(sqrt(2)*s_eps.*nodes),'linear','extrap');


%% Iteration
disp('Value function iteration')
cont = 1;
count=0;
diff = 100;
while cont

    if diff<tolerance
        cont=0;
    else
        count=count+1;
        V_NP = V_NP_new;
        EV_NP =  1/pi*weights'* interp1(epsilon,V_NP,(sqrt(2)*s_eps.*nodes),'linear','extrap');
        
        [V_NP_new PF] = min( L_NP +  delta*(P *EV_P+(1-P) *EV_NP));
                
        diff = max(abs(V_NP_new-V_NP)./V_NP);
 
    end
end
disp(strcat(num2str(count),' iterations needed to converge, done.'));



for i=1:size(epsilon,2)
    PF2(i)=beta_grid(PF(i));
end

PF=PF2;

figure(100)
plot(epsilon,PF2);
ylabel('\beta');xlabel('\epsilon'); hline(beta_l);hline(beta_h);vline(0);

figure(101)
for i=1:size(epsilon,2)
    vector=zeros(size(epsilon)); vector(i)=1; vector=vector';
    plot(allocation_y(PF(i))*vector,allocation_inf(PF(i))*vector,'.'); hold on;
end
ylabel('\pi');xlabel('y')
hold off;
    
    





VF = V_NP_new;