
clear all;clc;

set(0,'DefaultFigureWindowStyle','docked');
target='C:\Users\Filip Rozsypal\Documents\Cambridge\1st_year_paper_proposal\';

tic;
%% Parameters
global alpha y_star s_inf s_y s_eps beta_l beta_h kappa_pos kappa_neg;

%CB preference
beta_l = 7.5/1.5/10;
beta_h = beta_l*15;

%PC parameter
alpha  = 1;
y_star = 5;
%variances
s_eps = 2;
s_inf = 1;
s_y   = 1;

delta=0.99;

kappa_pos = 0.99; %revison constant    
kappa_neg = 2-kappa_pos;

%% bounds on region
y_min   =  -3;
y_max   =   5;

inf_min =  -3;
inf_max =   6;

%% grid 
y   = -6:0.2:7;
inf = -3:0.2:10;

%% simulation of shocks
N_sim = 50;
Xi = [s_y^2 0;0 s_inf^2] * randn(2,N_sim);

%% Probability of deviation
disp('computing "Probability of punishment" matrix')

norevision = zeros(size(y,2),size(inf,2),N_sim);

loglik=@(Shocks) -(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2))/2 ...
                    - Shocks(1)^2/(2*s_eps^2)-Shocks(2)^2/(2*s_y^2)-Shocks(3)^2/(2*s_inf^2);

xi_y_hat   = zeros(2,N_sim);               
xi_inf_hat = zeros(2,N_sim);
eps_hat    = zeros(2,N_sim);
y_hat      = zeros(2,N_sim);
inf_hat    = zeros(2,N_sim);

%figure(1)
for i=1:size(y,2)
    for j=1:size(inf,2)
        %fprintf('epsilon=%2.2f \n',eps(i));

        X_tilde =[y(i);inf(j)]*ones(1,N_sim)+Xi;


        for ii=1:N_sim
            %low beta - Deviation
            [y_hat(1,ii),inf_hat(1,ii),xi_y_hat(1,ii),xi_inf_hat(1,ii),eps_hat(1,ii)] = ...
                CSG(X_tilde(1,ii),X_tilde(2,ii),beta_h,beta_l);
            %plot(y_hat(1,ii),inf_hat(1,ii),'.','color','black');hold on;
            
            %high beta - NoDeviation
            [y_hat(2,ii),inf_hat(2,ii),xi_y_hat(2,ii),xi_inf_hat(2,ii),eps_hat(2,ii)] = ...
                CSG(X_tilde(1,ii),X_tilde(2,ii),beta_h,beta_h);
            %plot(y_hat(2,ii),inf_hat(2,ii),'.','color','black');hold on;

            if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > 0
                disp('ll>0')
                if loglik([eps_hat(1,ii) xi_y_hat(1,ii) xi_inf_hat(1,ii)]) > ...
                        kappa_pos*loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)])
                    norevision(i,j,ii) = 1;
                end
            else
                if loglik([eps_hat(2,ii) xi_y_hat(2,ii) xi_inf_hat(2,ii)]) > ...
                        kappa_neg*loglik([eps_hat(1,ii) xi_y_hat(1,ii) xi_inf_hat(1,ii)])
                    norevision(i,j,ii) = 1;
                    %plot(X_tilde(1,ii),X_tilde(2,ii),'.','color','r');hold on;
                else
                    %plot(X_tilde(1,ii),X_tilde(2,ii),'.','color','b');hold on;
                end

            end
        end
        %plot(y(i),inf(j),'.','color','yellow','MarkerSize',30);hold on;


    end
end
%axis([-6 8 -5 8]);
%hold off;


%%
[inflation,outputgap] = meshgrid(inf,y);
           
Prob = 1-sum(norevision,3)/size(norevision,3);
figure(12)
surf(outputgap,inflation,Prob);
xlabel('y'); ylabel('\pi'); zlabel('Prabability of revision');
figuresize(15,10,'centimeters')
% print(gcf, '-dpdf', '-r300', 'C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\P_punishment.pdf')
%% grid for epsilon
epsilon = -7:0.5:7;

y_ND = beta_h/(alpha^2+beta_h)*epsilon;
inf_ND = alpha/beta_h*y_star - alpha/(alpha^2+beta_h)*epsilon;

inf_e_D = alpha/beta_h*y_star;
inf_D     = (alpha  * y_star + alpha^2     *inf_e_D - alpha   *epsilon)/(alpha^2+beta_l);
y_D       = (alpha^2* y_star - alpha*beta_l*inf_e_D + beta_l  *epsilon)/(alpha^2+beta_l);


P_D = interp2(inflation,outputgap,Prob,inf_D,y_D,'linear',0);
P_ND = interp2(inflation,outputgap,Prob,inf_ND,y_ND,'linear',0);

figure(13)
plot(epsilon,P_D,epsilon,P_ND)
xlabel('\epsilon'); ylabel('Prabability of revision'); legend('D','ND')

figure(14)
plot(y_D,inf_D,y_ND,inf_ND);legend('D','ND');
%%

%expected value while being punished E[V^p(eps)]
EV_P = ones(size(eps))/(1-delta)*0.5*beta_l/(alpha^2+beta_l)*s_eps^2+0.5*(alpha^2+beta_l)/beta_l*y_star^2;

%current loss of NotDeviating while not being punished
L_NP_ND = 0.5*(y_ND-y_star).^2 + 0.5* beta_l * inf_ND.^2;

%current loss of Deviating while not being punished
L_NP_D  = 0.5*(y_D -y_star).^2 + 0.5* beta_l * inf_D .^2;



%expected value of NotDeviating while being punished E[V^p(eps)]
%expected value of Deviating while being punished E[V^p(eps)]





figure(15)
plot(epsilon,L_NP_D,epsilon,L_NP_ND);
xlabel('\epsilon'); ylabel('Loss'); legend('D','ND')

V_NP_D  =zeros(size(epsilon));
V_NP_ND =zeros(size(epsilon));


V_NP = max(V_NP_D,V_NP_ND);


%Gauss-Hermite quadrature
[nodes, weights] = GaussHermite(5);
EV_NP =  1/pi*weights'* interp1(epsilon,V_NP,[sqrt(2)*s_eps.*nodes],'linear','extrap');


%%
disp('Value function iteration')
cont = 1;
count=0;
tolerance = 0.01;
diff = 100;
while cont

    if diff<tolerance
        cont=0;
    else
        count=count+1;
        V_NP = max(V_NP_D,V_NP_ND);
        EV_NP =  1/pi*weights'* interp1(epsilon,V_NP,[sqrt(2)*s_eps.*nodes],'linear','extrap');
        
        V_NP_D  = L_NP_D  +delta*(P_D *EV_P+(1-P_D) *EV_NP);
        V_NP_ND = L_NP_ND +delta*(P_ND*EV_P+(1-P_ND)*EV_NP);
        
        V_NP_new = max(V_NP_D,V_NP_ND);
        
        diff = max(abs(V_NP_new-V_NP));
        
        
    end
end
deviation=(V_NP_D>V_NP_ND);
disp(count);

figure(16)
plot(epsilon,V_NP_D,epsilon,V_NP_ND)
xlabel('\epsilon'); ylabel('V(\epsilon)'); legend('D','ND')

toc;



