function integral = simpson_int_norm(X,Y,mu,sigma)

% x row vector, equidistant, must be odd
% Y row vector of Y=f(x)
%mu, sigma, for normal density


if mod(size(X,2),2)==0
    error('error: number of points must be odd!!!');
end


Z = NaN*zeros(floor(size(X,2)/2),2);
G = NaN*zeros(floor(size(X,2)/2),3);

for i=0:floor(size(X,2)/2)-1
    
    Z(i+1,1) = X(2*i+1);
    Z(i+1,2) = X(2*i+3);
    
    G(i+1,1) = Y(2*i+1)*normpdf(X(2*i+1),mu,sigma);
    G(i+1,2) = Y(2*i+2)*normpdf(X(2*i+2),mu,sigma);
    G(i+1,3) = Y(2*i+3)*normpdf(X(2*i+3),mu,sigma);
    
end

integral = [-1 1]*Z' * G*[1;4;1]/6;
    
