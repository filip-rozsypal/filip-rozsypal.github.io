for rep=1:3
    
clear all;

options = optimset('algorithm','active-set','Display','off');

%% Parameters
%CB preference
beta=7.5/1.5;

%PC parameter
alpha  = 1;
y_star = 5;
%variances
s_eps = 1;
s_inf  = 0.5;
s_y   = 0.5;
%discount factor
delta=0.9;



%inf_e inflation expectations
inf_e = alpha/beta*y_star;
inf_e_max=10*inf_e;

% no-revision region
kappa_pos = 0.95; %revison constant    
kappa_neg = 2-kappa_pos;

%% bounds on region
y_min   =  2;
y_max   =   3;

inf_min =   -1;
inf_max =  2;

N_inf = 15;
N_y   = 15;

beta_min=0.01;



%% Simulation
N   = 10000; % number of simulations for noise shocks
N_e = 100; % number of epsilon shocks





%% numerical solution
Loss = NaN*zeros(5,N);
inf_next= NaN*zeros(5,N);
for index=1:5
    eps = -3+index;
    fprintf('simulation for epsilon = %2.2f \n',eps)
    
    for sim=1:N
        xi_inf = s_inf^2*randn;
        xi_y   = s_y^2*randn;
        
        inf = alpha/(alpha^2+beta)*(y_star+alpha*inf_e-eps)+xi_inf; 
        y   = alpha/(alpha^2+beta)*(alpha*y_star-beta*inf_e+beta/alpha*eps)+xi_y;
        
        %% constrained
        loglikelihood=@(X) -1*(-1/2*(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2)) ...
           - (X(1)-alpha*(X(2)-inf_e))^2/(2*s_eps^2)-(X(1)-y)^2/(2*s_y^2)-(X(2)-inf)^2/(2*s_inf^2));
        [~,ll_c_num] = fmincon(loglikelihood,[0;inf_e],[],[],[1 beta/alpha ],y_star,[],[],[],options);
        ll_c_num = -ll_c_num; %changing back from maximum


        %% unconstrained
        loglikelihood=@(X)-1*( -log(2*pi*s_eps^2)/2 -log(2*pi*s_inf^2)/2 -log(2*pi*s_y^2)/2 ...
                                 -(X(1)-alpha*(X(2)-inf_e))^2/(2*s_eps^2)...
                                 -(X(1)-y)^2/(2*s_y^2)...
                                 -(X(2)-inf)^2/(2*s_inf^2)...
                                );    


        c   = @(x)x(2)*(x(1)-y_star);        ceq =[];        pos_const = @(x)deal(c(x),ceq);
        [target,ll_unc_num] = fmincon(loglikelihood,[0;inf_e],[],[],[],[],[],[],pos_const,options);

        ll_unc_num = -ll_unc_num; %changing back from maximum
        
        %% revision test
        revise = 0;
        if ll_unc_num >0 && ll_c_num>kappa_pos*ll_unc_num
            revise = 1;
        end
        if ll_unc_num <0 && ll_c_num>kappa_neg*ll_unc_num
            revise = 1;
        end
                
        %% inflation expectations
        if revise == 0
            inf_next(index,sim) = inf_e;
        else
            inf_next(index,sim) = y_star*target(2)/(y_star-target(1));
        end
        
        %loss function
        Loss(index,sim) = 0.5*(...
                    (y-y_star)^2+beta*inf^2 +...
                    delta*beta/(alpha^2+beta)*(y_star^2+alpha^2*inf_next(index,sim)^2+s_eps^2+2*alpha*y_star*inf_next(index,sim)));
    

        if mod(sim,100)==0
            fprintf('*');
        end
        
        if mod(sim,100*50)==0
            fprintf('* %u done \n',sim)
        end
    end
    
   
end

mean(Loss,2)

end