% setup
%int_method = 'gauss_quadrature';     
int_method = 'Simpson';%choose method to compute expected value
constraint = 'yes';  %constrint setup
cutoff = norminv(0.975,0,s_eps);
ind_first = find(epsilon>-cutoff,1, 'first');
ind_last  = find(epsilon>cutoff,1, 'first');

%% 0-1 setup
% 0-0 deviation only, normal value function iteration
method='01';
[VF,PF_01,reaction_y_01,reaction_inf_01] = ...
    Paper_VI_full_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,[],[]);

%continuous deviation, normal value function iteration
method='no_con';
[VF,PF_no_con,reaction_y_no_con,reaction_inf_no_con] = ...
    Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,[],[],constraint,int_method);




figure(1)
plot(epsilon,[PF_no_con;PF_01],'linewidth',2)
axis([-14 14 -3 3])
vline(0,'k');hline(0,'k');vline([-cutoff,cutoff]);
xlabel('\epsilon');ylabel('Policy function');
legend('continuous deviation','0-1 deviation only');legend('boxoff');

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\PF_01','.pdf');
print(gcf, '-dpdf', '-r100', target);



sc_y   = [reaction_y_01(ind_first);reaction_y_01(ind_last);reaction_y_no_con(ind_first);reaction_y_no_con(ind_last)];
sc_inf = [reaction_inf_01(ind_first);reaction_inf_01(ind_last);reaction_inf_no_con(ind_first);reaction_inf_no_con(ind_last)];

figure(2)
get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
plot(reaction_y_01,reaction_inf_01,reaction_y_no_con,reaction_inf_no_con,'linewidth',2);
scatter(sc_y,sc_inf,50,[1;1;2;2],'filled'); hold off;
axis([-12 11 -3 7])
vline(0,'k');hline(0,'k');
xlabel('y');ylabel('\pi');
legend('No rejection area','0-1 deviation only','continuous deviation');legend('boxoff');

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\allocation_01','.pdf');
print(gcf, '-dpdf', '-r100', target);








%% 

%continuous deviation, approximating the policy function by chebyshev
%polynomials and iterating on E[V]    
order = 14;
[theta_init,PF_no_con_fitted] = cheb_estimation(order,PF_no_con,epsilon); %find the starting values  from normal value function iteration


method='con_CHpol';
[VF,PF_conCH,reaction_y_CHpol,reaction_inf_CHpol] = ...
    Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,[],constraint,int_method);


%continuous deviation, approximating the policy function by linear
%approxiamtion and iterating on E[V]       
method='con_LinInt';
grid_eps = min(epsilon):0.5:max(epsilon);
theta_init = interp1(epsilon,PF_no_con,grid_eps); %find starting conditions from normal value function iteration
[VF,PF_conLI,reaction_y_LinInt,reaction_inf_LinInt] = ...
    Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,grid_eps,constraint,int_method);



figure(3)
plot(epsilon,[PF_no_con;PF_conCH;PF_conLI],'linewidth',2)
axis([-14 10 -0.5 3])
vline(0,'k');hline(0,'k');vline([-cutoff,cutoff]);
xlabel('\epsilon');ylabel('Policy function');
legend('standard VFI, no constraint', '12th order Chebyshev pol, with constraint','lin approx, with constraint');legend('boxoff');
title('(Gauss-Hermite quadrature))')

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\PF_constraint_gauss','.pdf');
print(gcf, '-dpdf', '-r100', target);



sc_y   = [reaction_y_no_con(ind_first);reaction_y_no_con(ind_last);
          reaction_y_CHpol(ind_first);reaction_y_CHpol(ind_last);
          reaction_y_LinInt(ind_first);reaction_y_LinInt(ind_last)];

sc_inf   = [reaction_inf_no_con(ind_first);reaction_inf_no_con(ind_last);
          reaction_inf_CHpol(ind_first);reaction_inf_CHpol(ind_last);
          reaction_inf_LinInt(ind_first);reaction_inf_LinInt(ind_last)];

      
yy = [reaction_y_no_con;
      reaction_y_CHpol;
      reaction_y_LinInt]';

  
infinf = [reaction_inf_no_con;
          reaction_inf_CHpol;
          reaction_inf_LinInt]';  
  
      
      
      
figure(4)
get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
plot(yy,infinf,'linewidth',2);
scatter(sc_y,sc_inf,50,[1;1;2;2;3;3],'filled'); hold off;
axis([-12 7 -1 5])
vline(0,'k');hline(0,'k');
xlabel('y');ylabel('\pi');
legend('No rejection area','standard VFI, no constraint', ...
    '12th order Chebyshev pol, with constraint','lin approx, with constraint');legend('boxoff');
title('(Gauss-Hermite quadrature))')

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\allocation_constraint_gauss','.pdf');
print(gcf, '-dpdf', '-r100', target);



%%
int_method = 'Simpson';


%continuous deviation, approximating the policy function by chebyshev
%polynomials and iterating on E[V]    
order = 12;
[theta_init,PF_no_con_fitted] = cheb_estimation(order,PF_no_con,epsilon); %find the starting values  from normal value function iteration


method='con_CHpol';
[VF,PF_conCH,reaction_y_CHpol,reaction_inf_CHpol] = ...
    Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,[],constraint,int_method);


%continuous deviation, approximating the policy function by linear
%approxiamtion and iterating on E[V]       
method='con_LinInt';
grid_eps = min(epsilon):0.5:max(epsilon);
theta_init = interp1(epsilon,PF_no_con,grid_eps); %find starting conditions from normal value function iteration
[VF,PF_conLI,reaction_y_LinInt,reaction_inf_LinInt] = ...
    Paper_VI_full_d_1p_only(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid,method,theta_init,grid_eps,constraint,int_method);



figure(5)
plot(epsilon,[PF_no_con;PF_conCH;PF_conLI],'linewidth',2)
axis([-14 10 -0.5 3])
vline(0,'k');hline(0,'k');vline([-cutoff,cutoff]);
xlabel('\epsilon');ylabel('Policy function');
legend('standard VFI, no constraint', '12th order Chebyshev pol, with constraint','lin approx, with constraint');legend('boxoff');
title('(Simpson quadrature))')

figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\PF_constraint_simpson','.pdf');
print(gcf, '-dpdf', '-r100', target);



sc_y   = [reaction_y_no_con(ind_first);reaction_y_no_con(ind_last);
          reaction_y_CHpol(ind_first);reaction_y_CHpol(ind_last);
          reaction_y_LinInt(ind_first);reaction_y_LinInt(ind_last)];

sc_inf   = [reaction_inf_no_con(ind_first);reaction_inf_no_con(ind_last);
          reaction_inf_CHpol(ind_first);reaction_inf_CHpol(ind_last);
          reaction_inf_LinInt(ind_first);reaction_inf_LinInt(ind_last)];

      
yy = [reaction_y_no_con;
      reaction_y_CHpol;
      reaction_y_LinInt]';

  
infinf = [reaction_inf_no_con;
          reaction_inf_CHpol;
          reaction_inf_LinInt]';  
  
      
      
      
figure(6)
get_noR_area(Rregion_matrix,Prob_y,Prob_inf);hold on;
plot(yy,infinf,'linewidth',2);
scatter(sc_y,sc_inf,50,[1;1;2;2;3;3],'filled'); hold off;
axis([-12 7 -1 5])
vline(0,'k');hline(0,'k');
xlabel('y');ylabel('\pi');
legend('No rejection area','standard VFI, no constraint', ...
    '12th order Chebyshev pol, with constraint','lin approx, with constraint');legend('boxoff');
title('(Simpson quadrature))')



figuresize(14,10,'centimeters')
%target=strcat('C:\Users\Filip Rozsypal\Documents\Cambridge\paper_update\fig\no_revision_2_',num2str(model),'.pdf');
target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\allocation_constraint_simpson','.pdf');
print(gcf, '-dpdf', '-r100', target);






