function combine_dev_fig(model_set,parameter_values,model_description,epsilon,tolerance,d_grid)

global alpha y_star s_eps beta_l beta_h delta;

PF = NaN*zeros(size(model_set,2),size(epsilon,2));

%% get data
for i=1:size(model_set,2)
    model=model_set(i);
       
    % Obtain probability of rejection
    disp('Obtain probability of rejection...')
    %cd('C:\Users\Filip Rozsypal\Documents\MATLAB\macro\1st_year_paper\Pmat');
    cd('C:\Documents and Settings\fr282\My Documents\MATLAB\macro\1st_year_paper\Pmat');
    target = strcat('Pun_matrix_',num2str(model_set(i)),'.mat');
    load(target); disp('loaded...')
    
    % set parameter values
    
    s_eps = parameter_values(model,1);
    delta = parameter_values(model,2);
    kappa_pos = parameter_values(model,3);    
    kappa_neg = 2-kappa_pos;
    beta_l = parameter_values(model,4);
    beta_h = parameter_values(model,5);
    alpha  = parameter_values(model,6);
    
    
    % Value function iteration
    disp('Value function iteration...');
    [VF(i,:),PF(i,:),~,~]=Paper_VI_full_d(epsilon,tolerance,Prob_y,Prob_inf,Prob,d_grid);    
    
    
end

%% generate figures
% deviations
figure(400)
plot(epsilon,PF,'LineWidth',2);    
ylabel('deviation');xlabel('\epsilon');hline(0);vline(0);
legend(model_description([model_set],:));
axis([-10 15 -7 7])
% value function
figure(401)
plot(epsilon,VF,'LineWidth',2);    
ylabel('value');xlabel('\epsilon');hline(0);vline(0);
legend(model_description([model_set],:));

