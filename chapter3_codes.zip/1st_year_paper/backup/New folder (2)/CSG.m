function [y_hat,inf_hat,xi_y_hat,xi_inf_hat,eps_hat] = CSG(y,inf,beta_old,beta_new)
global alpha y_star s_inf s_y s_eps;
%Constrained Signal Extraction
if beta_old==beta_new  %correct beliefs (=not deviated) 
    beta=beta_old;
    const = -s_y^2*s_inf^2*s_eps^2*(alpha^2+beta)/ ...
        (s_inf^2*s_y^2*(alpha^2+beta)^2+s_y^2*s_eps^2*alpha^2+s_inf^2*s_eps^2*beta^2);
    eps_hat = const * ( -alpha^2/(beta*s_inf^2)*y_star + alpha/s_inf^2*inf - beta/s_y^2*y);

    xi_inf_hat = inf - alpha/beta*y_star + alpha/(alpha^2+beta)*eps_hat;
    xi_y_hat   = y - beta/(alpha^2+beta)*eps_hat;

    inf_hat = alpha/beta*y_star - alpha/(alpha^2+beta)*eps_hat;
    y_hat   = beta/(alpha^2+beta)*eps_hat;
else %incorrect beliefs (=deviated)     
    inf_e = alpha/beta_old*y_star;
    const = (alpha^2+beta_new)/ ...
        ( (alpha^2+beta_new)^2*s_inf^2*s_y^2+alpha^2*s_y^2*s_eps^2+beta_new^2*s_inf^2*s_eps^2);
        
    eps_hat = const * ( ...
        -alpha*s_eps^2*s_y^2*(inf-alpha/(alpha^2+beta_new)*y_star-alpha^2/(alpha^2+beta_new)*inf_e) ...
        +beta_new*s_inf^2*s_eps^2*(y-alpha^2/(alpha^2+beta_new)*y_star-alpha*beta_new/(alpha^2+beta_new)*inf_e) ...
        );
    
    inf_hat = (alpha  * y_star + alpha^2       *inf_e - alpha   *eps_hat)/(alpha^2+beta_new);
    y_hat   = (alpha^2* y_star - alpha*beta_new*inf_e + beta_new*eps_hat)/(alpha^2+beta_new);
    

    xi_inf_hat = inf - inf_hat;
    xi_y_hat   = y - y_hat;
end

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                