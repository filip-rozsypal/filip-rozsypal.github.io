%% This program solves the nonlinear equation for optimal degree of
%% conservativeness 
clear all;
clc;

set(0,'DefaultFigureWindowStyle','docked');


y_star = 5;
alpha  = 0.9;

interval = 3:0.1:45;

beta_vector = [0.5 1 2 5];
s_e_vector = [0.8 1 2 3];

for j=1:4
    beta_low = beta_vector(j);
    for i=1:4
        s_e = s_e_vector(i);
        
        dEL_beta_high = @(beta_high)(s_e^2./(alpha^2+beta_high).^2 + y_star^2./beta_high.^2).*beta_high ...
        - (beta_high.^2+alpha^2*beta_low).*(s_e^2./(alpha^2+beta_high).^3 + y_star^2./beta_high.^3 );
    
        value(:,j,i)=dEL_beta_high(interval);
        zero_point(j,i) = fzero(dEL_beta_high,50);
    end
end



figure(1)
plot(interval, squeeze(value(:,2,:)),'LineWidth',2)
axis([min(interval) max(interval) -0.01 0.025]);
hline(0,'-k'),vline(zero_point(2,:))
legend('\sigma=0.8','\sigma=1','\sigma=2','\sigma=3');legend('boxoff');
title('Changes in \sigma (for \beta_{low}=1)')
xlabel('$\beta_{high}$','interpreter','latex','FontSize',12);
ylabel('$\frac{\partial E[L]}{\partial \beta_{high}}$','interpreter','latex','FontSize',13)

target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\sigma_exp.pdf');
figuresize(10,10,'centimeters')
print(gcf, '-dpdf', '-r100', target);       



figure(2)
plot(interval, squeeze(value(:,:,3)),'LineWidth',2)
axis([min(interval) max(interval) -0.01 0.025]);
hline(0,'-k'),vline(zero_point(:,3))
legend('\beta_{low}=0.5','\beta_{low}=1','\beta_{low}=2','\beta_{low}=5');legend('boxoff');
title('Changes in \beta_low (for \sigma=2)')
xlabel('$\beta_{high}$','interpreter','latex','FontSize',12);
ylabel('$\frac{\partial E[L]}{\partial \beta_{high}}$','interpreter','latex','FontSize',13)

target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\beta_low_exp.pdf');
figuresize(10,10,'centimeters')
print(gcf, '-dpdf', '-r100', target);   




beta_vector = 0.5:0.1:4;


for i=1:4
    s_e = s_e_vector(i);    
    
    guess = 20;
    
    for j=1:size(beta_vector,2)
        beta_low = beta_vector(j);
    
        dEL_beta_high = @(beta_high)(s_e^2./(alpha^2+beta_high).^2 + y_star^2./beta_high.^2).*beta_high ...
        - (beta_high.^2+alpha^2*beta_low).*(s_e^2./(alpha^2+beta_high).^3 + y_star^2./beta_high.^3 );
    
        zero_point_2(j,i) = fzero(dEL_beta_high,guess);
        guess =zero_point_2(j,i);
    end
end

figure(3)
plot(beta_vector,zero_point_2,'LineWidth',2)
axis([min(beta_vector) max(beta_vector) 0 80]);grid on;
legend('\sigma=0.8','\sigma=1','\sigma=2','\sigma=3');legend('location','NorthWest');legend('boxoff'); 
xlabel('$\beta_{low}$','interpreter','latex','FontSize',12);
ylabel('$\beta_{high}$','interpreter','latex','FontSize',12)
title('Solutions for optimal $\beta_{high}$ given $\beta_{low}$','interpreter','latex')

target=strcat('C:\Documents and Settings\fr282\My Documents\Cambridge\paper_update\fig\beta_low_high.pdf');
figuresize(10,10,'centimeters')
print(gcf, '-dpdf', '-r100', target);  



%