function ll=loglik3(beta,X)

s_eps = X(1);
s_inf = X(2);
s_y   = X(3);
inf   = X(4);
y     = X(5);
alpha = X(6);
beta1  = X(7);
y_star= X(8);


inf_hat = beta(1);
y_hat   = beta(2);



inf_e   = alpha/beta1*y_star;


eps_hat =  y_hat-alpha*(inf_hat-inf_e);


ll=-1/2*(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2)) ... 
    - eps_hat^2/(2*s_eps)-(y_hat-y)^2/(2*s_y)-(inf_hat-inf)^2/(2*s_inf);

