clc; clear all;

global counter; 

tolerance = 0.5;

col= -0.2:0.05:0.2;

Data_matrix = [col' col' col' col' col' col' col' ];

counter = 0;

history = [];
plausible_policy = [];

n_steps = size(Data_matrix,1)^size(Data_matrix,2);

fprintf('number of possible combinations: \t\t%8.i\n',n_steps);
plausible_policy = search_vector(history,Data_matrix,tolerance,plausible_policy,n_steps);


%function plausible_policy=search_vector(history,Data_matrix,weights,tolerance,plausible_policy)




