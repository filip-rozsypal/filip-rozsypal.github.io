
clear all;clc;


target='C:\Users\Filip Rozsypal\Documents\Cambridge\1st_year_paper_proposal\';
%% Parameters
global alpha y_star s_inf s_y s_eps beta_0 inf_e;

%CB preference
beta_0=7.5/1.5;

%PC parameter
alpha  = 1;
y_star = 5;
%variances
s_eps = 4;
s_inf  = 1;
s_y   = 1;


kappa_pos = 0.999; %revison constant    
kappa_neg = 2-kappa_pos;

%% bounds on region
y_min   =  -3;
y_max   =   5;

inf_min =   -3;
inf_max =  6;

N_inf = 50;
N_y   = 50;

arrows1 = [];
arrows0 = [];
norevison = zeros(N_inf,N_y);

loglik=@(Shocks) -1/2*(log(2*pi*s_eps^2)+log(2*pi*s_inf^2)+log(2*pi*s_y^2)) ...
                    - Shocks(1)^2/(2*s_eps^2)-Shocks(2)^2/(2*s_y^2)-Shocks(3)^2/(2*s_inf^2);

for i=1:N_inf
    for j=1:N_y
        inf = inf_min + (inf_max-inf_min)/(N_inf-1)*(i-1);
        y = y_min + (y_max-y_min)/(N_y-1)*(j-1);

        beta=beta_0;
        inf_e = alpha/beta*y_star;
        [y_hat0,inf_hat0,xi_y_hat0,xi_inf_hat0,eps_hat0] = CSG(inf,y,beta);
        arrows0 = [arrows0;y inf y_hat0 inf_hat0];

        beta=10*beta_0;
        inf_e = alpha/beta*y_star;
        [y_hat1,inf_hat1,xi_y_hat1,xi_inf_hat1,eps_hat1] = CSG(inf,y,beta);
        arrows1 = [arrows1;y inf y_hat1 inf_hat1];

        ll_matrix(i,j) = loglik([eps_hat0 xi_y_hat0 xi_inf_hat0])/loglik([eps_hat1 xi_y_hat1 xi_inf_hat1]);

        if loglik([eps_hat1 xi_y_hat1 xi_inf_hat1]) >0
            disp('ll>0')
            if loglik([eps_hat0 xi_y_hat0 xi_inf_hat0])>kappa_pos*loglik([eps_hat1 xi_y_hat1 xi_inf_hat1])
                norevison(j,i) = 1;
            end
        else
            if loglik([eps_hat1 xi_y_hat1 xi_inf_hat1])>kappa_neg*loglik([eps_hat0 xi_y_hat0 xi_inf_hat0])
                norevison(j,i) = 1;
            end
        end
        

        
        
        
    end
end

[inflation,outputgap] = meshgrid(inf_min:(inf_max-inf_min)/(N_inf-1):inf_max, y_min:(y_max-y_min)/(N_y-1):y_max);         
figure(2)
surf(outputgap,inflation,ll_matrix);
xlabel('y');ylabel('\pi');zlabel('relative log-likelihood');

figure(3)
surf(outputgap,inflation,norevison);
xlabel('y');ylabel('\pi');zlabel('no revision');


% %% export of arrows
% target0=strcat(target,'arrows0.dat');
% fid = fopen(target0,'w');
% for i= 1:size(arrows1,1)
%     fprintf(fid,'\\draw[->,thin,green] (%2.2f,%2.2f) -- (%2.2f, %2.2f);',  arrows1(i,:));    
% end
% fclose(fid);
% 
% target1=strcat(target,'arrows1.dat');
% fid = fopen(target1,'w');
% for i= 1:size(arrows0,1)
%     fprintf(fid,'\\draw[->,thin,pink] (%2.2f,%2.2f) -- (%2.2f, %2.2f);',  arrows0(i,:));    
% end
% fclose(fid);

%% export of circles
target_circ=strcat(target,'circles.dat');
fid = fopen(target_circ,'w');
for i=1:N_inf
    for j=1:N_y
        inf = inf_min + (inf_max-inf_min)/(N_inf-1)*(i-1);
        y = y_min + (y_max-y_min)/(N_y-1)*(j-1);
        
        if norevison(j,i) == 1
            draw = [y,inf];
            fprintf(fid,' \\fill [pink] (%2.2f,%2.2f) circle (0.05cm);',  draw);   
        end
    end
end

fclose(fid);
















