% Basic solution



clear;
clc


Solution_type = 'direct'; %'direct', 
Grid_type = 'product'; % 'product', 


%% initialisation

Problem_type = 'simple'; 



N_quadrature = 7;



gamma   =0;
gammaD0 = 0; 
gammaD1 = 0;
gammaU0 = 0; 
gammaU1 = 0.



% economic parameters
alpha = 0.36;  % capital share of output
beta  = 0.975;  % discount factor
delta = 0.025; % depreciation rate
rho   = 0.9;  % productivity persistence
sig_a = 0.01; % volatilify of productivity shocks
sigma = 2;
kappa = 0.5;



PF_type = 'basic'

theta_a = [0 1];
theta_k = [0 1];    

        
PF_order  = [3 3];

%% starting guess

k_ss = 13;
[Xi,theta_a,theta_k] = load_starting_guess(PF_order,PF_type,Solution_type,Grid_type,Problem_type,theta_a,theta_k,1);


%% grids and quadrature nodes


%% quadrature nodes
[nodes, weights] = GaussHermite_2(N_quadrature);
nodes   = sqrt(2)*sig_a*nodes;
weights = pi^(-0.5)*weights;

a_grid_set_length = 40;


a_grid_set = round(linspace(2,48,a_grid_set_length));
k_grid_set = round(4/3*linspace(2,48,a_grid_set_length));

time_matrix = zeros(1,length(a_grid_set));
time_loop_2 = zeros(1,length(a_grid_set));
time_loop_1 = zeros(1,length(a_grid_set));

N_smoothing = 15;


for index_grid_size=1:length(a_grid_set)
    %% grids
    % define boundaries



    a_grid_lb = -0.1;
    a_grid_ub = 0.1;
    a_grid_N  = a_grid_set(index_grid_size);

    k_grid_lb = 10;
    k_grid_ub = 17;
    k_grid_N  = k_grid_set(index_grid_size);

    k_grid = linspace(k_grid_lb,k_grid_ub,k_grid_N);
    a_grid = linspace(a_grid_lb,a_grid_ub,a_grid_N); 
    k_grid_adj = k_grid;
    a_grid_adj = a_grid;
    
    
    total_grid_size(index_grid_size) = a_grid_N*k_grid_N;
    

    
    
  




    [kk_grid,aa_grid] = comb_vector(k_grid,a_grid);
    [k_grid_adj,a_grid_adj] = comb_vector(k_grid_adj,a_grid_adj);

    [nodes_grid,kkk_grid] = comb_vector(nodes',kk_grid);
    [~,aaa_grid] = comb_vector(nodes',aa_grid);
    [weights_grid,~] = comb_vector(weights',aa_grid);


    lkk  = length(kk_grid);
    lkkk = length(kkk_grid);
    ln   = length(nodes');

    summation_matrix = zeros(lkkk,lkk);
    for i=1:lkk
        summation_matrix(1+(i-1)*ln:i*ln,i) = weights_grid(1+(i-1)*ln:i*ln)';
    end

    %% define functions
    define_functions;

    %% loop solution
    time_loop_1_raw=zeros(1,N_smoothing);
    
    for smoothing_index = 1:N_smoothing
error_loop1 = zeros(length(a_grid),length(k_grid));
error_loop2 = zeros(length(a_grid),length(k_grid));         
        tic
        for index_a=1:length(a_grid)
            for index_k=1:length(k_grid)       
                for index_eps=1:length(nodes)
                    error_loop1(index_a,index_k) = error_loop1(index_a,index_k) + ...
                        weights(index_eps)*f_EE_error(a_grid(index_a),k_grid(index_k),nodes(index_eps),Xi);
                end  
            end
            %index_a
        end
        time_loop_1_raw(smoothing_index) = toc;
    end
    
    time_loop_1(index_grid_size) = mean(time_loop_1_raw);


    %% loop solution 2
    
    time_loop_2_raw=zeros(1,N_smoothing);
    
    for smoothing_index = 1:N_smoothing
error_loop1 = zeros(length(a_grid),length(k_grid));
error_loop2 = zeros(length(a_grid),length(k_grid));         
        tic
        for index_a=1:length(a_grid)
            parfor index_k=1:length(k_grid)       
                for index_eps=1:length(nodes)
                    error_loop2(index_a,index_k) = error_loop2(index_a,index_k) + ...
                        weights(index_eps)*f_EE_error(a_grid(index_a),k_grid(index_k),nodes(index_eps),Xi);
                end  
            end
            %index_a
        end
        time_loop_2_raw(smoothing_index) = toc;
    end
    
    time_loop_2(index_grid_size) = mean(time_loop_2_raw);
        
        
    %% matrix solution 
    time_matrix_raw=zeros(1,N_smoothing);
    for smoothing_index = 1:N_smoothing
        tic
        error_direct_row = f_EE_error_short(Xi);
        error_direct = reshape(error_direct_row,length(k_grid),length(a_grid))';

        time_matrix_raw(smoothing_index) = toc;
    end
    
    time_matrix(index_grid_size) = mean(time_matrix_raw);



    %%

%     plot(error_direct_row)
% 
%     mesh(error_direct')
% 
%     mesh(error_loop2)

index_grid_size
    
end

%% plot the results
figure(1)
plot(total_grid_size,[time_loop_1; time_loop_2 ;time_matrix]')
axis([min(total_grid_size) max(total_grid_size) 0 4.5])
legend('loop','paralel loop','direct','Location','northwest');legend('boxoff')
ylabel('time [sec]');xlabel('total grid size')





target_folder = '..\..\research\texts\thesis\Chapter2\figures\';
model_name    = strcat('loop_vs_matrix_times.tex');




target = strcat(target_folder,model_name);
matlab2tikz(target,'externalData',true,'noSize',true,...
    'relativeDataPath','G:\filip_dropbox\Dropbox\research\texts\thesis\Chapter2\figures', ...
    'extraAxisOptions','legend style={draw=none,at={(0,1)},anchor=north west},small,scale only axis')



figure(2)
plot(total_grid_size,[min([time_loop_1; time_loop_2])./time_matrix])
axis([min(total_grid_size) max(total_grid_size) 0 140])
legend('speed-up factor');legend('boxoff')
ylabel('speed-up factor');xlabel('total grid size')





target_folder = '..\..\research\texts\thesis\Chapter2\figures\';
model_name    = strcat('loop_vs_matrix_times_speed_up.tex');




target = strcat(target_folder,model_name);
matlab2tikz(target,'externalData',true,'noSize',true,...
    'relativeDataPath','G:\filip_dropbox\Dropbox\research\texts\thesis\Chapter2\figures', ...
    'extraAxisOptions','legend style={draw=none,at={(0,1)},anchor=north west},small,scale only axis')




