%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  This function generates saving policy function %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function [PF,PF1,f_X,f_X_long,coefficients] = load_policy_function(PF_type,PF_order,theta_a,theta_k)
    
    % total number of parameters
    n_coef = (PF_order(1)+1)*(PF_order(2)+1);

    %define hermite polynomials
    H{1}  = @(x) ones(1,length(x));
    H{2}  = @(x) x;
    H{3}  = @(x) x.^2  -1;
    H{4}  = @(x) x.^3  -3*x;
    H{5}  = @(x) x.^4  -6*x.^2  +3;
    H{6}  = @(x) x.^5  -10*x.^3 +15*x;
    H{7}  = @(x) x.^6  -15*x.^4 +45*x.^2  -15;
    H{8}  = @(x) x.^7  -21*x.^5 +105*x.^3 -105*x;
    H{9}  = @(x) x.^8  -28*x.^6 +210*x.^4 -420*x.^2  +105;
    H{10} = @(x) x.^9  -36*x.^7 +378*x.^5 -1260*x.^3 +945*x;
    H{11} = @(x) x.^10 -45*x.^8 +630*x.^6 -3150*x.^4 +4725*x.^2 -945;   
    
    
    HH1  = @(x) ones(1,length(x));
    HH2  = @(x) x;
    HH3  = @(x) x.^2  -1;
    HH4  = @(x) x.^3  -3*x;
    HH5  = @(x) x.^4  -6*x.^2  +3;
    HH6  = @(x) x.^5  -10*x.^3 +15*x;
    HH7  = @(x) x.^6  -15*x.^4 +45*x.^2  -15;
    HH8  = @(x) x.^7  -21*x.^5 +105*x.^3 -105*x;
    HH9  = @(x) x.^8  -28*x.^6 +210*x.^4 -420*x.^2  +105;
    HH10 = @(x) x.^9  -36*x.^7 +378*x.^5 -1260*x.^3 +945*x;
    HH11 = @(x) x.^10 -45*x.^8 +630*x.^6 -3150*x.^4 +4725*x.^2 -945; 
    
    
    

    % define the order of polynomias
    coefficients = generate_polynomial_coefficients(PF_order);
    
    % define the policy function
    switch PF_type
        case 'manual'
            
        case 'basic'

            PF = @(a,k,xi)  xi*( ...
                            repmat(k,n_coef,1)    .^ repmat(coefficients(:,1),1,length(k)) ...
                          .*repmat(a,n_coef,1)    .^ repmat(coefficients(:,2),1,length(k)) ...
                                );
            PF1 = @(a,k,xi)  xi*( k.^ coefficients(:,1).*a.^ coefficients(:,2));                            
                            
            f_X= @(a,k)  repmat(k,n_coef,1)    .^ repmat(coefficients(:,1),1,length(k)) ...
                          .*repmat(a,n_coef,1)    .^ repmat(coefficients(:,2),1,length(k));
            
            %no normalisation in this mode
            f_X_long = @(a,k,theta_a,theta_k)  f_X(a,k);


        case 'orthogonal'
 
            PF_function_string = 'PF = @(a,k,xi)  xi*([';
            for i=1:size(coefficients,1)
                i_str = num2str(i);
                PF_function_string = strcat( ...
                        PF_function_string,'H{coefficients(',i_str,',1)+1}(k).*H{coefficients(',i_str,',2)+1}(a);' ...
                        );
            end
            PF_function_string = strcat(PF_function_string,']);');
            
            eval(PF_function_string);
            PF1 = @(a,k,xi) PF(a,k,xi);
            
            f_X_function_string = 'f_X = @(a,k)  [';
            for i=1:size(coefficients,1)
                i_str = num2str(i);
                f_X_function_string = strcat( ...
                        f_X_function_string,'H{coefficients(',i_str,',1)+1}(k).*H{coefficients(',i_str,',2)+1}(a);' ...
                        );
            end
            f_X_function_string = strcat(f_X_function_string,'];');
            
            eval(f_X_function_string);    
            
            %no normalisation in this mode
            f_X_long = @(a,k,theta_a,theta_k)  f_X(a,k);
            
            



        case 'norm'

            
            %scaling funciton
            x_norm = @(x,theta_x) (x-theta_x(1))/theta_x(2);
            PF = @(a,k,xi)  xi*( ...
                            repmat(x_norm(k,theta_k),n_coef,1)    .^ repmat(coefficients(:,1),1,length(k)) ...
                          .*repmat(x_norm(a,theta_a),n_coef,1)    .^ repmat(coefficients(:,2),1,length(k)) ...
                                );
                            
            PF1 = @(a,k,xi)  xi*( ...
                            x_norm(k,theta_k)   .^ coefficients(:,1) ...
                          .*x_norm(a,theta_a)    .^coefficients(:,2) ...
                                );                            
                            
                            
                            
            f_X = @(a,k)  repmat(x_norm(k,theta_k),n_coef,1)    .^ repmat(coefficients(:,1),1,length(k)) ...
                          .*repmat(x_norm(a,theta_a),n_coef,1)    .^ repmat(coefficients(:,2),1,length(k));
                      
            f_X_long = @(a,k,theta_a,theta_k) ...
                            repmat(x_norm(k,theta_k),n_coef,1)    .^ repmat(coefficients(:,1),1,length(k)) ...
                            .*repmat(x_norm(a,theta_a),n_coef,1)    .^ repmat(coefficients(:,2),1,length(k));                       
            
    
        case 'orthnorm'
            x_norm = @(x,theta_x) (x-theta_x(1))/theta_x(2);  
            
            PF_function_string = 'PF = @(a,k,xi)  xi*([';
            for i=1:size(coefficients,1)
                i_str = num2str(i);
                PF_function_string = strcat( ...
                        PF_function_string,'H{coefficients(',i_str,',1)+1}(x_norm(k,theta_k))',...
                                         '.*H{coefficients(',i_str,',2)+1}(x_norm(a,theta_a));' ...
                        );
            end
            PF_function_string = strcat(PF_function_string,']);');
            
            eval(PF_function_string);
            PF1 = @(a,k,xi) PF(a,k,xi);
            
            
            f_X_function_string = 'f_X = @(a,k)  [';
            for i=1:size(coefficients,1)
                i_str = num2str(i);
                f_X_function_string = strcat( ...
                        f_X_function_string,'H{coefficients(',i_str,',1)+1}(x_norm(k,theta_k))',...
                                         '.*H{coefficients(',i_str,',2)+1}(x_norm(a,theta_a));' ...
                        );
            end
            f_X_function_string = strcat(f_X_function_string,'];');
            
            eval(f_X_function_string);
            
            
            f_X_function_string = 'f_X_long = @(a,k,theta_a,theta_k)  [';
            for i=1:size(coefficients,1)
                i_str = num2str(i);
                f_X_function_string = strcat( ...
                        f_X_function_string,'H{coefficients(',i_str,',1)+1}(x_norm(k,theta_k))',...
                                         '.*H{coefficients(',i_str,',2)+1}(x_norm(a,theta_a));' ...
                        );
            end
            f_X_function_string = strcat(f_X_function_string,'];');
            
            eval(f_X_function_string); 
            
            
            
            
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
%             
%             PF_function_string = 'PF1 = @(a,k,xi)  xi*([';
%             for i=1:size(coefficients,1)
%                 i_str = num2str(i);
%                 PF_function_string = strcat( ...
%                         PF_function_string,'HH',num2str(coefficients(i,1)+1),'(x_norm(k,theta_k))',...
%                                          '.*HH',num2str(coefficients(i,1)+1),'(x_norm(a,theta_a));' ...
%                         );
%             end
%             PF_function_string = strcat(PF_function_string,']);');
%             
%             eval(PF_function_string);

            
            
            
            
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            
            
            
            
            
            
            
   
    end

end

%%%%% additional functions %%%%%%%%%%%%%%

%this function generates matrix of polynomial coefficients for a policy
%function on order PF_order
function coefficients = generate_polynomial_coefficients(PF_order)

coefficients = [0,0];

for sum_coef=1:PF_order(1)+PF_order(2);
    for index_k=0:min(PF_order(1),sum_coef)
        if sum_coef-index_k<=PF_order(2)
            coefficients = [coefficients;[index_k,sum_coef-index_k]];
        end
    end
end
            
end