

function [Xi_init_out,theta_a,theta_k] =  ... 
    load_starting_guess(PF_order,PF_type,Solution_type,Grid_type,Problem_type,theta_a,theta_k,check)

    target_string = strcat('solution_',Solution_type,'_',Grid_type,'_',Problem_type,'.mat');
    load(target_string);

    switch PF_type
        case 'basic'
            solution_to_load=solution_1;
        case 'orthogonal'
            solution_to_load=solution_2;
        case 'norm'   
            solution_to_load=solution_3;
        case 'orthnorm'
            solution_to_load=solution_4;
    end

    %%

    if check
        model_to_load =  ... 
            find(   ...
                    (solution_to_load.a<=PF_order(2)) .*  ...
                    (solution_to_load.k<=PF_order(1)) .*  ...
                    (~isnan(solution_to_load.acc)) ...
                  ,1,'last');
    else
        model_to_load =  ... 
            find(   ...
                    (solution_to_load.a<=PF_order(2)) .*  ...
                    (solution_to_load.k<=PF_order(1)) ,1,'last');
    end

      %%    
    try      
        Xi_init = solution_to_load.final(model_to_load);

    
    


    fprintf('using results from model [%u,%u]\n',[solution_1.k(model_to_load) solution_1.a(model_to_load)])








    % save the results into appropriate matrix
    switch PF_type
            case 'basic'
                model_to_load =  ... 
                    find(   ...
                                (solution_1.a<=PF_order(2)) ...
                             .* (solution_1.k<=PF_order(1)) ... 
                             .*(~isnan(solution_1.acc)),1,'last');
                if isempty(model_to_load)
                    disp('no previous results found, using default')
                    Xi_init=[ 0   0.1  0.9 zeros(1,(PF_order(1)+1)*(PF_order(2)+1)-3)];                
                else
                    Xi_init = solution_1.final(model_to_load);
                end

            case 'orthogonal'
                model_to_load =  ... 
                    find(   ...
                                (solution_2.a<=PF_order(2)) ...
                             .* (solution_2.k<=PF_order(1)) ... 
                             .*(~isnan(solution_2.acc)),1,'last');
                if isempty(model_to_load)
                    disp('no previous results found, using default')
                    Xi_init=[ 0   0.1  0.9 zeros(1,(PF_order(1)+1)*(PF_order(2)+1)-3)];                
                else
                    Xi_init = solution_2.final(model_to_load);
                end               

            case 'norm'           
                model_to_load =  ... 
                    find(   ...
                                (solution_3.a<=PF_order(2)) ...
                             .* (solution_3.k<=PF_order(1)) ... 
                             .*(~isnan(solution_3.acc)),1,'last');
                if isempty(model_to_load)
                    disp('no previous results found, using default')
                    Xi_init=[ 13   0.1  0.9 zeros(1,(PF_order(1)+1)*(PF_order(2)+1)-3)];                
                else
                    Xi_init = solution_3.final(model_to_load);
                end 

            case 'orthnorm'
                model_to_load =  ... 
                    find(   ...
                                (solution_4.a<=PF_order(2)) ...
                             .* (solution_4.k<=PF_order(1)) ... 
                             .*(~isnan(solution_4.acc)),1,'last');
                if isempty(model_to_load)
                    disp('no previous results found, using default')
                    Xi_init=[ 12.8   0.05  0.75 zeros(1,(PF_order(1)+1)*(PF_order(2)+1)-3)];                
                else
                    Xi_init = solution_4.final(model_to_load);
                end               
    end

    if isempty(model_to_load)
        Xi_init_out=Xi_init;
    else
        
    
        Xi_init_out = cell2mat(Xi_init);



        % add zeros for bigger models
        found_model_k = solution_1.k(model_to_load);
        found_model_a = solution_1.a(model_to_load);

        if isequal([found_model_k found_model_a],PF_order)
            %this model was already solved, so Xi is of correct size
        else
            coef_old = generate_polynomial_coefficients([found_model_k found_model_a]);
            coef_new = generate_polynomial_coefficients(PF_order);

            coef_old = [coef_old; NaN*zeros(size(coef_new,1) - size(coef_old,1),2)];


            index_old = 1;
            for index_new = 1:size(coef_new,1)
                if isequal(coef_old(index_old,:),coef_new(index_new,:))
                    index_old = index_old+1;
                else
                    Xi_init_out=[Xi_init_out(1:index_new-1) 0 Xi_init_out(index_new:end)];
                end
            end
        end
    end
    catch
            Xi_init_out = [];
        disp('model missing')
    end
    
    %load previous optimal normalising parameters
    try
        if ~isempty(cell2mat(solution_to_load.theta_a(model_to_load)))
            theta_a = cell2mat(solution_to_load.theta_a(model_to_load));
            theta_k = cell2mat(solution_to_load.theta_k(model_to_load));
        else
            disp('theta empty')
        end
    catch
        disp('theta error')
    end
                

end
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% additional functions %%%%
    
    
    
    
    
    
    
    
    
    
function coefficients = generate_polynomial_coefficients(PF_order)

coefficients = [0,0];

for sum_coef=1:PF_order(1)+PF_order(2);
    for index_k=0:min(PF_order(1),sum_coef)
        if sum_coef-index_k<=PF_order(2)
            coefficients = [coefficients;[index_k,sum_coef-index_k]];
        end
    end
end
            
end