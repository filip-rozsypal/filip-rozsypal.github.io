function [summation_matrix,weights_grid,nodes_grid,aaa_grid, ...
            kkk_grid,kk_grid,aa_grid,k_grid,a_grid,nodes,weights] =  ... 
            get_grids_sim_2(k,a,N_quadrature,sig_a,minN,maxN,TT_multiplier,...
            stretch_factor_k,stretch_factor_a,ddelta)
%% ADD LATER
    %k_mean,k_sigma,a_mean,a_sigma 
    % fix_seed
    %stretching
    
%%
    

    


    

    TT         = 1*TT_multiplier; %starting value for multiplier for distance (calibrated to minimize number of attempts)
    cut_factor = 0; %?

% boundary onn the number of points to compute the distance matrix for
[~,sys] = memory;
if sys.PhysicalMemory.Available > 2.6e+10
    thinning_target = 35000 ;
    thinning_target = 25000 ;
    
    thinning_target = 15000 ;
elseif  sys.PhysicalMemory.Available > 1.5e+10
    thinning_target = 25000;
    thinning_target = 12000;
else
    thinning_target = 15000;
end

%define the state vectors
T = length(k); 
Sigma_in = [k' a'];
Sigma_orig = Sigma_in;


% k_max_index = find(max(f_k(Sigma_in))==Sigma_in(:,1));
% Sigma_k_max = Sigma_in(k_max_index,:);

%     if fix_seed
%         rng(1234567890) % fix the seed
%     end

Sigma_in = single(Sigma_in); %smaller matrices, the precission is not needed

% randomize the ordering
% randomisation = randperm(size(Sigma_in,1))';
% Sigma_in      = Sigma_in(randomisation,:);


%% adjust the input Sigma
%ignore first 30 observations due to convergence to new steady state after
%a change in Xi
if size(Sigma_in,1)>1000
    Sigma_in(1:30,:)=[]; 
end

Sigma_in_orig = Sigma_in;

Sigma_in_extra = Sigma_in;
 
if max([stretch_factor_k stretch_factor_a])>0
    %matrix of stretching coefficients
    stretch_coef = repmat([stretch_factor_k stretch_factor_a ],size(Sigma_in,1),1);

    Sigma_in_for_stretching = Sigma_in;
    Sigma_mean = repmat(median(Sigma_in_for_stretching,1),size(Sigma_in,1),1); %medians of the variables

    
    %apply upper stretching
    Sigma_in_extra = Sigma_in + stretch_coef.*(Sigma_in-Sigma_mean);

    Sigma_in = [Sigma_in;Sigma_in_extra];
end






%% thinning
thinning_const2 = ceil(size(Sigma_in,1)/thinning_target); 
T_adjusted      = T/thinning_const2;
Sigma_set_thin  = Sigma_in(1:thinning_const2:end,:);

        




%% gettign the grid
%fprintf('gridding: \n')  
  
Sigma_set_lp_old=[];

Sigma_set_lp = get_set( ... 
   Sigma_set_thin, ... 
    Sigma_set_lp_old,TT,minN,maxN,ddelta); 


%convert back to double precission
Sigma_set = double(Sigma_set_lp);

k_grid = Sigma_set(:,1)';
a_grid = Sigma_set(:,2)';

[~,index_k_13] = find(k_grid>13)
k_grid(index_k_13) = [];
a_grid(index_k_13) = [];

[~,index_k_5] = find(k_grid<5)
k_grid(index_k_5) = [];
a_grid(index_k_5) = [];
% [k_grid,I] = sort(k_grid);
% a_grid = a_grid(I);
%% quadrature nodes
[nodes, weights] = GaussHermite_2(N_quadrature);
nodes   = sqrt(2)*sig_a*nodes;
weights = pi^(-0.5)*weights;
%%

[nodes_grid,kkk_grid] = comb_vector(nodes',k_grid);
[~,aaa_grid] = comb_vector(nodes',a_grid);
[weights_grid,~] = comb_vector(weights',a_grid);

 
lkk  = length(k_grid);
lkkk = length(kkk_grid);
ln   = length(nodes');

summation_matrix = zeros(lkkk,lkk);
for i=1:lkk
    summation_matrix(1+(i-1)*ln:i*ln,i) = weights_grid(1+(i-1)*ln:i*ln)';
end




[kk_grid,aa_grid] = comb_vector(k_grid,a_grid);


%%

figure(100)
scatter(Sigma_in_extra(:,1),Sigma_in_extra(:,2),'.k');hold on
scatter(Sigma_orig(:,1),Sigma_orig(:,2),'.b')
scatter(Sigma_set(:,1),Sigma_set(:,2),75,'r','filled')
hold off


%%


% [density_in,bins_in] = hist(f_k(Sigma_in_orig),50);
% [density_extra,bins_extra] = hist(f_k(Sigma_in_extra),100);
% figure()
% plot(bins_in,density_in,bins_extra,density_extra,'linewidth',3);
% vline(f_k(Sigma_set_lp),'-k')
% xlabel('capital');legend('original','stretched');
% name=strcat('sigma_k_',num2str(global_iteration));
% figuresize(16,12,'centimeters')
% target= strcat(folder,name,'.pdf');
% print(gcf, '-dpdf', '-r100', target);
% close;



end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% additional functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function set_out=get_set(set_in,set_in_old,TT,minN,maxN,ddelta)        
    
[Sigma_normalised1,V1,g_hat1,D_mat1] = get_distance(set_in);
    
    set_out = get_Sigma_set(set_in,ddelta,TT,set_in_old, ... 
                D_mat1,g_hat1,V1,Sigma_normalised1,minN,maxN);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Sigma_randomised_order,V,g_hat,D_mat]=get_distance(Sigma)
%inputs:
%Sigma ... matrix of points

    Sigma_randomised_order = Sigma;
    
    Sigma_demean = (Sigma-repmat(mean(Sigma),size(Sigma,1),1))./ ... 
        repmat(sqrt(var(Sigma)),size(Sigma,1),1);
    [~,~,V] = svd(Sigma_demean);
    
    %compute the size of the distance matrix
    NN=size(Sigma_demean,1);
    
    %Sigma_normalised = Sigma_adjusted;
    Sigma_normalised = Sigma_demean*V;
    
    %disp(N)
    fprintf('computing distance')
    %compute distance matrix
    D_mat = distmat(Sigma_normalised,3);

    fprintf(' done')

 %   D_mat=D_mat+D_mat';   ??????


    %compute density
    d     = size(Sigma,2);
    h     = NN^(-1/(d+4));   
    g_hat = 1/NN /(2*pi)^(d/2)*h^(-d)*sum(exp(-D_mat/(2*h^2)));    
end    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Sigma_set = get_Sigma_set(Sigma,delta,TT,Sigma_set_old,D_mat,g_hat,V,... 
    Sigma_normalised,min_points,max_points)
% function to select Sigma_set given distnances and target number of points

    N = size(Sigma_normalised,1);
    if delta>0
    %cut off lowest delta%
            %sort
            g_hat_sorted=sort(g_hat);
            %get the cot off possition
            cut_off_pos = max(1,round(N*delta));
            cut_off_val = g_hat_sorted(cut_off_pos);

            %cuf off the points
            Sigma_normalised(g_hat<cut_off_val,:)=[];
            % recompute  the distance matrix
            D_mat(g_hat<cut_off_val,:)=[];
            D_mat(:,g_hat<cut_off_val)=[];
    end

    ccont=1;
    multiplier=1;
    N_iter=1;

    while ccont

        threshold = median(median(D_mat))/TT/multiplier;
        final_set_normalised = zeros(size(Sigma_normalised));

        %construct the set
        consider = ones(size(Sigma_normalised,1),1); %1 for points still to be considered, 
                                                   %0 for the points already eliminated
                                                   
        in_set = zeros(size(Sigma_normalised,1),1);  %set of already chosen points, all zeros at the start

        cont = 1;        
        while cont
            index           = find(consider,1,'first'); %find the first point to consider
            consider(index) = 0;                        %do not consider it anymore
            in_set(index)   = 1;                        %add it to the chosen set

            consider = consider.*(D_mat(index,:)>threshold)'; %keep considering only points further than threshold away
            if all(consider==0)             %stop if all points have been considered
                cont = 0;
            end
        end
        N_points_chosen = sum(in_set);
        
        %disp(strcat('number of points in the erg set: ',num2str(size(Sigma_set,1))));
        fprintf('(%i)',sum(in_set));
        
        %% check the convergence and adjust the multiplier otherwise
        if N_points_chosen>max_points
            fprintf('-');
            multiplier = multiplier*0.95;
        end

        if N_points_chosen<min_points
            fprintf('+')
            multiplier = multiplier*1.15;
        end

        if N_points_chosen<=max_points && N_points_chosen>=min_points || N_iter>20
            ccont=0;
        end

        N_iter=N_iter+1;

    end
    
    fprintf('...elimination done ')
    
    %find the points in Sigma_set that correspond to the points chosen
    final_set_normalised= Sigma_normalised(find(in_set),:);       
    %rescale back
%     Sigma_set = final_set_normalised/V;
    Sigma_set = final_set_normalised;    
%     %add back the ignored columns           
%     %Sigma_set=[Sigma_set(:,1) zeros(size(Sigma_set,1),N_ind) Sigma_set(:,2:end)]; 
%     Sigma_set_final=zeros(N_points_chosen,9);
%     Sigma_set_final(:,indeces_keep)=Sigma_set;
%     Sigma_set=Sigma_set_final;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function generate_hist(index,hist_title,Sigma_in,Sigma_in_extra,Sigma_set_lp,Sigma_set_lr,Sigma_set_qP, ... 
    folder,global_iteration)

x=Sigma_in(:,index);
y=Sigma_in_extra(:,index);
z1=Sigma_set_lp(:,index);
z2=Sigma_set_lr(:,index);
z3=Sigma_set_qP(:,index);

[~, t] = hist([x;y;z1;z2;z3], 50);

nx = hist(x, t); % Sort x into bins.
nx = transpose(nx/sum(nx));
ny = hist(y, t); % Sort y into bins.
ny = transpose(ny/sum(ny));
nz1=hist(z1, t);
nz1 = transpose(nz1/sum(nz1));
nz2=hist(z2, t);
nz2 = transpose(nz2/sum(nz2));
nz3=hist(z3, t);
nz3 = transpose(nz3/sum(nz3));

bar(t, [nx, ny,nz1,nz2,nz3],'barwidth',1)
legend('data','extension','lp','lr','qP')
title(hist_title)


name=strcat('grid_',hist_title,'_',num2str(global_iteration));
figuresize(20,10,'centimeters')
target= strcat(folder,name,'.pdf');
print(gcf, '-dpdf', '-r100', target);
close;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dmat,opt] = distmat(xy,varargin)
% DISTMAT Distance matrix for a set of points
%   Returns the point-to-point distance between all pairs of points in XY
%       (similar to PDIST in the Statistics Toolbox)
%
%   DMAT = DISTMAT(XY) Calculates the distance matrix using an automatic option
%   DMAT = DISTMAT(XY,OPT) Uses the specified option to compute the distance matrix
%   [DMAT,OPT] = DISTMAT(XY) Also returns the automatic option used by the function
%
%   Inputs:
%       XY is an NxP matrix of coordinates for N points in P dimensions
%       OPT (optional) is an integer between 1 and 4 representing the chosen
%           method for computing the distance matrix (see note below)
%
%   Outputs:
%       DMAT is an NxN matrix, where the value of DMAT(i,j) corresponds to
%           the distance from XY(i,:) to XY(j,:)
%       OPT (optional) is an integer between 1 and 4 representing the method
%           used to compute the distance matrix (see note below)
%
%   Note:
%       DISTMAT contains 4 methods for computing the distance matrix
%         OPT=1 Usually fastest for small inputs. Takes advantage of the symmetric
%               property of distance matrices to perform half as many calculations
%         OPT=2 Usually fastest for medium inputs. Uses a fully vectorized method
%         OPT=3 Usually fastest for large inputs. Uses a partially vectorized
%               method with relatively small memory requirement
%         OPT=4 Another compact calculation, but usually slower than the others
%
%   Example:
%       % Test computation times for the options
%       n = [10 100 1000];
%       dmat = distmat(10*rand(10,3),1); % First call is always really slow
%       for k=1:3
%           for opt=1:4
%               tic; [dmat,opt] = distmat(10*rand(n(k),3),opt); t=toc;
%               disp(sprintf('n=%d, opt=%d, t=%0.6f', n(k), opt, t))
%           end
%       end
%
%   Example:
%       xy = 10*rand(25,2);  % 25 points in 2D
%       dmat = distmat(xy);
%       figure; plot(xy(:,1),xy(:,2),'.');
%       for k=1:25, text(xy(k,1),xy(k,2),[' ' num2str(k)]); end
%       figure; imagesc(dmat); set(gca,'XTick',1:25,'YTick',1:25); colorbar
%
%   Example:
%       xyz = 10*rand(20,3);  % 20 points in 3D
%       dmat = distmat(xyz);
%       figure; plot3(xyz(:,1),xyz(:,2),xyz(:,3),'.');
%       for k=1:20, text(xyz(k,1),xyz(k,2),xyz(k,3),[' ' num2str(k)]); end
%       figure; imagesc(dmat); set(gca,'XTick',1:20,'YTick',1:20); colorbar
%
% Author: Joseph Kirk
% Email: jdkirk630 at gmail dot com
% Release: 1.0
% Release Date: 5/29/07
    % process inputs
    error(nargchk(1,2,nargin));
    [n,dims] = size(xy);
    numels = n*n*dims;
    opt = 2; if numels > 5e4, opt = 3; elseif n < 20, opt = 1; end
    for var = varargin
        if length(var{1}) == 1
            opt = max(1, min(4, round(abs(var{1}))));
        else
            error('Invalid input argument.');
        end
    end

    % distance matrix calculation options
    switch opt
        case 1 % half as many computations (symmetric upper triangular property)
            [k,kk] = find(triu(ones(n),1));
            dmat = zeros(n);
            dmat(k+n*(kk-1)) = sqrt(sum((xy(k,:) - xy(kk,:)).^2,2));
            dmat(kk+n*(k-1)) = dmat(k+n*(kk-1));
        case 2 % fully vectorized calculation (very fast for medium inputs)
            a = reshape(xy,1,n,dims);
            b = reshape(xy,n,1,dims);
            dmat = sqrt(sum((a(ones(n,1),:,:) - b(:,ones(n,1),:)).^2,3));
        case 3 % partially vectorized (smaller memory requirement for large inputs)
            dmat = zeros(n,n);
            parfor k = 1:n
                dmat(k,:) = sqrt(sum((xy(k*ones(n,1),:) - xy).^2,2));
            end
        case 4 % another compact method, generally slower than the others
            a = (1:n);
            b = a(ones(n,1),:);
            dmat = reshape(sqrt(sum((xy(b,:) - xy(b',:)).^2,2)),n,n);
    end
end

















