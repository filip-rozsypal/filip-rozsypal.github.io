
clear;
% clc


%% initialisation
% setting
Solution_type = 'direct'; 
%Solution_type = 'direct_e'; 
Grid_type = 'product'; 

% Solution_type = 'iterative'; 
% Grid_type = 'ergodic'; 

Problem_type = 'complex'; 
% Problem_type = 'simple'; 


T_sim = 1e5; %length of the simulation



% Gamma = gamma/(1+  exp( gammaD0*(k-gammaD1) )  )
% Gamma' = -gammaD0*exp( gammaD0*(k-gammaD1) )*gamma/(1+  exp(gammaD0*(k-gammaD1) )  )^2
gamma   = 7.5e-2;

gammaD0 = 15; 
gammaD1 = 7.5;

gammaU0 = -15; 
gammaU1 = 11.5;


if strcmp(Problem_type,'simple')
    gamma = 0;
end


% economic parameters
alpha = 0.33;  % capital share of output
beta  = 0.95;  % discount factor
delta = 0.025; % depreciation rate
rho   = 0.95;  % productivity persistence
sig_a = 0.02; % volatilify of productivity shocks
sigma = 2;
kappa = 1;


rng(12345)
epsilon = sig_a*randn(1,T_sim);

% Problem_type_set={'simple', 'complex'}
% for ii=1:2
%     Problem_type=Problem_type_set{ii}

%% simulate productivity
PF_order=[2 2];PF_type = 'basic'; %to use define functions
[Xi,theta_a,theta_k] = load_starting_xi(PF_order,PF_type,Solution_type,Grid_type,Problem_type,[],[]); 

define_functions;


a = zeros(1,T_sim); 
for t=1:T_sim    
    a(t+1) = f_a_p(a(t),epsilon(t));
end


%%
PF_type_set   = {'basic','norm', 'orthogonal', 'orthnorm'};


for index_PF_type = 4:4
    PF_type = PF_type_set{index_PF_type}
    

    for PF_order_1 = 1:2  
        for PF_order_2 = PF_order_1:PF_order_1
            PF_order = [PF_order_1 PF_order_2]

            %% load policy function parameters
            [Xi,theta_a,theta_k] = load_starting_xi(PF_order,PF_type,Solution_type,Grid_type,Problem_type,[],[]);
Xi
            if ~isempty(theta_a)  %solution has been found
                %% define functions
                define_functions;

                %% simulate the results
                % get the non-stochastic steady state
                k = ones(1,500);               
                k(1)=13;               
                for t=1:500    
                    k(t+1) = f_k_p(0,k(t),Xi);
                end
              
                
                k_ss=k(end);

                % simulate the series
                k = ones(1,T_sim);
                k(1)=k_ss;
                tic;
                for t=1:T_sim    
                    k(t+1) = f_k_p(a(t),k(t),Xi);
                end
                simulation_time=toc;
                % accuracy  
                T_start = 500;
                errors = f_EE_error_long( ...
                                a(T_start:end-2),k(T_start:end-2),a(T_start+1:end-1), ...
                                k(T_start+1:end-1),k(T_start+2:end) ...
                                         );

                accuracy = norm(errors);
                accuracy_rel = mean(abs(errors));
            else  %solution not found
                accuracy        = NaN;
                accuracy_rel    = NaN;
                simulation_time = NaN;
                errors          = NaN;
            end


            %% save the results
            save_simulation(PF_type,PF_order,accuracy,accuracy_rel,simulation_time, ...
                                Solution_type,Grid_type,Problem_type,errors)
            disp('saved')

        end
    end


end

% end