% Basic solution



clear;
%clc






%% initialisation
% setting
PF_type   = 'orthnorm'; % 'basic','norm', 'orthogonal', 'orthnorm'


%for index_move=30:2:38

% for PF_order_1=2:7
%     for PF_order_2=2:7
%         PF_order=[PF_order_1 PF_order_2]


PF_order  = [4 4];

N_quadrature = 5;

T_sim = 5e3; %length of the simulation
T_irf = 32; 

% Gamma = gamma*(  exp( -gammaD0*(k-gammaD1) )   +exp( gammaU0*(k-gammaU1) )  )
gamma   = 0*1e-2;
gammaU0 = 0*3; 
gammaU1 = 45; 
gammaD0 = 4; 
gammaD1 = 31.5;

% economic parameters
alpha = 0.36;  % capital share of output
beta  = 0.99;  % discount factor
delta = 0.025; % depreciation rate
rho   = 0.9;  % productivity persistence
sig_a = 0.02; % volatilify of productivity shocks
sigma = 2;
psi   = 2;
%%

k_ss = 30;

%optimisation setting
options = optimset('Display','final','MaxFunEvals',2e5,'TolX',1e-10,'Tolfun',1e-10,'MaxIter',1e6);

% starting guess
Xi_init = load_starting_guess(PF_order,PF_type);
Xi=Xi_init
% 
%  Xi_init = [      39.6808    4.8281    0.9938    1.6806    0.0304  ... 
%                 -0.0002    0.5834    0.0172    0.0003    0.0000   -0.0012   -0.0001 ...
%                 0.0000    0.0002   -0.0000    0.0000]

%Xi_init =  [ 37.9995    0.3118    2.7028    0.0167]
% Xi_init=zeros(size(Xi_init))
% Xi_init(1)=38


switch PF_type
        case 'basic'
            
            % scaling parameters
            theta_a = [0 1];
            theta_k = [0 1];            
            
        case 'orthogonal'
           
            % scaling parameters
            theta_a = [0 1];
            theta_k = [0 1];            

        case 'norm'           

            % scaling parameters
            theta_a = [0 0.1];
            theta_k = [39 2.8];            
            
        case 'orthnorm'
            % scaling parameters
            theta_a = [0 0.9];
            theta_k = [38 5];                
             
end

%% grids and quadrature nodes
[summation_matrix,weights_grid,nodes_grid,aaa_grid,... 
    kkk_grid,k_grid_adj,a_grid_adj,k_grid,a_grid,nodes,weights] = ... 
    get_grids(N_quadrature,PF_type,sig_a);

%% define functions
% policy function
[PF,coefficients] = load_policy_function(PF_type,PF_order,theta_a,theta_k);
f_k_p = @(a,k,xi) PF(a,k,xi);

%other function
f_a_p = @(a,epsilon) rho*a + epsilon; % law of motion for productivity

% solving for optimal labour supply
f_l_long = @(l,k,a,Xi) ...
            l.^alpha ...
            - l.^(1+alpha) ...
            - psi*(1-alpha)/(sigma-1)*l.^(1-alpha) ...
            +psi/(sigma-1)*( (1-delta)*k - f_k_p(a,k,Xi)  ) ./ ( a.*(1-alpha)*k.^alpha  );
f_l      = @(a,k) arrayfun(@(i) fzero(@(l) f_l_long(l,k(i),a(i),Xi),0.3),1:numel(k));


% functions
kappa=1

f_y      = @(a,k) kappa*exp(a).*k.^alpha.*f_l(a,k).^(1-alpha);  %output
f_GAMMA  = @(k) gamma*(  exp( -gammaD0*(k-gammaD1) )   +exp( gammaU0*(k-gammaU1) )  ); % capital boundary function
f_dGAMMA = @(k) gamma*(  -gammaD0*exp( -gammaD0*(k-gammaD1) )   + gammaU0*exp( gammaU0*(k-gammaU1) )  );  % dGAMMA/dk
f_R      = @(a,k) (alpha*kappa*exp(a).*k.^(alpha-1).*f_l(a,k).^(1-alpha)+1-delta)./(1+f_dGAMMA(k)); % interest rate
f_c      = @(a,k,k_p) f_y(a,k)+(1-delta)*k-f_GAMMA(k_p)-k_p; % consumption
f_u      = @(c,l) c^(1-sigma)/(1-sigma)*(1-l).^(-psi); % utility of consumption
f_du     = @(c,l) c.^(-sigma)*(1-l)^(-psi);



f_EE_error_long = @(a,k,a_p,k_p,k_pp)  ... 
        1- beta*f_du(f_c(a_p,k_p,k_pp),f_l(a,k))./f_du(f_c(a,k,k_p),f_l(a,k)).*f_R(a_p,k_p);

f_EE_error = @(a,k,epsilon,xi) ...
    f_EE_error_long(a,k,f_a_p(a,epsilon),f_k_p(a,k,xi),f_k_p(f_a_p(a,epsilon),f_k_p(a,k,xi),xi));


f_SSR = @(Xi) norm(f_EE_error(aaa_grid,kkk_grid,nodes_grid,Xi)*summation_matrix);

adj_EE_SSR= @(Xi) EE_SSR(Xi,a_grid,k_grid,nodes,weights,f_EE_error);



% %test
% f_SSR(Xi_init) - adj_EE_SSR(Xi_init);



%% projection
fprintf('optimisation...')
 
tic; 
[Xi,fval] = fminsearch(f_SSR,Xi_init,options)
solution_time=toc;

 %%
%  options = optimset('Display','iter','MaxFunEvals',20000,'TolX',1e-8,'Tolfun',1e-8,'MaxIter',10000);
%  ub = [10,1,10,10];
%  lb = [-10,-1,-1,-1];
%   [Xi,fval] = fmincon(f_SSR,Xi_init,[],[],[],[],lb,ub,[],options)
  %%

%% analyze the errors
% 
% error=zeros(length(a_grid_adj),length(k_grid_adj));
% for index_a=1:length(a_grid_adj)
%     for index_k=1:length(k_grid_adj)       
%         for index_eps=1:length(nodes)
%             error(index_a,index_k) = error(index_a,index_k) + ...
%                 weights(index_eps)*f_EE_error(a_grid_adj(index_a),k_grid_adj(index_k),nodes(index_eps),Xi);
%         end  
%     end
% end
% 
% [mesh_a,mesh_k] = meshgrid(k_grid_adj,a_grid_adj);
% figure(10)
% surf(mesh_k,mesh_a,error)
% xlabel('productivity')
% ylabel('capital')
% zlabel('EE error')






%% simulate the results
rng(12345)
% get the steady state
a = zeros(1,500);
k = ones(1,500);
k(1)=k_ss;

for t=1:500    
    k(t+1) = f_k_p(a(t),k(t),Xi);
end
k_ss=k(end);



 
 

 

% simulate the series
epsilon = sig_a*randn(1,T_sim);

a = zeros(1,T_sim);
k = ones(1,T_sim);
k(1)=k_ss;
tic;
for t=1:T_sim    
    a(t+1) = f_a_p(a(t),epsilon(t));
    k(t+1) = f_k_p(a(t),k(t),Xi);
end
simulation_time=toc;
% accuracy  
T_start = 500;
EE_error = f_EE_error_long( ...
                a(T_start:end-2),k(T_start:end-2),a(T_start+1:end-1), ...
                k(T_start+1:end-1),k(T_start+2:end));

accuracy = norm(EE_error)
% if isnan(accuracy)
%     accuracy=10;
% end
    

%% save the results
if ~isnan(accuracy)
    save_results(PF_type,PF_order,Xi_init,Xi,accuracy,solution_time,simulation_time,k_grid_adj,a_grid_adj);
end

%% plot the results
% simulated series
c = f_c(a(1:end-1),k(1:end-1),k(2:end));

figure(1)
subplot(3,1,1)
plot(k)
legend('capital')
legend('boxoff')

subplot(3,1,2)
plot(a)   
legend('productivity')
legend('boxoff')

subplot(3,1,3)
plot(c)
legend('consumption')
legend('boxoff')


% irf
a_irf = zeros(1,T_irf);
a_irf(1) = sig_a;
k_irf = k_ss*ones(1,T_irf);

for t=1:T_irf   
    a_irf(t+1) = f_a_p(a_irf(t),0);
    k_irf(t+1) = f_k_p(a_irf(t),k_irf(t),Xi);
end



figure(2)
subplot(1,2,1)
plot((k_irf-k_ss)/k_ss)
legend('capital irf')
legend('boxoff')

subplot(1,2,2)
plot(a_irf)
legend('productivity irf')
legend('boxoff')




% scatter plot of simulation vs the grid
figure(3)
scatter(a(1:4:end),k(1:4:end),'.');
hold on;
scatter(a_grid_adj,k_grid_adj,'r','filled')

[~, max_k_pos] = max(k);
[~, min_k_pos] = min(k);
[~, max_a_pos] = max(a);
[~, min_a_pos] = min(a);

scatter([a(min_k_pos) a(max_k_pos) a(min_a_pos) a(max_a_pos)], ...
        [k(min_k_pos) k(max_k_pos) k(min_a_pos) k(max_a_pos)],'ok','filled');
hold off


% policy function
k_p=zeros(length(a_grid),length(k_grid));
for index_a=1:length(a_grid)
    for index_k=1:length(k_grid)       
        for index_eps=1:length(nodes)
            k_p(index_a,index_k) = f_k_p(a_grid(index_a),k_grid(index_k),Xi);
        end  
    end
end

[mesh_a,mesh_k] = meshgrid(k_grid,a_grid);
figure(4)
surf(mesh_k,mesh_a,k_p)
xlabel('productivity')
ylabel('capital')
zlabel('capital tomorrow')

% % GAMMA function
% figure(5)
% plot(k_grid,f_GAMMA(k_grid))
% vline([quantile(k,0.05) quantile(k,0.25) quantile(k,0.50) quantile(k,0.75) quantile(k,0.95)])
% 

figure(3)

figure(5)
e_grid=min(k):0.1:max(k);
plot(e_grid,f_k_p(zeros(size(e_grid)),e_grid,Xi))





%     end
% end
% 


%end
