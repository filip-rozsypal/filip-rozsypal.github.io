function save_simulation(PF_type,PF_order,accuracy,accuracy_rel,simulation_time, ...
                        Solution_type,Grid_type,Problem_type,errors)

% biggest possible order of polynomisals 
max_order = 8;

[xx,yy] = comb_vector(0:max_order,0:max_order);
model_numbers = [xx',yy'];


model_number = [];

i=1;
cont=1;
while cont
    if isequal(model_numbers(i,:),PF_order)
        cont=0;
        model_number = i;
    end
    i=i+1;
end

target_string = strcat('solution_',Solution_type,'_',Grid_type,'_',Problem_type,'.mat');
load(target_string);

% save the results into appropriate matrix
switch PF_type
        case 'basic'
            solution_1.acc(model_number)          = accuracy; 
            solution_1.accrel(model_number)       = accuracy_rel;   
            solution_1.sim_t(model_number)        = simulation_time;  
            solution_1.datetime_sim{model_number} = datetime;
            %solution_1.errors{model_number}       = errors;
            solution_1.errors_avg{model_number}   = mean(abs(errors));
            solution_1.errors_quant{model_number} = quantile(abs(errors),[0.5 0.9 0.95 0.99 0.999]);            
            
        case 'orthogonal'
            solution_2.acc(model_number)          = accuracy;  
            solution_2.accrel(model_number)       = accuracy_rel;             
            solution_2.sim_t(model_number)        = simulation_time;      
            solution_2.datetime_sim{model_number} = datetime;  
            %solution_2.errors{model_number}       = errors;
            solution_2.errors_avg{model_number}   = mean(abs(errors));
            solution_2.errors_quant{model_number} = quantile(abs(errors),[0.5 0.9 0.95 0.99 0.999]);            
            
        case 'norm'           
            solution_3.acc(model_number)          = accuracy;  
            solution_3.accrel(model_number)       = accuracy_rel;             
            solution_3.sim_t(model_number)        = simulation_time;       
            solution_3.datetime_sim{model_number} = datetime;   
            %solution_3.errors{model_number}       = errors;
            solution_3.errors_avg{model_number}   = mean(abs(errors));
            solution_3.errors_quant{model_number} = quantile(abs(errors),[0.5 0.9 0.95 0.99 0.999]);            
                        
        case 'orthnorm'
            solution_4.acc(model_number)          = accuracy;    
            solution_4.accrel(model_number)       = accuracy_rel;             
            solution_4.sim_t(model_number)        = simulation_time;   
            solution_4.datetime_sim{model_number} = datetime;     
            %solution_4.errors{model_number}       = errors;
            solution_4.errors_avg{model_number}   = mean(abs(errors));
            solution_4.errors_quant{model_number} = quantile(abs(errors),[0.5 0.9 0.95 0.99 0.999]);   
end


target_string = strcat('solution_',Solution_type,'_',Grid_type,'_',Problem_type,'.mat');
save(target_string,'solution_1','solution_2','solution_3','solution_4');