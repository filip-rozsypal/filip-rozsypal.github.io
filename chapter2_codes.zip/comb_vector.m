% this function combines two row vectors x and y to produce vectors xx and yy
% with all combinations of x and y
function [xx,yy] = comb_vector(x,y)

%get the vecotr lengths
lx = length(x);
ly = length(y);

% first vector repets itself ly times
xx = repmat(x,1,ly);



% the second vector repeats subsequentely each element in y exactly lx
% times
yy = [];
for i=1:ly
    yy = [yy repmat(y(i),1,lx)];
end
