

% parameter=[]



parameter.crit_xi = crit_xi ; 
parameter.crit_sim= crit_sim ; 
parameter.crit_grid = crit_grid ; 

parameter.lambda = lambda ; 

parameter.N_quadrature = N_quadrature ; 

parameter.T_sim = T_sim ; 
parameter.T_irf=  T_irf; 

%parameter.options =  options; 

parameter.gamma =  gamma; 
parameter.gammaD0=  gammaD0; 
parameter.gammaD1 = gammaD1 ; 
parameter.theta_a =  theta_a; 
parameter.theta_k =  theta_k;    
      


parameter.alpha = alpha ; 
parameter.beta  = beta ; 
parameter.delta = delta ; 
parameter.rho  =  rho; 
parameter.sig_a = sig_a ; 
parameter.sigma = sigma ; 
% 

