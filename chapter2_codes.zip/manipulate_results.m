



clear all;
clc;






accrel = zeros(2,2,4,8,8);
acc = zeros(2,2,4,8,8);
errors_avg = zeros(2,2,4,8,8);
e_quant = zeros(2,2,4,8,8,5);

sol_t = zeros(2,2,4,8,8);
sim_t = zeros(2,2,4,8,8);
datetime_sim = [];


Solution_type_set = {'iterative','direct','direct_e'};
Grid_type_set = {'ergodic', 'product'};
PF_type_set   = {'basic','norm', 'orthogonal', 'orthnorm'};
Problem_type_set = {'simple', 'complex'};



for i1=1:3
    i1
    Solution_type = Solution_type_set{i1};
    Grid_type     = Grid_type_set{min(2,i1)};
    
    for i2=1:2
        i2
       Problem_type =  Problem_type_set{i2};

        target_string = strcat('solution_',Solution_type,'_',Grid_type,'_',Problem_type,'.mat');
        load(target_string);
       
        for PF_order_1=1:6  
            PF_order_1
            for PF_order_2=PF_order_1:PF_order_1
                PF_order=[PF_order_1 PF_order_2];
                
                model_to_load = find( (solution_1.a<=PF_order(2)) .*  ...
                                      (solution_1.k<=PF_order(1)),1,'last');
                                      

                acc(i1,i2,1,PF_order_1,PF_order_2) = solution_1.acc(model_to_load);
                acc(i1,i2,2,PF_order_1,PF_order_2) = solution_2.acc(model_to_load);
                acc(i1,i2,3,PF_order_1,PF_order_2) = solution_3.acc(model_to_load);
                acc(i1,i2,4,PF_order_1,PF_order_2) = solution_4.acc(model_to_load);
                
                accrel(i1,i2,1,PF_order_1,PF_order_2) = solution_1.accrel(model_to_load);
                accrel(i1,i2,2,PF_order_1,PF_order_2) = solution_2.accrel(model_to_load);
                accrel(i1,i2,3,PF_order_1,PF_order_2) = solution_3.accrel(model_to_load);
                accrel(i1,i2,4,PF_order_1,PF_order_2) = solution_4.accrel(model_to_load);
                
                e_quant(i1,i2,1,PF_order_1,PF_order_2,:) = solution_1.errors_quant{model_to_load};
                e_quant(i1,i2,2,PF_order_1,PF_order_2,:) = solution_2.errors_quant{model_to_load};
                e_quant(i1,i2,3,PF_order_1,PF_order_2,:) = solution_3.errors_quant{model_to_load};
                e_quant(i1,i2,4,PF_order_1,PF_order_2,:) = solution_4.errors_quant{model_to_load};
                
                errors_avg(i1,i2,1,PF_order_1,PF_order_2) = solution_1.errors_avg{model_to_load};
                errors_avg(i1,i2,2,PF_order_1,PF_order_2) = solution_2.errors_avg{model_to_load};
                errors_avg(i1,i2,3,PF_order_1,PF_order_2) = solution_3.errors_avg{model_to_load};
                errors_avg(i1,i2,4,PF_order_1,PF_order_2) = solution_4.errors_avg{model_to_load};
                
                datetime_sim{i1,i2,1,PF_order_1,PF_order_2} = solution_1.datetime_sim{model_to_load};
                datetime_sim{i1,i2,2,PF_order_1,PF_order_2} = solution_2.datetime_sim{model_to_load};
                datetime_sim{i1,i2,3,PF_order_1,PF_order_2} = solution_3.datetime_sim{model_to_load};
                datetime_sim{i1,i2,4,PF_order_1,PF_order_2} = solution_4.datetime_sim{model_to_load};  
                
                sim_t(i1,i2,1,PF_order_1,PF_order_2) = solution_1.sim_t(model_to_load);
                sim_t(i1,i2,2,PF_order_1,PF_order_2) = solution_2.sim_t(model_to_load);
                sim_t(i1,i2,3,PF_order_1,PF_order_2) = solution_3.sim_t(model_to_load);
                sim_t(i1,i2,4,PF_order_1,PF_order_2) = solution_4.sim_t(model_to_load);
                
                sol_t(i1,i2,1,PF_order_1,PF_order_2) = solution_1.sol_t(model_to_load);
                sol_t(i1,i2,2,PF_order_1,PF_order_2) = solution_2.sol_t(model_to_load);
                sol_t(i1,i2,3,PF_order_1,PF_order_2) = solution_3.sol_t(model_to_load);
                sol_t(i1,i2,4,PF_order_1,PF_order_2) = solution_4.sol_t(model_to_load);   
                
            end
        end
    end
end

%%
save('results_manipulated','e_quant','acc','accrel','errors_avg',...
    'datetime_sim','sim_t','sol_t')
%%
for i=1:8
    accrel_sym(:,:,:,i) = squeeze(accrel(:,:,:,i,i));
    e_quant_sym(:,:,:,i,:) = squeeze(e_quant(:,:,:,i,i,:));
    acc_sym(:,:,:,i) = squeeze(acc(:,:,:,i,i));
    sim_t_sym(:,:,:,i) = squeeze(sim_t(:,:,:,i,i));
    
    
end

%% figures
% compare
% figure(1)
% lines = plot(squeeze(e_quant(1,2,4,1:8,4,:)),'linewidth',2);
% xlabel('order of the polynomial')
% legend('median','0.9q','0.95q','0.99q','0.999q')
% title('complex, Iterative, orthogonal, normalized, quantiles')
% 
% figure(2)
% lines = plot(squeeze(e_quant(1,2,:,1:8,4,1))','linewidth',2);
% set(lines(end),'marker','+')
% xlabel('order of the polynomial');ylabel('EE realized residual')
% legend('basic','norm', 'orthogonal', 'orthnorm')
% title('complex, median')
% 
% figure(3)
% lines = plot(squeeze(e_quant(:,2,4,1:8,4,1))','linewidth',2);
% xlabel('order of the polynomial');ylabel('EE realized residual')
% legend('iterative','direct')
% title('complex, median')
% 
% figure(4)
% lines = plot(squeeze(e_quant(1,2,4,1:8,4,:)),'linewidth',2); hold on
% xlabel('order of the polynomial')
% set(lines(:),'marker','+')
% lines = plot(squeeze(e_quant(2,2,4,1:8,4,:)),'linewidth',2); hold off
% title('complex, Iterative, orthogonal, normalized, quantiles')
% legend('median','0.9q','0.95q','0.99q','0.999q')
% 
% 


%%
figure(1)
lines = plot(squeeze(e_quant_sym(1,2,4,1:5,:)),'linewidth',2);
xlabel('order of the polynomial')
legend('median','0.9q','0.95q','0.99q','0.999q')
title('complex, Iterative, orthogonal, normalized, quantiles')
axis([1 5 0 0.15])


figure(2)
lines = plot(squeeze(e_quant_sym(2,2,4,1:5,:)),'linewidth',2);
xlabel('order of the polynomial')
legend('median','0.9q','0.95q','0.99q','0.999q')
title('complex, direct, orthogonal, normalized, quantiles')
 axis([1 8 0 0.15])
 
 
figure(3)
lines = plot(squeeze(e_quant_sym(3,2,4,1:5,:)),'linewidth',2);
xlabel('order of the polynomial')
legend('median','0.9q','0.95q','0.99q','0.999q')
title('complex, direct\_e, orthogonal, normalized, quantiles')
axis([1 8 0 0.15])


%%

% quantiles: [0.5 0.9 0.95 0.99 0.999]
figure(10)
lines1 = plot(squeeze(e_quant_sym(1,2,4,1:5,[1 3 5])),'linewidth',2); hold on
lines2 = plot(squeeze(e_quant_sym(2,2,4,1:5,[1 3 5])),'linewidth',2);
lines3 = plot(squeeze(e_quant_sym(3,2,4,1:5,[1 3 5])),'linewidth',2); hold off;



set(lines1(2),'LineStyle',':')
set(lines2(2),'LineStyle',':')
set(lines3(2),'LineStyle',':')  


set(lines1(3),'LineStyle','--')
set(lines2(3),'LineStyle','--')
set(lines3(3),'LineStyle','--') 

set(lines1,'color','b') 
set(lines2,'color','r') 
set(lines3,'color','k') 


quantile = {'50','95','999'};
description = {'iter','solver','e-solver'};

legend_str = []; 
for i=1:3
    for ii=1:3, 
        legend_str = [legend_str; strcat(description(i),'\_q',quantile(ii))]; 
    end
end 
columnlegend(3, legend_str, 'Location', 'NorthWest', 'boxoff');
% axis([1 5 0 0.1])


% matlab2tikz('G:\filip_dropbox\Dropbox\research\texts\thesis\Chapter2\figures\method_comp.tex', ...
%     'extraAxisOptions','small,legend style={at={(0.5,1.03)},anchor=south},xtick={1,2,3,4,5},ytick={0,0.02,0.04,0.06,0.08,0.1,0.12},yticklabels={0,0.02,0.04,0.06,0.08,0.1,0.12},legend columns=3')

% tikz final setting
% \begin{axis}[%
% at={(1.08875in,0.790625in)},
% xlabel=order of policy function,
% ylabel=quantiles of simulated |Euler errors|,
% xmin=1,
% xmax=5,
% ymin=0,
% ymax=0.14,
% legend style={font=\small,legend cell align=left,align=left,draw=none,fill=none},
% legend style={at={(1.03,0.5)},anchor=west},
% xtick={1,2,3,4,5},
% ytick={0,0.02,0.04,0.06,0.08,0.1,0.12},
% yticklabels={0,0.02,0.04,0.06,0.08,0.1,0.12}
% ]


