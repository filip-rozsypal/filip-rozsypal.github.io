% Basic solution



clear;
clc


Solution_type = 'direct'; %'direct', 
Grid_type = 'product'; % 'product', 

optimize = 0;
%% initialisation
% % setting
% PF_type   = 'orthogonal'; % 'basic','norm', 'orthogonal', 'orthnorm'
Problem_type = 'simple'; % 'simple', 'complex'

Problem_type_set = {'simple', 'complex'}

crit_xi = [];

crit_sim = [];
crit_grid = [];
lambda = [];
exit_flag = [];


%optimisation setting
options = optimset('Display','final','MaxFunEvals',2e5,'TolX',1e-10,'Tolfun',1e-10,'MaxIter',1e6);
%options = optimset('Display','iter','MaxFunEvals',2e4,'TolX',1e-8,'Tolfun',1e-8,'MaxIter',1e6);
% options = optimset('Display','final','MaxFunEvals',2e4,'TolX',1e-6,'Tolfun',1e-6,'MaxIter',1e6);
% 
% options = optimset('Display','final','MaxFunEvals',2e5,'TolX',1e-8,'Tolfun',1e-8,'MaxIter',5e6);


%%

% 
% for index_move=1:20
%     moving1=linspace(15,14.5,20);
%     moving2=linspace(11,11.5,20);
%     
    
    
%             theta_a = [0 0.1];
%             theta_k = [12.8 moving(index_move)]
    

% 
%  PF_order  = [8 2];

N_quadrature = 5;

T_sim = 5e5; %length of the simulation
T_irf = 32; 


% Gamma = gamma/(1+  exp( gammaD0*(k-gammaD1) )  )
% Gamma' = -gammaD0*exp( gammaD0*(k-gammaD1) )*gamma/(1+  exp(gammaD0*(k-gammaD1) )  )^2
gamma   = 1e-2;
gammaD0 = 20; 
gammaD1 = 11.75;
if strcmp(Problem_type,'simple')
    gamma = 0;
end


% economic parameters
alpha = 0.36;  % capital share of output
beta  = 0.99;  % discount factor
delta = 0.025; % depreciation rate
rho   = 0.9;  % productivity persistence
sig_a = 0.01; % volatilify of productivity shocks
sigma = 2;



%% starting guess




%% grids and quadrature nodes

%% quadrature nodes
[nodes, weights] = GaussHermite_2(N_quadrature);
nodes   = sqrt(2)*sig_a*nodes;
weights = pi^(-0.5)*weights;


%% grids
% define boundaries



a_grid_lb = -0.1;
a_grid_ub = 0.1;
a_grid_N  = 10;

k_grid_lb = 10;
k_grid_ub = 17;
k_grid_N  = 20;

k_grid = linspace(k_grid_lb,k_grid_ub,k_grid_N);
a_grid = linspace(a_grid_lb,a_grid_ub,a_grid_N); 
k_grid_adj = k_grid;
a_grid_adj = a_grid; 




[kk_grid,aa_grid] = comb_vector(k_grid,a_grid);
[k_grid_adj,a_grid_adj] = comb_vector(k_grid_adj,a_grid_adj);

[nodes_grid,kkk_grid] = comb_vector(nodes',kk_grid);
[~,aaa_grid] = comb_vector(nodes',aa_grid);
[weights_grid,~] = comb_vector(weights',aa_grid);

 
lkk  = length(kk_grid);
lkkk = length(kkk_grid);
ln   = length(nodes');

summation_matrix = zeros(lkkk,lkk);
for i=1:lkk
    summation_matrix(1+(i-1)*ln:i*ln,i) = weights_grid(1+(i-1)*ln:i*ln)';
end


%% define functions
% policy function
[PF,PF1,f_X,f_X_long,coefficients] = load_policy_function(PF_type,PF_order,theta_a,theta_k);
f_k_p = @(a,k,xi) PF(a,k,xi);
f1_k_p = @(a,k,xi) PF1(a,k,xi);

%other function
f_a_p = @(a,epsilon) rho*a + epsilon; % law of motion for productivity

% functions
%kappa_grid=0.5:0.05:0.8
kappa = 0.5;
%kappa=kappa_grid(8-i)

f_y      = @(a,k) kappa*exp(a).*k.^alpha;  %output
% f_GAMMA  = @(k) gamma*(  exp( -gammaD0*(k-gammaD1) )   +exp( gammaU0*(k-gammaU1) )  ); % capital boundary function
% f_dGAMMA = @(k) gamma*(  -gammaD0*exp( -gammaD0*(k-gammaD1) )   + gammaU0*exp( gammaU0*(k-gammaU1) )  );  % dGAMMA/dk
f_GAMMA  = @(k) gamma./(1+  exp( gammaD0*(k-gammaD1) )  ); % capital boundary function
f_dGAMMA = @(k) -gammaD0*exp( gammaD0*(k-gammaD1) )*gamma./(1+  exp( gammaD0*(k-gammaD1) )  ).^2;  % dGAMMA/dk
f_R      = @(a,k) (alpha*kappa*exp(a).*k.^(alpha-1)+1-delta)./(1+f_dGAMMA(k)); % interest rate
f_c      = @(a,k,k_p) f_y(a,k)+(1-delta)*k-f_GAMMA(k_p)-k_p; % consumption
f_u      = @(c) c^(1-sigma)/(1-sigma); % utility of consumption
f_du     = @(c) c.^(-sigma);



f_EE_error_long = @(a,k,a_p,k_p,k_pp) -1+ beta*f_du(f_c(a_p,k_p,k_pp))./f_du(f_c(a,k,k_p)).*f_R(a_p,k_p) ...
    +  1e6*max(-f_c(a_p,k_p,k_pp),0);

f_EE_error = @(a,k,epsilon,xi) ...
    f_EE_error_long(a,k,f_a_p(a,epsilon),f_k_p(a,k,xi),f_k_p(f_a_p(a,epsilon),f_k_p(a,k,xi),xi));


f_SSR = @(Xi) norm(f_EE_error(aaa_grid,kkk_grid,nodes_grid,Xi)*summation_matrix);

adj_EE_SSR= @(Xi) EE_SSR(Xi,a_grid,k_grid,nodes,weights,f_EE_error);


f_M_long = @(a,k,a_p,k_p,k_pp) beta*f_du(f_c(a_p,k_p,k_pp))./f_du(f_c(a,k,k_p)).*f_R(a_p,k_p) ;
f_M = @(a,k,epsilon,xi) ...
    f_M_long(a,k,f_a_p(a,epsilon),f_k_p(a,k,xi),f_k_p(f_a_p(a,epsilon),f_k_p(a,k,xi),xi));







% %plot hermite polynomias over the grids
% figure(6)
% subplot(2,1,1)
% X_k = f_X(zeros(size(k_grid)),k_grid);
% X_k(coefficients(:,2)>0,:)=[];
% plot(k_grid,X_k')
% xlabel('capital')
% %vline([min(k),mean(k),max(k)])
% 
% 
% subplot(2,1,2)
% X_a = f_X(a_grid,zeros(size(a_grid)));
% X_a(coefficients(:,1)>0,:)=[];
% plot(a_grid,X_a')
% xlabel('productivity')
%vline([min(a),mean(a),max(a)])

% %test
% f_SSR(Xi_init) - adj_EE_SSR(Xi_init);

%% test condition number
% X = f_X(aa_grid,kk_grid);
% cond(X)

%% projection
fprintf('optimisation...')
if optimize 
    tic; 
    [Xi,fval] = fminsearch(f_SSR,Xi_init,options);
    disp([coefficients';Xi])
    solution_time=toc;
else
    Xi = Xi_init;
    solution_time = 123456789;
end

%[Xi,fval] = fminunc(f_SSR,Xi_init,options);

 %%
%  options = optimset('Display','iter','MaxFunEvals',20000,'TolX',1e-8,'Tolfun',1e-8,'MaxIter',10000);
%  ub = [10,1,10,10];
%  lb = [-10,-1,-1,-1];
%   [Xi,fval] = fmincon(f_SSR,Xi_init,[],[],[],[],lb,ub,[],options)
  %%

%% analyze the errors
% 
% figure(8)
% error=zeros(length(aa_grid),length(kk_grid));
% for index_a=1:length(aa_grid)
%     for index_k=1:length(kk_grid)       
%         for index_eps=1:length(nodes)
%             error(index_a,index_k) = error(index_a,index_k) + ...
%                 weights(index_eps)*f_EE_error(aa_grid(index_a),kk_grid(index_k),nodes(index_eps),Xi);
%         end  
%     end
% end
% 
% [mesh_a,mesh_k] = meshgrid(kk_grid,aa_grid);
% figure(10)
% surf(mesh_k,mesh_a,error)
% xlabel('productivity')
% ylabel('capital')
% zlabel('EE error')






%% simulate the results
rng(12345)
% get the steady state
a = zeros(1,500);
k = ones(1,500);
k(1)=k_ss;

for t=1:500    
    k(t+1) = f1_k_p(a(t),k(t),Xi);
end
k_ss=k(end)





% simulate the series
epsilon = sig_a*randn(1,T_sim);

a = zeros(1,T_sim);
k = ones(1,T_sim);
k(1)=k_ss;
tic;
for t=1:T_sim    
    a(t+1) = f_a_p(a(t),epsilon(t));
    k(t+1) = f1_k_p(a(t),k(t),Xi);
end
simulation_time=toc;
% accuracy  
T_start = 500;
EE_error = f_EE_error_long( ...
                a(T_start:end-2),k(T_start:end-2),a(T_start+1:end-1), ...
                k(T_start+1:end-1),k(T_start+2:end));

accuracy = norm(EE_error)
accuracy_rel = mean(abs(EE_error))
% if isnan(accuracy)
%     accuracy=10;
% end
    

%% save the results
% error
if ~isnan(accuracy)
    save_results(PF_type,PF_order,Xi_init,Xi,accuracy,accuracy_rel,solution_time,...
                    simulation_time,kk_grid,aa_grid,parameter,...
                    Solution_type,Grid_type,Problem_type,theta_a,theta_k,exit_flag);
    disp('saved')
end

%% for cycle endings

    end
end


end

end

%% plot the results
% simulated series
c = f_c(a(1:end-1),k(1:end-1),k(2:end));

figure(1)
subplot(3,1,1)
plot(k)
legend('capital')
legend('boxoff')

subplot(3,1,2)
plot(a)   
legend('productivity')
legend('boxoff')

subplot(3,1,3)
plot(c)
legend('consumption')
legend('boxoff')


% irf
a_irf = zeros(1,T_irf);
a_irf(1) = sig_a;
k_irf = k_ss*ones(1,T_irf);

for t=1:T_irf   
    a_irf(t+1) = f_a_p(a_irf(t),0);
    k_irf(t+1) = f_k_p(a_irf(t),k_irf(t),Xi);
end



figure(2)
subplot(1,2,1)
plot((k_irf-k_ss)/k_ss)
legend('capital irf')
legend('boxoff')

subplot(1,2,2)
plot(a_irf)
legend('productivity irf')
legend('boxoff')




% scatter plot of simulation vs the grid
figure(3)
scatter(a(1:2:end),k(1:2:end),'.');
hold on;
scatter(aa_grid,kk_grid,'r','filled')

[~, max_k_pos] = max(k);
[~, min_k_pos] = min(k);
[~, max_a_pos] = max(a);
[~, min_a_pos] = min(a);

scatter([a(min_k_pos) a(max_k_pos) a(min_a_pos) a(max_a_pos)], ...
        [k(min_k_pos) k(max_k_pos) k(min_a_pos) k(max_a_pos)],150,'ok','filled');
hold off


% policy function
k_p=zeros(length(a_grid),length(k_grid));
for index_a=1:length(a_grid)
    for index_k=1:length(k_grid)       
        for index_eps=1:length(nodes)
            k_p(index_a,index_k) = f_k_p(a_grid(index_a),k_grid(index_k),Xi);
        end  
    end
end

[mesh_a,mesh_k] = meshgrid(k_grid,a_grid);
figure(4)
surf(mesh_k,mesh_a,k_p)
xlabel('productivity')
ylabel('capital')
zlabel('capital tomorrow')

% % GAMMA function
% figure(5)
% plot(k_grid,f_GAMMA(k_grid))
% vline([quantile(k,0.05) quantile(k,0.25) quantile(k,0.50) quantile(k,0.75) quantile(k,0.95)])
% 

figure(3)

figure(5)
e_grid=min(k):0.1:max(k);
plot(e_grid,f_k_p(zeros(size(e_grid)),e_grid,Xi))

lin_coef = (f_k_p(0,max(k),Xi) - f_k_p(0,min(k),Xi))/(max(k)-min(k))




figure(7)
plot(min(k)-1:0.05:max(k)+1,f_GAMMA(min(k)-1:0.05:max(k)+1)); hold on
plot(min(k):0.1:max(k),f_GAMMA(min(k):0.1:max(k)),'linewidth',3); hold off




%     end
% end



%end
