function save_results(PF_type,PF_order,Xi_init,Xi,solution_time,k_grid_adj,a_grid_adj,par,...
                        Solution_type,Grid_type,Problem_type,theta_a,theta_k,exit_flag)

% biggest possible order of polynomisals 
max_order = 8;

[xx,yy] = comb_vector(0:max_order,0:max_order);
model_numbers = [xx',yy'];





model_number = [];

i=1;
cont=1;
while cont
    if isequal(model_numbers(i,:),PF_order)
        cont=0;
        model_number = i;
    end
    i=i+1;
end

target_string = strcat('solution_',Solution_type,'_',Grid_type,'_',Problem_type,'.mat');
load(target_string);

% save the results into appropriate matrix
switch PF_type
        case 'basic'
            solution_1.init{model_number}  = Xi_init;
            solution_1.final{model_number} = Xi;
            solution_1.acc(model_number) = 1234567890;
            solution_1.sol_t(model_number) = solution_time;  

            solution_1.grid_k{model_number} = k_grid_adj;   
            solution_1.grid_a{model_number} = a_grid_adj; 
            solution_1.par{model_number} = par; 
            solution_1.theta_a{model_number} = theta_a; 
            solution_1.theta_k{model_number} = theta_k; 
            solution_1.exit_flag{model_number} = exit_flag;
            solution_1.datetime{model_number} = datetime;


            
        case 'orthogonal'
            solution_2.init{model_number}  = Xi_init;
            solution_2.final{model_number} = Xi;
            solution_2.acc(model_number)= 1234567890;
            solution_2.sol_t(model_number) = solution_time;  
  
            solution_2.grid_k{model_number} = k_grid_adj;   
            solution_2.grid_a{model_number} = a_grid_adj; 
            solution_2.par{model_number} = par; 
            solution_2.theta_a{model_number} = theta_a; 
            solution_2.theta_k{model_number} = theta_k; 
            solution_2.exit_flag{model_number} = exit_flag;  
            solution_2.datetime{model_number} = datetime;            
            

            
        case 'norm'           
            solution_3.init{model_number}  = Xi_init;
            solution_3.final{model_number} = Xi;
            solution_3.acc(model_number) = 1234567890;
            solution_3.sol_t(model_number) = solution_time;  

            solution_3.grid_k{model_number} = k_grid_adj;   
            solution_3.grid_a{model_number} = a_grid_adj;     
            solution_3.par{model_number} = par; 
            solution_3.theta_a{model_number} = theta_a; 
            solution_3.theta_k{model_number} = theta_k;        
            solution_3.exit_flag{model_number} = exit_flag;       
            solution_3.datetime{model_number} = datetime;            
            

            
        case 'orthnorm'
            solution_4.init{model_number}  = Xi_init;
            solution_4.final{model_number} = Xi;
            solution_4.acc(model_number) = 1234567890;
            solution_4.sol_t(model_number) = solution_time;  

            solution_4.grid_k{model_number} = k_grid_adj;   
            solution_4.grid_a{model_number} = a_grid_adj; 
            solution_4.par{model_number} = par; 
            solution_4.theta_a{model_number} = theta_a; 
            solution_4.theta_k{model_number} = theta_k;  
            solution_4.exit_flag{model_number} = exit_flag;    
            solution_4.datetime{model_number} = datetime;            

end


target_string = strcat('solution_',Solution_type,'_',Grid_type,'_',Problem_type,'.mat');
save(target_string,'solution_1','solution_2','solution_3','solution_4');