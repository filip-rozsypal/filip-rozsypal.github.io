





clear;
clc


%% initialisation
% setting
Solution_type = 'direct'; 
Grid_type = 'product'; 

% Solution_type = 'iterative'; 
% Grid_type = 'ergodic'; 

Problem_type = 'complex'; 
% Problem_type = 'simple'; 


T_sim = 1e5; %length of the simulation



% Gamma = gamma/(1+  exp( gammaD0*(k-gammaD1) )  )
% Gamma' = -gammaD0*exp( gammaD0*(k-gammaD1) )*gamma/(1+  exp(gammaD0*(k-gammaD1) )  )^2
gamma   = 3e-2;
gammaD0 = 3; 
gammaD1 = 12;
if strcmp(Problem_type,'simple')
    gamma = 0;
end


% economic parameters
alpha = 0.36;  % capital share of output
beta  = 0.99;  % discount factor
delta = 0.025; % depreciation rate
rho   = 0.9;  % productivity persistence
sig_a = 0.01; % volatilify of productivity shocks
sigma = 2;


rng(12345)
epsilon = sig_a*randn(1,T_sim);

% Problem_type_set={'simple', 'complex'}
% for ii=1:2
%     Problem_type=Problem_type_set{ii}





%%
PF_type_set   = {'basic','norm', 'orthogonal', 'orthnorm'};
for index_PF_type = 1:4
    PF_type = PF_type_set{index_PF_type}


            
            
    target_string = strcat('solution_',Solution_type,'_',Grid_type,'_',Problem_type,'.mat');
    load(target_string);
    
    solution_1.errors = [];
    solution_2.errors = [];
    solution_3.errors = [];
    solution_4.errors = [];    
    
    save(target_string,'solution_1','solution_2','solution_3','solution_4');          

end


