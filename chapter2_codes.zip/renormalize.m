function [Xi_new,theta_a_new,theta_k_new] = ...
    renormalize(Xi_old,theta_a_old,theta_k_old,f_X_long,a_grid,k_grid,unstable)






f_X_long_adjusted = @(x1,x2,x3,x4) f_X_long(a_grid,k_grid,[x1 x2],[x3 x4]);



f_cond = @(x) cond(f_X_long_adjusted(x(1),x(2),x(3),x(4)));

x0 = [theta_a_old(1);theta_a_old(2);theta_k_old(1);theta_k_old(2)];
%[cond_out,condition_number] = fminsearch(f_cond,x0);

%warning('off',optim:fminunc:SwitchingMethod)
options = optimset('MaxFunEvals',1000,'display','notify');

% [cond_out,condition_number] = fminunc(f_cond,x0,options);

A=[];
b=[];
Aeq=[];
beq=[];
lb = [-1 0.0001 5  0.001]';
ub = [ 1 1      25 10]';
nonlcon=[];

[cond_out,condition_number] = fmincon(f_cond,x0,A,b,Aeq,beq,lb,ub,nonlcon,options);

if ~unstable
    theta_a_new = [cond_out(1) cond_out(2)];
    theta_k_new = [cond_out(3) cond_out(4)];    
else
    theta_a_new = [cond_out(1) cond_out(2)*1.5];
    theta_k_new = [cond_out(3) cond_out(4)*1.5];    
end


X_old = [f_X_long(a_grid,k_grid,theta_a_old,theta_k_old) ];
X_new = [f_X_long(a_grid,k_grid,theta_a_new,theta_k_new) ];


Xi_new = Xi_old * X_old * X_new' /(X_new*X_new');


%testing precision
scaling_error = max(abs(Xi_new*X_new -  Xi_old * X_old));
if scaling_error>1e-8
    Xi_new;
    Xi_old;
    scaling_error
    %error('scaling error')
end









