clear all;clc    



%% choose the model
Problem_type = 'complex'; % 'simple', 'complex'
Solution_type = 'iterative'; %'direct', 'iterative'





%% load the data
if strcmp(Solution_type,'iterative')
    Grid_type = 'ergodic'; %  'ergodic', 'product'
else
    Grid_type = 'product'; %  
end

target_string = strcat('solution_',Solution_type,'_',Grid_type,'_',Problem_type,'.mat');
load(target_string);


%% plot rhe results
PF_type_set={'basic','norm', 'orthogonal', 'orthnorm'};
%figure()
for i=1:4
    


    switch PF_type_set{i}
        case 'basic'
            solution_results=solution_1;
        case 'orthogonal'
            solution_results=solution_2;
        case 'norm'
            solution_results=solution_3;
        case 'orthnorm'
            solution_results=solution_4;
    end
    
    
    

    x = reshape(solution_results.k,9,9)';
    y = reshape(solution_results.a,9,9)';
    accuracy = reshape(solution_results.accrel,9,9)';
    time_sol = reshape(solution_results.sol_t,9,9)';
    time_sim = reshape(solution_results.sim_t,9,9)';

    %accuracy(accuracy>2)=NaN; %do not show bad outcomes
    % accuracy(accuracy<2)=NaN
    accuracy(accuracy==0)=NaN
    
    %subplot(2,2,i)
    figure()
    mesh(x,y,accuracy)
    xlabel('pol order in capital');ylabel('pol order in productivity') 
    title(strcat(Solution_type,'{ }',Problem_type,'{ }',PF_type_set{i}))
    
end
    


% 
% 
% 
% mesh(x,y,accuracy)
% mesh(x,y,time_sol)
% mesh(x,y,time_sim)
% 
% 
% 
% scatter3(solution_results.k,solution_results.a,solution_results.acc)

























