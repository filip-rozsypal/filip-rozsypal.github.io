
%this fucntion computes sum of squared errors on a grid for a and k using
% quadrature nodes and weights for productivity process a



function SSR = EE_SSR(Xi,a_grid,k_grid,nodes,weights,EE_error)



% EE_error(a,k,epsilon,xi)  Euler equation error




error = zeros(length(a_grid),length(k_grid));
N_nodes = length(nodes);


for index_a=1:length(a_grid)
    for index_k=1:length(k_grid)
        
        for index_eps=1:N_nodes
            error(index_a,index_k) = error(index_a,index_k) + ...
                weights(index_eps)*EE_error(a_grid(index_a),k_grid(index_k),nodes(index_eps),Xi);
        end
            
            
%         error(index_a,index_k) = ...
%             weights'*EE_error(repmat(a_grid(index_a),N_nodes,1),repmat(k_grid(index_k),N_nodes,1),nodes,Xi);
        
        
        
        
    end
end

SSR = sqrt(sum(sum(error.*error)));
