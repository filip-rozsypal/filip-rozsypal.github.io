
% policy function
[PF,PF1,f_X,f_X_long,coefficients] = load_policy_function(PF_type,PF_order,theta_a,theta_k);
f_k_p = @(a,k,xi) PF(a,k,xi);
f1_k_p = @(a,k,xi) PF1(a,k,xi);

%other function
f_a_p = @(a,epsilon) rho*a + epsilon; % law of motion for productivity

% functions
%kappa_grid=0.5:0.05:0.8
%kappa=kappa_grid(8-i)

f_y      = @(a,k) kappa*exp(a).*k.^alpha;  %output



% f_GAMMA  = @(k) gamma*(  exp( -gammaD0*(k-gammaD1) )   +exp( gammaU0*(k-gammaU1) )  ); % capital boundary function
% f_dGAMMA = @(k) gamma*(  -gammaD0*exp( -gammaD0*(k-gammaD1) )   + gammaU0*exp( gammaU0*(k-gammaU1) )  );  % dGAMMA/dk


% f_GAMMA  = @(k) gamma./(1+  exp( gammaD0*(k-gammaD1) )  ); % capital boundary function
% f_dGAMMA = @(k) -gammaD0*exp( gammaD0*(k-gammaD1) )*gamma./(1+  exp( gammaD0*(k-gammaD1) )  ).^2;  % dGAMMA/dk

% f_GAMMA  = @(k) gamma./(1+  exp( gammaU0*(k-gammaU1) )  ); % capital boundary function
% f_dGAMMA = @(k) -gammaU0*exp( gammaU0*(k-gammaU1) )*gamma./(1+  exp( gammaU0*(k-gammaU1) )  ).^2;  % dGAMMA/dk

f_GAMMA  = @(k) gamma./(1+  exp( gammaD0*(k-gammaD1) )  ) ... 
                    + gamma./(1+  exp( gammaU0*(k-gammaU1) )  ); % capital boundary function
f_dGAMMA = @(k) -gammaD0*exp( gammaD0*(k-gammaD1) )*gamma./(1+  exp( gammaD0*(k-gammaD1) )  ).^2 ...
                    -gammaU0*exp( gammaU0*(k-gammaU1) )*gamma./(1+  exp( gammaU0*(k-gammaU1) )  ).^2;  % dGAMMA/dk
                
                


f_R      = @(a,k) (alpha*kappa*exp(a).*k.^(alpha-1)+1-delta)./(1+f_dGAMMA(k)); % interest rate
f_c      = @(a,k,k_p) f_y(a,k)+(1-delta)*k-f_GAMMA(k_p)-k_p; % consumption
f_cc     = @(a,k,xi) f_y(a,k)+(1-delta)*k-f_GAMMA(PF(a,k,xi))-PF(a,k,xi); % consumption
f_u      = @(c) c^(1-sigma)/(1-sigma); % utility of consumption
f_du     = @(c) c.^(-sigma);





f_EE_error_long = @(a,k,a_p,k_p,k_pp) -1+ beta*f_du(f_c(a_p,k_p,k_pp))./f_du(f_c(a,k,k_p)).*f_R(a_p,k_p) ...
    +  1e6*max(-f_c(a_p,k_p,k_pp),0);

f_EE_error = @(a,k,epsilon,xi) ...
    f_EE_error_long(a,k,f_a_p(a,epsilon),f_k_p(a,k,xi),f_k_p(f_a_p(a,epsilon),f_k_p(a,k,xi),xi));

f_EE_error_short = @(Xi) f_EE_error(aaa_grid,kkk_grid,nodes_grid,Xi)*summation_matrix;


f_SSR = @(Xi) norm(f_EE_error(aaa_grid,kkk_grid,nodes_grid,Xi)*summation_matrix);

adj_EE_SSR= @(Xi) EE_SSR(Xi,a_grid,k_grid,nodes,weights,f_EE_error);


f_M_long = @(a,k,a_p,k_p,k_pp) beta*f_du(f_c(a_p,k_p,k_pp))./f_du(f_c(a,k,k_p)).*f_R(a_p,k_p) ;

f_M = @(a,k,epsilon,xi) ...
    f_M_long(a,k,f_a_p(a,epsilon),f_k_p(a,k,xi),f_k_p(f_a_p(a,epsilon),f_k_p(a,k,xi),xi));






