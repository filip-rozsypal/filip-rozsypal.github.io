


















% Basic solution



clear all;
clc






%% initialisation
% setting
PF_type   = 'norm'; % 'basic','norm', 'orthogonal', 'orthnorm'


NN=20;
scale_1_grid = linspace(14.5,15.5,NN);
scale_2_grid = linspace(3,4,NN);
for index_1=1:NN
    for index_2=1:NN
    


PF_order  = [3 2];

N_quadrature = 1;

T_sim = 5e3; %length of the simulation
T_irf = 32; 

% Gamma = gamma*(  exp( -gammaD0*(k-gammaD1) )   +exp( gammaU0*(k-gammaU1) )  )
gamma   = 0*1e-2;
gammaU0 = 0*3; 
gammaU1 = 45; 
gammaD0 = 4; 
gammaD1 = 31.5;

% economic parameters
alpha = 0.36;  % capital share of output
beta  = 0.99;  % discount factor
delta = 0.025; % depreciation rate
rho   = 0.9;  % productivity persistence
sig_a = 0.02; % volatilify of productivity shocks
sigma = 2.75;
%%

k_ss = 30;

%optimisation setting
options = optimset('Display','final','MaxFunEvals',2e5,'TolX',1e-10,'Tolfun',1e-10,'MaxIter',1e6);
options = optimset('Display','final','MaxFunEvals',2e4,'TolX',1e-8,'Tolfun',1e-8,'MaxIter',1e6);
% starting guess
Xi_init = load_starting_guess(PF_order,PF_type);
% 
%  Xi_init = [      39.6808    4.8281    0.9938    1.6806    0.0304  ... 
%                 -0.0002    0.5834    0.0172    0.0003    0.0000   -0.0012   -0.0001 ...
%                 0.0000    0.0002   -0.0000    0.0000]

%Xi_init =  [ 14.9816    1.0046    1.0755    0.0300] %for [15 1.2]
% Xi_init=zeros(size(Xi_init))
% Xi_init(1)=38



% scaling parameters
theta_a = [0 .11];
theta_k = [scale_1_grid(index_1) scale_2_grid(index_2)];                
         
%% grids and quadrature nodes
[summation_matrix,weights_grid,nodes_grid,aaa_grid,... 
    kkk_grid,k_grid_adj,a_grid_adj,k_grid,a_grid,nodes,weights] = ... 
    get_grids(N_quadrature,PF_type,sig_a);

%% define functions
% policy function
[PF,f_X,coefficients] = load_policy_function(PF_type,PF_order,theta_a,theta_k);


%% test condition number
X = f_X(a_grid_adj,k_grid_adj);
conditional_results(index_1,index_2)=cond(X);
% conditional_results2(index_1,index_2)=inv(X'*X);

    end
    
end


%%


[mesh_1,mesh_2] = meshgrid(scale_1_grid,scale_2_grid);


surf(mesh_1,mesh_2,conditional_results')

















