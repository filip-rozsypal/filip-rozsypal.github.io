

clear;
clc



%% initialisation
% general setting

T_sim = 1e4; %length of the simulation
T_irf = 32; 

gamma   = 7.5e-2;

gammaD0 = 15; 
gammaD1 = 7.5;

gammaU0 = -15; 
gammaU1 = 11.5;






% economic parameters
alpha = 0.33;  % capital share of output
beta  = 0.95;  % discount factor
delta = 0.025; % depreciation rate
rho   = 0.95;  % productivity persistence
sig_a = 0.02; % volatilify of productivity shocks
sigma = 2;
kappa = 1;



%%
Solution_type1 = 'direct'; %'direct', 'iterative'
Grid_type1 = 'product'; %  'ergodic', 'product'
PF_type1   = 'orthnorm'; % 'basic','norm', 'orthogonal', 'orthnorm'
Problem_type1 = 'complex'; % 'simple', 'complex'
PF_order1 = [5 5];


%%
Solution_type2 = 'iterative'; %'direct', 'iterative'
Grid_type2 = 'ergodic'; %  'ergodic', 'product'
PF_type2   = 'orthnorm'; % 'basic','norm', 'orthogonal', 'orthnorm'
Problem_type2 = 'complex'; % 'simple', 'complex'
PF_order2 = [5 5];




%%

 [summation_matrix2,weights_grid2,nodes_grid2,aaa_grid2, ...
            kkk_grid2,kk_grid2,aa_grid2,k_grid2,a_grid2,nodes2,weights2] = ... 
                get_grids_figures(7,PF_type1,sig_a);
%% starting guess
[Xi,theta_a,theta_k] = load_starting_guess(PF_order1,PF_type1,Solution_type1,Grid_type1,Problem_type1,[],[],1);


%% define functions

if strcmp(Problem_type1,'simple')
    gamma = 0;
end
PF_type = PF_type1; PF_order = PF_order1;
define_functions;

%%
         
load('evaluation_e_grid')   
f_EE_error_e_short1 = @(Xi) f_EE_error(aaa_grid,kkk_grid,nodes_grid,Xi)*summation_matrix;
EE_error_e_grid1 =  f_EE_error_e_short1(Xi);

%load('evaluation_p_grid') 
f_EE_error_p_short1 = @(Xi) f_EE_error(aaa_grid2,kkk_grid2,nodes_grid2,Xi)*summation_matrix2;
EE_error_p_grid1 =  f_EE_error_p_short1(Xi);



%% starting guess
[Xi,theta_a,theta_k] = load_starting_guess(PF_order2,PF_type2,Solution_type2,Grid_type2,Problem_type2,[],[],1);

%% define functions
gamma   = 3e-2;
if strcmp(Problem_type2,'simple')
    gamma = 0;
end
PF_type = PF_type2; PF_order = PF_order2;
define_functions;

load('evaluation_e_grid')             
f_EE_error_e_short2 = @(Xi) f_EE_error(aaa_grid,kkk_grid,nodes_grid,Xi)*summation_matrix;
EE_error_e_grid2 =  f_EE_error_e_short2(Xi);

%load('evaluation_p_grid') 
f_EE_error_p_short2 = @(Xi) f_EE_error(aaa_grid2,kkk_grid2,nodes_grid2,Xi)*summation_matrix2;
EE_error_p_grid2 =  f_EE_error_p_short2(Xi);




%% plot the results
az=-10;el=25;

%
figure(1)
scatter3(a_grid,k_grid,EE_error_e_grid1,75,EE_error_e_grid1,'p','filled')
hold on
scatter3(a_grid,k_grid,EE_error_e_grid2,25,EE_error_e_grid2,'filled')
hold off
view(az,el);

legend('direct','iterative','Location','Best');

%%
figure(2)
%subplot(2,1,1)
scatter3(a_grid,k_grid,EE_error_e_grid1,25,'red')
hold on
scatter3(a_grid,k_grid,EE_error_e_grid2,25,'blue','filled')
scatter3(a_grid,k_grid,-0.04*ones(size(EE_error_e_grid2)),1,[0.1 0.1 0.1])
hold off
view(az,el);
xlabel('productivity')
ylabel('capital')
zlabel('error')

export_fig('G:\filip_dropbox\Dropbox\research\texts\thesis\Chapter2\figures\grid1', '-pdf','-transparent');

figure(3)
%subplot(2,1,2)
scatter3(aa_grid2,kk_grid2,EE_error_p_grid1,25,'red')
hold on
scatter3(aa_grid2,kk_grid2,EE_error_p_grid2,25,'blue','filled')

scatter3(aa_grid2,kk_grid2,-0.4*ones(size(EE_error_p_grid2)),1,[0.1 0.1 0.1])

hold off
view(az,el);
xlabel('productivity')
ylabel('capital')
zlabel('error')

export_fig('G:\filip_dropbox\Dropbox\research\texts\thesis\Chapter2\figures\grid2', '-pdf','-transparent');
%%


figure(101)
scatter3(a_grid,k_grid,abs(EE_error_e_grid1),75,EE_error_e_grid1,'p','filled')
hold on
scatter3(a_grid,k_grid,abs(EE_error_e_grid2),25,EE_error_e_grid2,'filled')
hold off
view(az,el);


legend('direct','iterative','Location','Best');

%
figure(102)
%subplot(2,1,1)
scatter3(a_grid,k_grid,abs(EE_error_e_grid1),25,'red')
hold on
scatter3(a_grid,k_grid,abs(EE_error_e_grid2),25,'blue','filled')
hold off
view(az,el);


figure(103)
%subplot(2,1,2)
scatter3(aa_grid2,kk_grid2,abs(EE_error_p_grid1),25,'red')
hold on
scatter3(aa_grid2,kk_grid2,abs(EE_error_p_grid2),25,'blue','filled')
hold off
view(az,el);


%% numeric values

p_on_e_5_q = quantile(abs(EE_error_e_grid1),[0.5 0.999])
e_on_e_5_q = quantile(abs(EE_error_e_grid2),[0.5 0.999])

p_on_p_5_q = quantile(abs(EE_error_p_grid1),[0.5 0.999])
e_on_p_5_q = quantile(abs(EE_error_p_grid2),[0.5 0.999])

p_on_e_5_a = mean(abs(EE_error_e_grid1))
e_on_e_5_a = mean(abs(EE_error_e_grid2))

p_on_p_5_a = mean(abs(EE_error_p_grid1))
e_on_p_5_a = mean(abs(EE_error_p_grid2))


[p_on_e_5_q   p_on_p_5_q
 e_on_e_5_q   e_on_p_5_q]


[p_on_e_5_a   p_on_p_5_a
 e_on_e_5_a   e_on_p_5_a]

























%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% %%
% error
% 
% 
% 
% %%
% 
% 
% 
% 
% %%
% 
% 
% steps = 0:.5:100;
% stepsk = 12.5:0.1:15.5;
% stepsz = -0.1:0.025:0.1;
% 
% [XI,YI] = meshgrid(stepsk,stepsz);
% 
% % now interpolate - find z values for these grid points
% ZI = griddata(a_grid,k_grid,EE_error_e_grid1,YI,XI);
% ZI2 = griddata(a_grid,k_grid,EE_error_e_grid2,YI,XI);
% 
% mesh(XI,YI,ZI);hold on
% mesh(XI,YI,ZI2);hold off
% 
% %%
% AA_error = reshape(aa_grid2,length(k_grid2),length(a_grid2));
% KK_error = reshape(kk_grid2,length(k_grid2),length(a_grid2));
% 
% EE_error_grid1 = reshape(EE_error_p_grid1,length(k_grid2),length(a_grid2));
% EE_error_grid2 = reshape(EE_error_p_grid2,length(k_grid2),length(a_grid2));
% 
% figure(2)
% 
% 
% mesh(AA_error',KK_error',EE_error_grid2','black')
% mesh(AA_error',KK_error',EE_error_grid1')
% 
% 
% 
% 
% %%
% scatter3(aa_grid2,kk_grid2,EE_error_p_grid1,50,'blue','filled')
% 
% %%
% 
% 
% 
% hold off
% 
% 
% 
% 
% 
% error('end')
% 
% 
% 
% 
% load('evaluation_p_grid') 
% f_EE_error_short2 = @(Xi) f_EE_error(aaa_grid2,kkk_grid2,nodes_grid2,Xi)*summation_matrix2;
% EE_error_p_grid =  f_EE_error_short2(Xi);
% [counts2,centers2] = hist(abs(EE_error_p_grid),30);
% total2=sum(counts2);
% 
% plot(centers,counts/total,centers2,counts2/total2)
% 
% 
% %% plot the results
% % errors
% 
% 
% %scatter3(a(T_start:100:end-2),k(T_start:100:end-2),EE_error(1:100:end),25,EE_error(1:100:end)*5,'filled')
% %%
% scatter3(a_grid,k_grid,EE_error_e_grid,50,EE_error_e_grid*5,'filled')
% hold on
% 
% EE_error_grid2 = reshape(EE_error_p_grid,length(k_grid2),length(a_grid2));
% AA_error2 = reshape(aa_grid2,length(k_grid2),length(a_grid2));
% KK_error2 = reshape(kk_grid2,length(k_grid2),length(a_grid2));
% mesh(AA_error2',KK_error2',EE_error_grid2')
% hold off
% 
% 
