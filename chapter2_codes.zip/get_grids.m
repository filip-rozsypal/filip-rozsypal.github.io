% this function generatese grids and quadrature nodes

function [summation_matrix,weights_grid,nodes_grid,aaa_grid, ...
            kkk_grid,k_grid_adj,a_grid_adj,k_grid,a_grid,nodes,weights] = ... 
                get_grids(N_quadrature,PF_type,sig_a)




%% quadrature nodes
[nodes, weights] = GaussHermite_2(N_quadrature);
nodes   = sqrt(2)*sig_a*nodes;
weights = pi^(-0.5)*weights;


%% grids
% define boundaries



a_grid_lb = -0.233;
a_grid_ub = 0.233;
a_grid_N  = 10;

k_grid_lb = 7.25;
k_grid_ub = 11.75;
k_grid_N  = 25;

k_grid = linspace(k_grid_lb,k_grid_ub,k_grid_N);
a_grid = linspace(a_grid_lb,a_grid_ub,a_grid_N); 
k_grid_adj = k_grid;
a_grid_adj = a_grid; 





[kk_grid,aa_grid] = comb_vector(k_grid,a_grid);
[k_grid_adj,a_grid_adj] = comb_vector(k_grid_adj,a_grid_adj);

[nodes_grid,kkk_grid] = comb_vector(nodes',kk_grid);
[~,aaa_grid] = comb_vector(nodes',aa_grid);
[weights_grid,~] = comb_vector(weights',aa_grid);

 
lkk  = length(kk_grid);
lkkk = length(kkk_grid);
ln   = length(nodes');

summation_matrix = zeros(lkkk,lkk);
for i=1:lkk
    summation_matrix(1+(i-1)*ln:i*ln,i) = weights_grid(1+(i-1)*ln:i*ln)';
end
