


clear all; clc



load results_manipulated



%%
for i=1:8
    accrel_sym(:,:,:,i) = squeeze(accrel(:,:,:,i,i));
    acc_sym(:,:,:,i) = squeeze(acc(:,:,:,i,i));
    sim_t_sym(:,:,:,i) = squeeze(sim_t(:,:,:,i,i));
end

%% figures
% compare
figure(1)
lines = plot(squeeze(e_quant(1,2,4,1:8,4,:)),'linewidth',2);
xlabel('order of the polynomial')
legend('median','0.9q','0.95q','0.99q','0.999q')
title('complex, Iterative, orthogonal, normalized, quantiles')

%%
figure(2)
lines = plot(squeeze(e_quant(1,2,:,2:8,4,1))','linewidth',2);
set(lines(end),'marker','+')
xlabel('order of the polynomial');ylabel('EE realized residual')
legend('basic','norm', 'orthogonal', 'orthnorm')
title('complex, median')
%%
figure(3)
lines = plot(squeeze(e_quant(:,2,4,2:8,4,1))','linewidth',2);
xlabel('order of the polynomial');ylabel('EE realized residual')
legend('iterative','direct')
title('complex, median')
%%
figure(4)
lines = plot(squeeze(e_quant(1,2,4,2:8,4,:)),'linewidth',2); hold on
xlabel('order of the polynomial')
set(lines(:),'marker','+')
lines = plot(squeeze(e_quant(2,2,4,2:8,4,:)),'linewidth',2); hold off
title('complex, Iterative, orthogonal, normalized, quantiles')
legend('median i','0.9q i','0.95q i','0.99q i','0.999q i',...
    'median d','0.9q d','0.95q d','0.99q d','0.999q d')





