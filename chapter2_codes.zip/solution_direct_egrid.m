% Basic solution



clear;
clc


Solution_type = 'direct_e'; %'direct', 
Grid_type = 'product'; % 'product', 

optimize = 1;
%% initialisation
% % setting
% PF_type   = 'orthogonal'; % 'basic','norm', 'orthogonal', 'orthnorm'
Problem_type = 'complex'; % 'simple', 'complex'

Problem_type_set = {'simple', 'complex'}

crit_xi = [];

crit_sim = [];
crit_grid = [];
lambda = [];
exit_flag = [];


%optimisation setting
options = optimset('Display','final','MaxFunEvals',5e5,'TolX',1e-10,'Tolfun',1e-10,'MaxIter',5e6);
options = optimset('Display','iter','MaxFunEvals',2e4,'TolX',1e-8,'Tolfun',1e-8,'MaxIter',1e6);
% options = optimset('Display','final','MaxFunEvals',2e4,'TolX',1e-6,'Tolfun',1e-6,'MaxIter',1e6);
% 
% options = optimset('Display','final','MaxFunEvals',2e5,'TolX',1e-8,'Tolfun',1e-8,'MaxIter',5e6);


%%

% 
% for index_move=1:20
%     moving1=linspace(15,14.5,20);
%     moving2=linspace(11,11.5,20);
%     
    
    
%             theta_a = [0 0.1];
%             theta_k = [12.8 moving(index_move)]
    

% 
%  PF_order  = [8 2];

N_quadrature = 7;

T_sim = 5e5; %length of the simulation
T_irf = 32; 


% Gamma = gamma/(1+  exp( gammaD0*(k-gammaD1) )  )
% Gamma' = -gammaD0*exp( gammaD0*(k-gammaD1) )*gamma/(1+  exp(gammaD0*(k-gammaD1) )  )^2
gamma   = 7.5e-2;

gammaD0 = 15; 
gammaD1 = 7.5;

gammaU0 = -15; 
gammaU1 = 11.5;




if strcmp(Problem_type,'simple')
    gamma = 0;
end


% economic parameters
alpha = 0.33;  % capital share of output
beta  = 0.95;  % discount factor
delta = 0.025; % depreciation rate
rho   = 0.95;  % productivity persistence
sig_a = 0.02; % volatilify of productivity shocks
sigma = 2;
kappa = 1;

% Problem_type_set={'simple', 'complex'}
% for ii=1:2
%     Problem_type=Problem_type_set{ii}

PF_type_set   = {'basic','norm', 'orthogonal', 'orthnorm'};
for index_PF_type=4:4
    PF_type = PF_type_set{index_PF_type}
 % scaling parameters
switch PF_type
        case 'basic'     
            theta_a = [0 1];
            theta_k = [0 1];    

        case 'orthogonal'           
            theta_a = [0 1];
            theta_k = [0 1];   
            
        case 'norm'           
            theta_a = [0 0.04];
            theta_k = [12.8 0.8];       

        case 'orthnorm'
            theta_a = [-0.0011    0.0730];
            theta_k = [9.1892    0.6838];      
end

parameter_export;
% 



for PF_order_1 = 4:4
    for PF_order_2 = PF_order_1:PF_order_1
        PF_order = [PF_order_1 PF_order_2]
        
%          PF_order  = [3 3];

%% starting guess
%load the starting guess from the iterative solution
k_ss = 9;
%[Xi_init,theta_a,theta_k] = load_starting_guess(PF_order,PF_type,'iterative','ergodic',Problem_type,theta_a,theta_k,1);
[Xi_init,theta_a,theta_k] = load_starting_guess(PF_order,PF_type,'direct_e','product',Problem_type,theta_a,theta_k,1);


    theta_k = [9.25 0.7]
    theta_a = [0.0206 0.07]
  Xi_init(1:4) = [9.25 0.06 0.65 0.005];
  Xi_init(5:end) = zeros(size(Xi_init(5:end)));



%% grids and quadrature nodes
% [summation_matrix,weights_grid,nodes_grid,aaa_grid, ...
%             kkk_grid,kk_grid,aa_grid,k_grid,a_grid,nodes,weights] = ... 
%                 get_grids(N_quadrature,PF_type,sig_a);
            
            
load('evaluation_e_grid')     
kk_grid = [];aa_grid=[];k_grid = []; a_grid=[];


%% define functions
define_functions;

%% projection
fprintf('optimisation...')
if optimize 
    tic; 
    [Xi,fval] = fminsearch(f_SSR,Xi_init,options);
    disp([coefficients';Xi])
    solution_time=toc;
else
    Xi = Xi_init;
    solution_time = 123456789;
end

%[Xi,fval] = fminunc(f_SSR,Xi_init,options);

 %%
%  options = optimset('Display','iter','MaxFunEvals',20000,'TolX',1e-8,'Tolfun',1e-8,'MaxIter',10000);
%  ub = [10,1,10,10];
%  lb = [-10,-1,-1,-1];
%   [Xi,fval] = fmincon(f_SSR,Xi_init,[],[],[],[],lb,ub,[],options)









%% save the results
% error

    save_results(PF_type,PF_order,Xi_init,Xi,solution_time,...
                    kk_grid,aa_grid,parameter,...
                    Solution_type,Grid_type,Problem_type,theta_a,theta_k,exit_flag);
    disp('saved')


%%



%% for cycle endings


    end
end


end

%%

% end

%% plot the results
% simulated series
