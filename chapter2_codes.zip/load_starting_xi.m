

function [Xi_init_out,theta_a,theta_k] =  ... 
    load_starting_xi(PF_order,PF_type,Solution_type,Grid_type,Problem_type,theta_a,theta_k)

    target_string = strcat('solution_',Solution_type,'_',Grid_type,'_',Problem_type,'.mat');
    load(target_string);

    switch PF_type
        case 'basic'
            solution_to_load=solution_1;
        case 'orthogonal'
            solution_to_load=solution_2;
        case 'norm'   
            solution_to_load=solution_3;
        case 'orthnorm'
            solution_to_load=solution_4;
    end

    %% find the correct model

    model_to_load =  ... 
        find(   ...
                (solution_to_load.a<=PF_order(2)) .*  ...
                (solution_to_load.k<=PF_order(1)) ,1,'last');


    %%    load Xi and thetas
    try      
        Xi_init = solution_to_load.final(model_to_load);
        fprintf('using results from model [%u,%u]\n',[solution_1.k(model_to_load) solution_1.a(model_to_load)])
        Xi_init_out = cell2mat(Xi_init);
    catch
        Xi_init_out = [];
        disp('model missing')
    end
    
    %load previous optimal normalising parameters
    try
        if ~isempty(cell2mat(solution_to_load.theta_a(model_to_load)))
            theta_a = cell2mat(solution_to_load.theta_a(model_to_load));
            theta_k = cell2mat(solution_to_load.theta_k(model_to_load));
        else
            disp('theta empty')
        end
    catch
        disp('theta error')
    end
                

end
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% additional functions %%%%
    
    
function coefficients = generate_polynomial_coefficients(PF_order)

coefficients = [0,0];

for sum_coef=1:PF_order(1)+PF_order(2);
    for index_k=0:min(PF_order(1),sum_coef)
        if sum_coef-index_k<=PF_order(2)
            coefficients = [coefficients;[index_k,sum_coef-index_k]];
        end
    end
end
            
end