








    %tic
    figure(1)
    subplot(3,2,1)
    scatter(k_old(1:1:end),a_old(1:1:end),1,[0.75 0.75 1],'.');hold on;
    scatter(k_grid_old,a_grid_old,25,[1 0.75 0.75],'filled');
    scatter(k(1:1:end),a(1:1:end),1,[0 0 1],'.');
    scatter(k_grid,a_grid,25,[1 0 0],'filled');
    xlabel('capital');ylabel('productivity')
    hold off;
%     axis([11 20 -0.1 0.1])

    subplot(3,2,2)
    plot(Xi_change_)
    xlabel('iteration');ylabel('\Delta Xi')
     %toc
% 
%     subplot(4,2,5)
%     plot(k_p_new-k_p_old)
%     ylabel('change of capital on the grid')
    
    subplot(3,2,3)
    scatter(k_grid,k_p_new-k_p_old,'.')
    ylabel('k_{t+1}(Xi_{new})-k_{t+1}(Xi_{old})')
    xlabel('capital')
    
    subplot(3,2,4)
    scatter(a_grid,k_p_new-k_p_old,'.')
    xlabel('productivity')    
    
    subplot(3,2,5)
    scatter(k_grid,k_p_new,'.')
    ylabel('k_{t+1}')    
    xlabel('capital')
    
    subplot(3,2,6)
    scatter(a_grid,k_p_new,'.')
    xlabel('productivity')   

% drawnow



