

clear;
clc



% 
Solution_type = 'direct'; %'direct', 'iterative'
Grid_type = 'product'; %  'ergodic', 'product'


% Solution_type = 'iterative'; %'direct', 'iterative'
% Grid_type = 'ergodic'; %  'ergodic', 'product'

optimize = 0;
%% initialisation
% setting
PF_type   = 'orthnorm'; % 'basic','norm', 'orthogonal', 'orthnorm'
Problem_type = 'complex'; % 'simple', 'complex'

crit_xi   = 1e-6;
crit_sim  = 5e-3;
crit_grid = 5e-3;
lambda    = 0.05;

TT_multiplier = 3;
ddelta = 0.05


N_quadrature = 5;

T_sim = 1e4; %length of the simulation
T_irf = 32; 


% Gamma = gamma/(1+  exp( gammaD0*(k-gammaD1) )  )
% Gamma' = -gammaD0*exp( gammaD0*(k-gammaD1) )*gamma/(1+  exp(gammaD0*(k-gammaD1) )  )^2
gamma   = 3e-2;
%gammaD0 = 20; 
gammaD0 = 3; 
% gammaD1 = 11.75;
gammaD1 = 12;
if strcmp(Problem_type,'simple')
    gamma = 0;
end


% economic parameters
alpha = 0.36;  % capital share of output
beta  = 0.99;  % discount factor
delta = 0.025; % depreciation rate
rho   = 0.9;  % productivity persistence
sig_a = 0.01; % volatilify of productivity shocks
sigma = 2;





%%

PF_order=[6 6]
%% starting guess
epsilon = sig_a*randn(1,T_sim);


k_ss = 13;
[Xi,theta_a,theta_k] = load_starting_guess(PF_order,PF_type,Solution_type,Grid_type,Problem_type,[],[]);





%% define functions

% policy function
[PF,PF1,f_X,f_X_long,coefficients] = load_policy_function(PF_type,PF_order,theta_a,theta_k);
f_k_p = @(a,k,xi) PF(a,k,xi);
f1_k_p = @(a,k,xi) PF1(a,k,xi);

%other function
f_a_p = @(a,epsilon) rho*a + epsilon; % law of motion for productivity

% functions
%kappa_grid=0.5:0.05:0.8
kappa = 0.5;
%kappa=kappa_grid(8-i)

f_y      = @(a,k) kappa*exp(a).*k.^alpha;  %output
% f_GAMMA  = @(k) gamma*(  exp( -gammaD0*(k-gammaD1) )   +exp( gammaU0*(k-gammaU1) )  ); % capital boundary function
% f_dGAMMA = @(k) gamma*(  -gammaD0*exp( -gammaD0*(k-gammaD1) )   + gammaU0*exp( gammaU0*(k-gammaU1) )  );  % dGAMMA/dk
f_GAMMA  = @(k) gamma./(1+  exp( gammaD0*(k-gammaD1) )  ); % capital boundary function
f_dGAMMA = @(k) -gammaD0*exp( gammaD0*(k-gammaD1) )*gamma./(1+  exp( gammaD0*(k-gammaD1) )  ).^2;  % dGAMMA/dk
f_R      = @(a,k) (alpha*kappa*exp(a).*k.^(alpha-1)+1-delta)./(1+f_dGAMMA(k)); % interest rate
f_c      = @(a,k,k_p) f_y(a,k)+(1-delta)*k-f_GAMMA(k_p)-k_p; % consumption
f_u      = @(c) c^(1-sigma)/(1-sigma); % utility of consumption
f_du     = @(c) c.^(-sigma);





f_EE_error_long = @(a,k,a_p,k_p,k_pp) -1+ beta*f_du(f_c(a_p,k_p,k_pp))./f_du(f_c(a,k,k_p)).*f_R(a_p,k_p) ...
    +  1e6*max(-f_c(a_p,k_p,k_pp),0);

f_EE_error = @(a,k,epsilon,xi) ...
    f_EE_error_long(a,k,f_a_p(a,epsilon),f_k_p(a,k,xi),f_k_p(f_a_p(a,epsilon),f_k_p(a,k,xi),xi));

f_EE_error_short = @(Xi) f_EE_error(aaa_grid,kkk_grid,nodes_grid,Xi)*summation_matrix;


f_SSR = @(Xi) norm(f_EE_error(aaa_grid,kkk_grid,nodes_grid,Xi)*summation_matrix);

adj_EE_SSR= @(Xi) EE_SSR(Xi,a_grid,k_grid,nodes,weights,f_EE_error);


f_M_long = @(a,k,a_p,k_p,k_pp) beta*f_du(f_c(a_p,k_p,k_pp))./f_du(f_c(a,k,k_p)).*f_R(a_p,k_p) ;
f_M = @(a,k,epsilon,xi) ...
    f_M_long(a,k,f_a_p(a,epsilon),f_k_p(a,k,xi),f_k_p(f_a_p(a,epsilon),f_k_p(a,k,xi),xi));


%%




% %% simulate the results
% rng(12345)
% % get the steady state
% a = zeros(1,500);
% k = ones(1,500);
% k(1)=k_ss;
% 
% for t=1:500    
%     k(t+1) = f1_k_p(a(t),k(t),Xi);
% end
% k_ss=k(end)
% 
% 
% 
% 
% 
% % simulate the series
% epsilon = sig_a*randn(1,T_sim);
% 
% a = zeros(1,T_sim);
% k = ones(1,T_sim);
% k(1)=k_ss;
% tic;
% for t=1:T_sim    
%     a(t+1) = f_a_p(a(t),epsilon(t));
%     k(t+1) = f1_k_p(a(t),k(t),Xi);
% end
% simulation_time=toc;
% % accuracy  
% T_start = 500;
% EE_error = f_EE_error_long( ...
%                 a(T_start:end-2),k(T_start:end-2),a(T_start+1:end-1), ...
%                 k(T_start+1:end-1),k(T_start+2:end));
% 

        
        
        

            
load('evaluation_e_grid')             
f_EE_error_short = @(Xi) f_EE_error(aaa_grid,kkk_grid,nodes_grid,Xi)*summation_matrix;
EE_error_e_grid =  f_EE_error_short(Xi);

[counts,centers] = hist(abs(EE_error_e_grid),30);
total=sum(counts);


load('evaluation_p_grid') 
f_EE_error_short2 = @(Xi) f_EE_error(aaa_grid2,kkk_grid2,nodes_grid2,Xi)*summation_matrix2;
EE_error_p_grid =  f_EE_error_short2(Xi);
[counts2,centers2] = hist(abs(EE_error_p_grid),30);
total2=sum(counts2);

plot(centers,counts/total,centers2,counts2/total2)


%% plot the results
% errors


%scatter3(a(T_start:100:end-2),k(T_start:100:end-2),EE_error(1:100:end),25,EE_error(1:100:end)*5,'filled')
%%
scatter3(a_grid,k_grid,EE_error_e_grid,50,EE_error_e_grid*5,'filled')
hold on

EE_error_grid2 = reshape(EE_error_p_grid,length(k_grid2),length(a_grid2));
AA_error2 = reshape(aa_grid2,length(k_grid2),length(a_grid2));
KK_error2 = reshape(kk_grid2,length(k_grid2),length(a_grid2));
mesh(AA_error2',KK_error2',EE_error_grid2')
hold off


error

%%

scatter3(a_grid,k_grid,log(abs(EE_error_e_grid)),50,EE_error_e_grid*5,'filled')
hold on

EE_error_grid2 = reshape(EE_error_p_grid,length(k_grid2),length(a_grid2));
AA_error2 = reshape(aa_grid2,length(k_grid2),length(a_grid2));
KK_error2 = reshape(kk_grid2,length(k_grid2),length(a_grid2));
mesh(AA_error2',KK_error2',log(abs(EE_error_grid2))')
hold off


%%




%% quadrature nodes
[nodes, weights] = GaussHermite_2(N_quadrature);
nodes   = sqrt(2)*sig_a*nodes;
weights = pi^(-0.5)*weights;


%grids 


NN = 500
k_grid2 = linspace(min(k)*0.95,max(k)*1.05,2*NN);
a_grid2 = linspace(min(a),max(a),NN);





[kk_grid,aa_grid] = comb_vector(k_grid2,a_grid2);

[nodes_grid,kkk_grid] = comb_vector(nodes',kk_grid);
[~,aaa_grid] = comb_vector(nodes',aa_grid);
[weights_grid,~] = comb_vector(weights',aa_grid);

 
lkk  = length(kk_grid);
lkkk = length(kkk_grid);
ln   = length(nodes');

summation_matrix = zeros(lkkk,lkk);
for i=1:lkk
    summation_matrix(1+(i-1)*ln:i*ln,i) = weights_grid(1+(i-1)*ln:i*ln)';
end




EE_grid = NaN*zeros(2*NN,NN);



f_EE_error_short = @(Xi) f_EE_error(aaa_grid,kkk_grid,nodes_grid,Xi)*summation_matrix;


        




%%
hold off
scatter3(k_grid,a_grid,EE_error_grid,50,'filled')

hold on
mesh(AA,KK,EE_error_grid2')

%%
hold off
scatter3(k_grid,a_grid,log(abs(EE_error_grid)),50,EE_error_grid*5,'filled')

hold on
surf(AA,KK,log(abs(EE_error_grid2')))

%%
error
%%
% simulated series
c = f_c(a(1:end-1),k(1:end-1),k(2:end));

figure(1)
subplot(3,1,1)
plot(k)
legend('capital')
legend('boxoff')

subplot(3,1,2)
plot(a)   
legend('productivity')
legend('boxoff')

subplot(3,1,3)
plot(c)
legend('consumption')
legend('boxoff')


% irf
a_irf = zeros(1,T_irf);
a_irf(1) = sig_a;
k_irf = k_ss*ones(1,T_irf);

for t=1:T_irf   
    a_irf(t+1) = f_a_p(a_irf(t),0);
    k_irf(t+1) = f_k_p(a_irf(t),k_irf(t),Xi);
end



figure(2)
subplot(1,2,1)
plot((k_irf-k_ss)/k_ss)
legend('capital irf')
legend('boxoff')

subplot(1,2,2)
plot(a_irf)
legend('productivity irf')
legend('boxoff')




% scatter plot of simulation vs the grid
figure(3)
scatter(a(1:2:end),k(1:2:end),'.');
hold on;
scatter(a_grid,k_grid,'r','filled')

[~, max_k_pos] = max(k);
[~, min_k_pos] = min(k);
[~, max_a_pos] = max(a);
[~, min_a_pos] = min(a);

scatter([a(min_k_pos) a(max_k_pos) a(min_a_pos) a(max_a_pos)], ...
        [k(min_k_pos) k(max_k_pos) k(min_a_pos) k(max_a_pos)],150,'ok','filled');
hold off


%% % policy function
k_p = reshape(f_k_p(aa_grid,kk_grid,Xi),length(k_grid),length(a_grid));

[mesh_a,mesh_k] = meshgrid(k_grid,a_grid);
% mesh_a = reshape(aa_grid,length(k_grid),length(a_grid))';
% mesh_k = reshape(kk_grid,length(k_grid),length(a_grid))';

surf(k_grid,a_grid,k_p')


scatter3(k_grid,a_grid,f_k_p(a_grid,k_grid,Xi))

%%




[mesh_a,mesh_k] = meshgrid(k_grid,a_grid);
figure(4)
surf(mesh_k,mesh_a,k_p')
xlabel('productivity')
ylabel('capital')
zlabel('capital tomorrow')

% % GAMMA function
% figure(5)
% plot(k_grid,f_GAMMA(k_grid))
% vline([quantile(k,0.05) quantile(k,0.25) quantile(k,0.50) quantile(k,0.75) quantile(k,0.95)])
% 

figure(3)

figure(5)
e_grid=min(k):0.1:max(k);
plot(e_grid,f_k_p(zeros(size(e_grid)),e_grid,Xi))

lin_coef = (f_k_p(0,max(k),Xi) - f_k_p(0,min(k),Xi))/(max(k)-min(k))




figure(7)
plot(min(k)-1:0.05:max(k)+1,f_GAMMA(min(k)-1:0.05:max(k)+1)); hold on
plot(min(k):0.1:max(k),f_GAMMA(min(k):0.1:max(k)),'linewidth',3); hold off



