function l = l_star(a,k)




alpha = 0.34;
sigma = 2;
psi   = 1.5;
delta = 0.025;

a   = 1;
k   = 1;
k_p = 1;

konst1 = psi*(1-alpha)/(sigma-1);
konst2 = psi/(sigma-1)*( (1-delta).*k - k_p  ) ./ ( a*(1-alpha).*k.^alpha  );

f_l_long = @(l,k,a) ...
            l.^alpha ...
            - l.^(1+alpha) ...
            - psi*(1-alpha)/(sigma-1)*l.^(1-alpha) ...
            +psi/(sigma-1)*( (1-delta)*k - k_p  ) ./ ( a.*(1-alpha)*k.^alpha  );




%%
a = ones(1,2000);
k = ones(1,2000) ;     
tic
arrayfun(@(i) fzero(@(l) f_l_long(l,k(i),a(i)),0.3),1:numel(k));
toc

tic
for i=1:2000
    fzero(@(l) f_l_long(l,k(i),a(i)),0.3);
end
toc
%%


ll2=fzero(f_l,0.3);






