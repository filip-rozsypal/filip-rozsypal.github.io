%this code initialises the data file for solutions


max_order = 8;

%get the dimensions of the matrices
[xx,yy] = comb_vector(0:max_order,0:max_order);



%basic solution
solution_1.k     =xx';
solution_1.a     =yy';
solution_1.init  ={};
solution_1.final ={};
solution_1.acc   = NaN*xx';
solution_1.sol_t = NaN*xx';  
solution_1.sim_t = NaN*xx';  


% orthogonal 
solution_2.k     =xx';
solution_2.a     =yy';
solution_2.init  ={};
solution_2.final ={};
solution_2.acc   = NaN*xx';
solution_2.sol_t = NaN*xx';  
solution_2.sim_t = NaN*xx'; 

% norm
solution_3.k     =xx';
solution_3.a     =yy';
solution_3.init  ={};
solution_3.final ={};
solution_3.acc   = NaN*xx';
solution_3.sol_t = NaN*xx';  
solution_3.sim_t = NaN*xx'; 



% orth-norm
solution_4.k     =xx';
solution_4.a     =yy';
solution_4.init  ={};
solution_4.final ={};
solution_4.acc   = NaN*xx';
solution_4.sol_t = NaN*xx';  
solution_4.sim_t = NaN*xx'; 





save('solution_data.mat','solution_1','solution_2','solution_3','solution_4');








