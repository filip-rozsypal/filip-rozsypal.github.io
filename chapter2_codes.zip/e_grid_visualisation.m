







%%


scatter(Sigma_normalised(:,1),Sigma_normalised(:,2),'.')
hold on
scatter(Sigma_normalised(in_set==1,1),Sigma_normalised(in_set==1,2),100,'y','filled')
scatter(Sigma_normalised((consider==0),1),Sigma_normalised((consider==0),2),'.','r')
hold off








%%


scatter(Sigma_normalised(:,1),Sigma_normalised(:,2),80,'filled')
hold on
scatter(Sigma_normalised(index,1),Sigma_normalised(index,2),100,'y','filled')
scatter(Sigma_normalised((consider==0),1),Sigma_normalised((consider==0),2),70,'r')
hold off





%%