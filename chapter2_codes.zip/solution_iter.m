% Basic solution



clear;
clc



%%

Solution_type = 'iterative'; %'direct', 'iterative'
Grid_type = 'ergodic'; %  'ergodic', 'product'
optimize = 1;


%% initialisation
% setting
PF_type   = 'orthnorm'; % 'basic','norm', 'orthogonal', 'orthnorm'
Problem_type = 'complex'; % 'simple', 'complex'

crit_xi   = 5e-8;
crit_sim  = 1e-4;
crit_grid = 1e-2;
lambda    = 0.01;
N_grids_min = 200;
N_grids_max = 250;
convergence_counter = 5e2;

% ddelta = 0.05;
% stretch_factor_k = 0.9;
% stretch_factor_a = 0.9;
% TT_multiplier = 4;


ddelta = 0.00;
stretch_factor_k = 0.0;
stretch_factor_a = 0.0;
TT_multiplier = 6;


% ddelta = 0.02;
% stretch_factor_k = 0.66;
% stretch_factor_a = 0.66;
% TT_multiplier = 4;


unstable = 0;

%%

% 
% for index_move=1:100
%     moving1=linspace(0.001,3e-2,100);
%     moving2=linspace(11,11.5,20);
%     
    
    
%             theta_a = [0 0.1];
%             theta_k = [12.8 moving(index_move)]
    


N_quadrature = 7;

T_sim =20* 0.5*5e5; %length of the simulation

T_sim_short = 20*1e5; % iterative simulation for grids
T_irf = 32; 


% Gamma = gamma/(1+  exp( gammaD0*(k-gammaD1) )  )
% Gamma' = -gammaD0*exp( gammaD0*(k-gammaD1) )*gamma/(1+  exp(gammaD0*(k-gammaD1) )  )^2
% gamma   =moving1(index_move);% 3e-2;

gamma   = 7.5e-2;

gammaD0 = 15; 
gammaD1 = 7.5;

gammaU0 = -15; 
gammaU1 = 11.5;

if strcmp(Problem_type,'simple')
    gamma = 0;
end


% economic parameters
alpha = 0.33;  % capital share of output
beta  = 0.95;  % discount factor
delta = 0.025; % depreciation rate
rho   = 0.95;  % productivity persistence
sig_a = 0.02; % volatilify of productivity shocks
sigma = 2;
kappa = 1;

 % scaling parameters

% Problem_type_set={'simple', 'complex'}
% for ii=1:2
%     Problem_type=Problem_type_set{ii}
% 


PF_type_set   = {'orthnorm','basic','norm', 'orthogonal'};
%PF_type_set   = {'basic','norm', 'orthogonal'};
for index_PF_type=1:1
    PF_type = PF_type_set{index_PF_type}
%     PF_type = 'orthnorm'
    
    
% scaling parameters
switch PF_type
        case 'basic'     
            theta_a = [0 1];
            theta_k = [0 1];    

        case 'orthogonal'           
            theta_a = [0 1];
            theta_k = [0 1];   
            
        case 'norm'           
            theta_a = [0 0.04];
            theta_k = [12.8 0.8];       

        case 'orthnorm'
            theta_a = [0  0.04];
            theta_k = [12.86  0.8];      
end

parameter_export;

PF=[]
PF1=[]
f_X=[]
coefficients=[]
%%
for PF_order_1 = 4:4
    for PF_order_2=PF_order_1:PF_order_1
        PF_order=[PF_order_1 PF_order_2]
%         PF_order = [5 5]


% PF_order=[8 6]

switch PF_type
        case 'basic'     
            theta_a = [0 1];
            theta_k = [0 1];    

        case 'orthogonal'           
            theta_a = [0 1];
            theta_k = [0 1];   
            
        case 'norm'           
            theta_a = [0 0.04];
            theta_k = [12.8 0.8];       

        case 'orthnorm'
            theta_a = [0  0.04];
            theta_k = [12.86  0.8];      
end

% PF_order=[PF_order_1 labindex]
% 
%  PF_order  = [5 1];
%% starting guess
epsilon = sig_a*randn(1,T_sim);


k_ss = 8;
[Xi_init,theta_a,theta_k] = load_starting_guess(PF_order,PF_type,Solution_type,Grid_type,Problem_type,theta_a,theta_k,0);
%   
%     theta_k = [9.25 0.7]
%     theta_a = [0.0206 0.07]
%   Xi_init(1:4) = [9.25 0.06 0.65 0.005];
%   Xi_init(5:end) = zeros(size(Xi_init(5:end)));



%     theta_k = [ 9.0624    1.3045]
%     theta_a = [0 0.1190]
%  Xi_init = [9.0610    0.1030    1.1968    0.0281]


%FOR [5 5]      theta_k = [9.2461    0.6918]
%     theta_a = [ 0.0204    0.0710]
%   Xi_init = [    9.2454 
%     0.0665
%     0.6444
%     0.0063
%    -0.0073
%     0.0039
%     0.0003
%    -0.0028
%     0.0042
%    -0.0017
%     0.0004
%    -0.0035
%     0.0067
%    -0.0048
%     0.0008
%    -0.0000
%    -0.0002
%     0.0013
%    -0.0024
%     0.0010
%    -0.0002
%    -0.0002
%     0.0008
%    -0.0017
%     0.0011
%    -0.0003
%     0.0000
%    -0.0002
%     0.0003
%    -0.0002
%    -0.0000
%     0.0001
%    -0.0001
%     0.0000
%    -0.0000
%    -0.0000]'; 
  
  
  
  
  
Xi=Xi_init;
Xi_crude_  = [Xi_init];
Xi_        = [Xi_init];
Xi_change_ = zeros(size(Xi));
theta_a_ = theta_a;
theta_k_ = theta_k;


%Xi(1) = 13; Xi(2) = 0.1; Xi(3) = 0.8; Xi(4:end) = zeros(size(Xi(4:end)))
% 

%Xi_init =  [  0.3   0.1   0.59    0.05] 
%   
%    
  %Xi_init =  [     13   0.01    0.5    0] 

% Xi_init=zeros(size(Xi_init))
% Xi_init(1)=38








%% define functions

define_functions;


% % %plot hermite polynomias over the grids
% % figure(6)
% % subplot(2,1,1)
% % X_k = f_X(zeros(size(k_grid)),k_grid);
% % X_k(coefficients(:,2)>0,:)=[];
% % plot(k_grid,X_k')
% % xlabel('capital')
% % %vline([min(k),mean(k),max(k)])
% % 
% % 
% % subplot(2,1,2)
% % X_a = f_X(a_grid,zeros(size(a_grid)));
% % X_a(coefficients(:,1)>0,:)=[];
% % plot(a_grid,X_a')
% % xlabel('productivity')
%vline([min(a),mean(a),max(a)])

% %test
% f_SSR(Xi_init) - adj_EE_SSR(Xi_init);

%% test condition number
% X = f_X(aa_grid,kk_grid);
% cond(X)



%% 
if optimize
    cont = 1;
    simulate=1;
    update_grids = 1;
    counter_N_adjustments = 0;

    simulation_results_old=zeros(5,1); 
    Xi_change_crit_=[NaN];
    simulation_results_crit_ = NaN;  
    k_change_cum = [];

    k_grid_old = [];
    a_grid_old = [];
    k_old = [];
    a_old = [];
    a_grid = [];
    k_grid = [];
    
    counter=1;
    N_grid_multiplier = 1;
    diverged = 0;
    
    tic;
    


    a = zeros(1,T_sim_short);
    for t=1:T_sim_short    
        a(t+1) = f_a_p(a(t),epsilon(t));
    end
else
    cont = 0;
    solution_time = 123456789; %CHANGE THIS!
    tic
    kk_grid = [];
    aa_grid = [];
    exit_flag = [];
end
%%
while cont
    %% simulate the series    
    if simulate
        rng(1234567890);
        simulate = 0;
        update_grids = 1;
        
        k = ones(1,T_sim_short);
        k(1)=k_ss;
        tic;
        
        for t=1:T_sim_short    
            k(t+1) = f_k_p(a(t),k(t),Xi);
        end
        
        %correct diverging series
        if max(k)>3*k_ss || min(k)<0.33*k_ss
            disp('simulation diverged, correcting')
            diverged=1;
  

            k_ok = find(((k<3*k_ss).*(k>0.33*k_ss))) ;
            

            k_corrected = [k(k_ok) k_grid];
            a_corrected = [a(k_ok) a_grid];
            ddelta = ddelta*0.95;
            
        else
            k_corrected = k;
            a_corrected = a;
            diverged=0;
        end

        
        
        simulation_time = toc;
        
        k_ss = mean(k_corrected);
        % accuracy  
        T_start = 500;
        EE_error = f_EE_error_long( ...
                        a_corrected(T_start:end-2),k_corrected(T_start:end-2),a_corrected(T_start+1:end-1), ...
                        k_corrected(T_start+1:end-1),k_corrected(T_start+2:end));

        accuracy = norm(EE_error);
        accuracy_rel = norm(EE_error)/length(EE_error);

        correlation = cov(a_corrected,k_corrected);
        simulation_results = [mean(a_corrected); var(a_corrected); mean(k_corrected);var(k_corrected);correlation(2,1)]; 

        simulation_results_crit = max(abs(simulation_results-simulation_results_old)./simulation_results_old);
        simulation_results_old  = simulation_results;
        
        %check whether new grid is needed
        if (simulation_results_crit < crit_sim) &&(~diverged)
            update_grids = 0;
        end
        
    end
    
    %% update grids
    if update_grids
        
        update_grids = 0;
        %disp('simulation changed, updating grids')
        % generate grids
%         recompute_grids=1;
%         while recompute_grids
           [summation_matrix,weights_grid,nodes_grid,aaa_grid, ...
                        kkk_grid,kk_grid,aa_grid,k_grid,a_grid,nodes,weights] ...
               = get_grids_sim(k_corrected,a_corrected,N_quadrature,sig_a,N_grids_min*N_grid_multiplier,N_grids_max*N_grid_multiplier,TT_multiplier, ...
                                stretch_factor_k,stretch_factor_a,ddelta);
                            
     %%   saving for grid comparisons
%            [summation_matrix,weights_grid,nodes_grid,aaa_grid, ...
%                         kkk_grid,kk_grid,aa_grid,k_grid,a_grid,nodes,weights] ...
%                = get_grids_sim(k_corrected,a_corrected,N_quadrature,sig_a,N_grids_min*N_grid_multiplier,N_grids_max*N_grid_multiplier,TT_multiplier, ...
%                                 stretch_factor_k,stretch_factor_a,ddelta);     
%      save('evaluation_e_grid','summation_matrix','weights_grid','nodes_grid','aaa_grid', ...
%                         'kkk_grid','kk_grid','aa_grid','k_grid','a_grid','nodes','weights') 
                    
                   
% [summation_matrix2,weights_grid2,nodes_grid2,aaa_grid2, ...
%             kkk_grid2,kk_grid2,aa_grid2,k_grid2,a_grid2,nodes,weights2] = ... 
%                 get_grids(N_quadrature,PF_type,sig_a);


                    
                    
                 %%   
figure()
hist3([k',a'],[66 50])
set(get(gca,'child'),'FaceColor','interp','CDataMode','auto');
xlabel('capital'); ylabel('productivity');  

%%
figure(200)
scatter(k(1:20:end),a(1:20:end),'.b'); hold on
scatter(k_grid,a_grid,75,'r','filled')
scatter(kk_grid2,aa_grid2,'+k')
hold off
xlabel('capital'); ylabel('productivity');  
print -dpdf myplot2.pdf

figure(300)
scatter(k(1:50:end),a(1:50:end),'.b'); hold on
scatter(k_grid,a_grid,75,'r','filled')
scatter(kk_grid2,aa_grid2,'+k')
hold off
xlabel('capital'); ylabel('productivity');  
print -dpdf myplot3.pdf


       %%    
           
             [Xi_new,theta_a_new,theta_k_new] = ... 
                 renormalize(Xi,theta_a,theta_k,f_X_long,a_grid,k_grid,unstable);

                
            %check whether normalisation in needed
            if cond(f_X_long(a_grid,k_grid,theta_a,theta_k))>1.33*cond(f_X_long(a_grid,k_grid,theta_a_new,theta_k_new))
                
                fprintf('re-normalising, cond old: %1.1e   new : %1.1e\n', ...
                    [cond(f_X_long(a_grid,k_grid,theta_a,theta_k)) cond(f_X_long(a_grid,k_grid,theta_a_new,theta_k_new))])
                
                Xi = Xi_new;
                theta_a = theta_a_new;
                theta_k = theta_k_new;

                %update function definitions
                define_functions;



            end          
           
%            if  cond(f_X_long(a_grid,k_grid,theta_a,theta_k)) < 1e3
%                recompute_grids=0;
%            else
%                disp('bad conditioning, adding more points')
%                cond(f_X_long(a_grid,k_grid,theta_a,theta_k))
%                N_grids_min = 1.5*N_grids_min;
%                N_grids_max = 1.5*N_grids_max;
%            end
%         end
%                

        k_change_cum = zeros(size(k_grid));
        

        
    end
    
    %% update Xi
    
    RHS_kappa = f_M(aaa_grid,kkk_grid,nodes_grid,Xi)*summation_matrix;        
    y = RHS_kappa.*f_k_p(a_grid,k_grid,Xi);        
    X = f_X(a_grid,k_grid);

    X=X'; y=y';

%     Xi_crude = ((X'*X)\X'*y)';
    
    RM        = 6;
    penalty   = 6;
    normalize = 1;
    Xi_crude = Num_Stab_Approx(X,y,RM,penalty,normalize)';
    
    if ~isreal(Xi_crude)
        error(' imaginary coefficients')
    end


    Xi         = lambda*Xi_crude+(1-lambda)*Xi;
    Xi_crude_  = [Xi_crude_;Xi_crude];
    Xi_        = [Xi_;Xi];
    Xi_change_ = [Xi_change_;(Xi-Xi_(end-1,:))./Xi];
    
    theta_a_=[theta_a_;theta_a_new];
    theta_k_=[theta_k_;theta_k_new];
                
                
    Xi_change_crit = max(abs(Xi_change_(end,:)));

    Xi_change_crit_ = [Xi_change_crit_;Xi_change_crit];
    simulation_results_crit_ = [simulation_results_crit_;simulation_results_crit];
    k_p_new = f_k_p(a_grid,k_grid,Xi);
    k_p_old = f_k_p(a_grid,k_grid,Xi_(end-1,:));

    k_change_cum = k_change_cum + k_p_new-k_p_old;

    if max(abs(k_change_cum))>crit_grid
        simulate = 1;
        k_change_cum = 0;
    end
    
    fprintf('%2.7f %1.5f\n',[Xi_change_crit max(abs(k_change_cum))])
    %stop only if the simulation has not changed
    if Xi_change_crit < crit_xi || max(abs(k_p_new-k_p_old))<1e-12
        cont = 0;
        disp('converged');
        exit_flag = 1;
    end
    
    %check for convergence

    if counter>convergence_counter
        if mean(max(abs(Xi_change_(end-400:end-200,:))))<mean(max(abs(Xi_change_(end-200:end,:))))
            if counter_N_adjustments<5
                disp('not converging, adding points to the grid...');
                update_grids = 1;
                N_grid_multiplier = N_grid_multiplier * 1.25;
                convergence_counter = convergence_counter + 250;
                counter_N_adjustments = counter_N_adjustments+1;
                
            else
                cont = 0;
                disp('convergence not achieved, stopping...');
                exit_flag = 2;
            end
        end
        if isnan(Xi_change_crit) 
            disp('diverged, stopping...')
            cont = 0;
            exit_flag = 3;
        end
    end  
    


    %% plot intermediate figures
    intermediate_plots;

    %%
    

    a_old=a;
    k_old=k;
    k_grid_old=k_grid;
    a_grid_old=a_grid;
    counter = counter+1;
end
solution_time=toc;


%% save the results
parameter_export;



if exit_flag ~= 3
    save_results(PF_type,PF_order,Xi_init,Xi,solution_time,...
                    k_grid,a_grid,parameter,...
                    Solution_type,Grid_type,Problem_type,theta_a,theta_k,exit_flag);
    disp('saved')
end

%% for cycle endings
% 
%     end
% end
% % 
% % 
% % end
% end

%% plot the results
% simulated series
c = f_c(a(1:end-1),k(1:end-1),k(2:end));

figure(1)
subplot(3,1,1)
plot(k)
legend('capital')
legend('boxoff')

subplot(3,1,2)
plot(a)   
legend('productivity')
legend('boxoff')

subplot(3,1,3)
plot(c)
legend('consumption')
legend('boxoff')


% irf
a_irf = zeros(1,T_irf);
a_irf(1) = sig_a;
k_irf = k_ss*ones(1,T_irf);

for t=1:T_irf   
    a_irf(t+1) = f_a_p(a_irf(t),0);
    k_irf(t+1) = f_k_p(a_irf(t),k_irf(t),Xi);
end



figure(2)
subplot(1,2,1)
plot((k_irf-k_ss)/k_ss)
legend('capital irf')
legend('boxoff')

subplot(1,2,2)
plot(a_irf)
legend('productivity irf')
legend('boxoff')




% % scatter plot of simulation vs the grid
% figure(3)
% scatter(a(1:2:end),k(1:2:end),'.');
% hold on;
% scatter(aa_grid,kk_grid,'r','filled')
% 
% [~, max_k_pos] = max(k);
% [~, min_k_pos] = min(k);
% [~, max_a_pos] = max(a);
% [~, min_a_pos] = min(a);
% 
% scatter([a(min_k_pos) a(max_k_pos) a(min_a_pos) a(max_a_pos)], ...
%         [k(min_k_pos) k(max_k_pos) k(min_a_pos) k(max_a_pos)],150,'ok','filled');
% hold off


%% % policy function
k_p = reshape(f_k_p(aa_grid,kk_grid,Xi),length(k_grid),length(a_grid));

[mesh_a,mesh_k] = meshgrid(k_grid,a_grid);
% mesh_a = reshape(aa_grid,length(k_grid),length(a_grid))';
% mesh_k = reshape(kk_grid,length(k_grid),length(a_grid))';

surf(k_grid,a_grid,k_p')


scatter3(k_grid,a_grid,f_k_p(a_grid,k_grid,Xi))

%%
target_folder = 'figures_results\';
model_name    = strcat(Solution_type,'_',Problem_type,'_k',num2str(PF_order(1)),'_a',num2str(PF_order(2)),'.tex');



[mesh_a,mesh_k] = meshgrid(k_grid,a_grid);
figure(4)
surf(mesh_k,mesh_a,k_p')
xlabel('productivity')
ylabel('capital')
zlabel('capital tomorrow')

% % GAMMA function
% figure(5)
% plot(k_grid,f_GAMMA(k_grid))
% vline([quantile(k,0.05) quantile(k,0.25) quantile(k,0.50) quantile(k,0.75) quantile(k,0.95)])
% 





figure(6)
e_grid=min(k)*0.95:0.1:max(k)/0.95;
data_to_plot = [f_k_p(quantile(a,0.25)*ones(size(e_grid)),e_grid,Xi); ...
    f_k_p(zeros(size(e_grid)),e_grid,Xi); ...
    f_k_p(quantile(a,0.75)*ones(size(e_grid)),e_grid,Xi)];
plot(e_grid,data_to_plot)
xlabel('capital')
ylabel('k_{t+1} for a=0')
vline(max(k),'--k','k_{max}')
vline(min(k),'--k','k_{min}')
vline(max(k_grid),'--r','kgrid_{max}')
vline(min(k_grid),'--r','kgrid_{min}')
legend('productivity low','productivity medium','productivity high')
legend('boxoff')

target = strcat(target_folder,'savings_',model_name);
matlab2tikz(target,'externalData',true,'noSize',true,...
    'relativeDataPath','../', ...
    'extraAxisOptions','legend style={draw=none,at={(0.5,1.03)},anchor=south},small,scale only axis')






lin_coef = (f_k_p(0,max(k),Xi) - f_k_p(0,min(k),Xi))/(max(k)-min(k))

figure(3)
f_plot = @(a,k,Xi) ...
        ( f_k_p(a(2:end),k(2:end),Xi) ...
           - f_k_p(a(1:end-1),k(1:end-1),Xi)) ...
         ./f_k_p(a(1:end-1),k(1:end-1),Xi);

data_to_plot = ...
   [f_plot(quantile(a,0.25)*ones(size(e_grid)),e_grid,Xi); ...
    f_plot(quantile(a,0.5)*ones(size(e_grid)),e_grid,Xi); ...
    f_plot(quantile(a,0.75)*ones(size(e_grid)),e_grid,Xi)];
plot(e_grid(1:end-1),data_to_plot)

xlabel('k');ylabel('slope of saving function')
vline(max(k),'--k','k_{max}')
vline(min(k),'--k','k_{min}')
vline(max(k_grid),'--r','kgrid_{max}')
vline(min(k_grid),'--r','kgrid_{min}')
% legend('productivity low','productivity medium','productivity high')
% legend('boxoff')

target = strcat(target_folder,'savings_slope_',model_name);
matlab2tikz(target,'externalData',true,'relativeDataPath','../','noSize',true,...
    'extraAxisOptions','small,scale only axis')


figure(20)
f_plot = @(a,k,Xi) f_cc(a,k,Xi)./f_y(a,k);

data_to_plot = ...
   [f_plot(quantile(a,0.25)*ones(size(e_grid)),e_grid,Xi); ...
    f_plot(quantile(a,0.5)*ones(size(e_grid)),e_grid,Xi); ...
    f_plot(quantile(a,0.75)*ones(size(e_grid)),e_grid,Xi)];

plot(e_grid,data_to_plot)
vline(max(k),'--k','k_{max}')
vline(min(k),'--k','k_{min}')
vline(max(k_grid),'--r','kgrid_{max}')
vline(min(k_grid),'--r','kgrid_{min}')
ylabel('consumption share of output')
xlabel('capital')
% legend('productivity low','productivity medium','productivity high')
% legend('boxoff')

target = strcat(target_folder,'c_share_',model_name);
matlab2tikz(target,'externalData',true,'relativeDataPath','../','noSize',true,...
    'extraAxisOptions','small,scale only axis')



figure(7)
plot(e_grid,f_GAMMA(e_grid)); hold on
plot(min(k):0.025:max(k),f_GAMMA(min(k):0.025:max(k)),'linewidth',3); hold off
hold off
xlabel('capital')
ylabel('GAMMA function')

target = strcat(target_folder,'gamma_f_',model_name);
matlab2tikz(target,'externalData',true,'relativeDataPath','../',...
    'extraAxisOptions','small,scale only axis')

    end
end



end
